//
//  File.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 04/01/2019.
//  Copyright © 2019 RiverSnap. All rights reserved.
//

import Foundation
import UIKit
import WebKit

class BannerViewController: UIViewController, WKNavigationDelegate {
    
    @IBOutlet weak var webView: WKWebView!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.view.showHUD(inView: self.view)
        self.callWSBanner()
        
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    
    
    func callWSBanner() {
        
        
        let urlToRequest = "\(Constants.serverIP)/banner"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "GET"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                DispatchQueue.main.async{
                                    
                                    //print(json["pagina"] as! Dictionary<String, AnyObject>)
                                    
                                    let requestAux = URLRequest(url: NSURL(string: json["url"]! as! String)! as URL)
                                    self.webView.load( requestAux)//loadHTMLString(json["url"]! as! String, baseURL: nil)
                                    self.view.hideHUD()
                                }
                                
                                
                            } catch let error {
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 204:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se ha encontrado la página indicada.")
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
}
