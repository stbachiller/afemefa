package com.deltaceti.afemefa;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ScrollView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.Answer;
import com.deltaceti.afemefa.json.AnswerUpdateProfile;
import com.deltaceti.afemefa.json.LegalText;
import com.deltaceti.afemefa.json.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class EditProfileActivity extends AppCompatActivity {

    private TextInputLayout name_layout, user_layout, pass_layout, confirm_pass_layout,
            email_layout, dni_layout, address_layout, cp_layout, city_layout, province_layout,
            country_layout, phone_number_layout, birth_layout;
    private TextInputEditText name_et, user_et, pass_et, confirm_pass_et, email_et, dni_et,
            address_et, cp_et, city_et, province_et, country_et, phone_number_et;
    private static TextInputEditText birth_et;
    private String name_str, user_str, pass_str="", confirm_pass_str="", email_str, dni_str, address_str,
            cp_str, city_str, province_str, country_str, phone_number_str, birth_str,
            newsletter_str="0";

    private TextView terms_tv, terms_text_tv;

    private ScrollView scrollview;
    private View mProgressView;
    private Button accept_btn;

    private Dialog dialog;
    private Gson gson;
    private PrefManager prefManager;

    private RequestQueue requestQueue;
    private String endpointLogin, endpointUpdate, endpointLegalText;
    private Answer answer;

    private CheckBox newsletter_checkbox, terms_checkbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        accept_btn = findViewById(R.id.btn_register);
        scrollview = findViewById(R.id.scrollView1);

        accept_btn.setText(getResources().getString(R.string.btn_accept));

        name_layout = findViewById(R.id.name_layout);
        user_layout = findViewById(R.id.user_layout);
        pass_layout = findViewById(R.id.pass_layout);
        confirm_pass_layout = findViewById(R.id.pass_confirm_layout);
        email_layout = findViewById(R.id.email_layout);
        dni_layout = findViewById(R.id.dni_layout);
        address_layout = findViewById(R.id.address_layout);
        cp_layout = findViewById(R.id.cp_layout);
        city_layout = findViewById(R.id.city_layout);
        province_layout = findViewById(R.id.province_layout);
        country_layout = findViewById(R.id.country_layout);
        phone_number_layout = findViewById(R.id.phone_number_layout);
        birth_layout = findViewById(R.id.birthday_layout);

        name_et = findViewById(R.id.name_et);
        user_et = findViewById(R.id.user_et);
        pass_et = findViewById(R.id.pass_et);
        confirm_pass_et = findViewById(R.id.pass_confirm_et);
        email_et = findViewById(R.id.email_et);
        dni_et = findViewById(R.id.dni_et);
        address_et = findViewById(R.id.address_et);
        cp_et = findViewById(R.id.cp_et);
        city_et = findViewById(R.id.city_et);
        province_et = findViewById(R.id.province_et);
        country_et = findViewById(R.id.country_et);
        phone_number_et = findViewById(R.id.phone_number_et);
        birth_et = findViewById(R.id.birthday_et);

        newsletter_checkbox = findViewById(R.id.newsletter_checkbox);
        terms_checkbox = findViewById(R.id.terms_checkbox);
        terms_tv = findViewById(R.id.terms_tv);
        terms_text_tv = findViewById(R.id.terms_text_tv);

        mProgressView = findViewById(R.id.login_progress);

        prefManager = new PrefManager(getApplicationContext());
        gson = new GsonBuilder().serializeNulls().create();

        Utils.showProgress(true, getApplicationContext(), scrollview, mProgressView);
        requestQueue = Volley.newRequestQueue(getApplicationContext());

        if (prefManager.getUserId().compareTo("defaultStringIfNothingFound")!=0){
            endpointLogin = getString(R.string.base_url).concat(getString(R.string.profile_path)).concat("/").concat(prefManager.getUserId());
            fetchPosts();
        }

        newsletter_checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
               @Override
               public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
               newsletter_str = "0";
               if (isChecked){
                   newsletter_str = "1";
               }
               }
           }
        );

        birth_et.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    DatePickerFragment mDatePicker = new DatePickerFragment();
                    mDatePicker.show(getSupportFragmentManager(), "Select date");
                }
            }

        });

        birth_et.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {

                // in onCreate or any event where your want the user to
                // select a file
                DatePickerFragment mDatePicker = new DatePickerFragment();
                mDatePicker.show(getSupportFragmentManager(), "Select date");
            }
        });

        terms_text_tv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                if (Utils.checkConnectivity(getApplicationContext())) {
                    endpointLegalText = getString(R.string.base_url).concat(getString(R.string.legal_text_path));
                    fetchPostsLegalText();
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), EditProfileActivity.this);
                }
            }
        });

        accept_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptAccept();
            }
        });
    }

    private void attemptAccept(){
        name_layout.setError(null);
        user_layout.setError(null);
        pass_layout.setError(null);
        confirm_pass_layout.setError(null);
        email_layout.setError(null);
        dni_layout.setError(null);
        address_layout.setError(null);
        cp_layout.setError(null);
        city_layout.setError(null);
        province_layout.setError(null);
        country_layout.setError(null);
        phone_number_layout.setError(null);
        birth_layout.setError(null);

        name_str = name_et.getText().toString();
        user_str = user_et.getText().toString();
        pass_str = pass_et.getText().toString();
        confirm_pass_str = confirm_pass_et.getText().toString();
        email_str = email_et.getText().toString();
        dni_str = dni_et.getText().toString();
        address_str = address_et.getText().toString();
        cp_str = cp_et.getText().toString();
        city_str = city_et.getText().toString();
        province_str = province_et.getText().toString();
        country_str = country_et.getText().toString();
        phone_number_str = phone_number_et.getText().toString();
        birth_str = birth_et.getText().toString();

        boolean cancel = false;
        View focusView = null;
        terms_tv.setVisibility(View.GONE);


        if (TextUtils.isEmpty(birth_str)) {
            birth_layout.setError(getString(R.string.empty_generic));
            focusView = birth_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(phone_number_str)) {
            phone_number_layout.setError(getString(R.string.empty_generic));
            focusView = phone_number_et;
            cancel = true;
        }
        else if (phone_number_str.length()<9){
            phone_number_layout.setError(getString(R.string.invalid_phone_number));
            focusView = phone_number_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(country_str)) {
            country_layout.setError(getString(R.string.empty_generic));
            focusView = country_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(province_str)) {
            province_layout.setError(getString(R.string.empty_generic));
            focusView = province_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(city_str)) {
            city_layout.setError(getString(R.string.empty_generic));
            focusView = city_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(cp_str)) {
            cp_layout.setError(getString(R.string.empty_generic));
            focusView = cp_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(address_str)) {
            address_layout.setError(getString(R.string.empty_generic));
            focusView = address_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(dni_str)) {
            dni_layout.setError(getString(R.string.empty_generic));
            focusView = dni_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(email_str)) {
            email_layout.setError(getString(R.string.empty_generic));
            focusView = email_et;
            cancel = true;
        }
        else if (!Utils.isEmailValid(email_str)){
            email_layout.setError(getString(R.string.invalid_email));
            focusView = email_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(user_str)) {
            user_layout.setError(getString(R.string.empty_generic));
            focusView = user_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(name_str)) {
            name_layout.setError(getString(R.string.empty_generic));
            focusView = name_et;
            cancel = true;
        }
        if (pass_str.compareTo(confirm_pass_str) != 0) {
            confirm_pass_layout.setError(getString(R.string.diferent_pass));
            focusView = confirm_pass_et;
            cancel = true;
        }


        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.

            focusView.getParent().requestChildFocus(focusView,focusView);
            focusView.requestFocus();
            //scrollview.scrollTo(scrollview.getScrollX(), focusView.getBottom());
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            if (terms_checkbox.isChecked()) {
                if (Utils.checkConnectivity(this)) {
                    Utils.showProgress(true, getApplicationContext(), scrollview, mProgressView);
                    endpointUpdate = getString(R.string.base_url).concat(getString(R.string.profile_update_path));
                    fetchPostsUpdate();
                    //showDialog();

                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), EditProfileActivity.this);
                }
            } else {
                terms_tv.setVisibility(View.VISIBLE);
            }

        }

    }

    void fill_fields(){
        User user = gson.fromJson(prefManager.getUserInfo(), User.class);
        name_et.setText(user.getNombre());
        user_et.setText(user.getUsuario());
        email_et.setText(user.getEmail());
        dni_et.setText(user.getDni());
        address_et.setText(user.getDireccion());
        cp_et.setText(user.getCp());
        city_et.setText(user.getLocalidad());
        province_et.setText(user.getProvincia());
        country_et.setText(user.getPais());
        phone_number_et.setText(user.getTelefono());
        birth_et.setText(user.getFecha_nacimiento());
        Utils.showProgress(false, getApplicationContext(), scrollview, mProgressView);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(EditProfileActivity.this, MenuActivity.class);
                //PrefManager prefManager = new PrefManager(MenuActivity.this);
                //prefManager.setId("defaultStringIfNothingFound");
                startActivity(intent);
                finish();

                //super.onBackPressed();
                break;
        }
        return true;
    }

    private void fetchPosts() {
        StringRequest request = new StringRequest(Request.Method.GET, endpointLogin, onPostsLoaded, onPostsError)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }


            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), EditProfileActivity.this);
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoaded = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            answer = gson.fromJson(response, Answer.class);
            User user = gson.fromJson(answer.getData(), User.class);
            PrefManager prefManager = new PrefManager(getApplicationContext());
            prefManager.setUserInfo(gson.toJson(user));
            fill_fields();

            /*answer = gson.fromJson(response, Answer.class);
            try{
                startActivity(new Intent(MainActivity.this, MenuActivity.class));
            } catch (JsonParseException e) {
                Utils.alertErrorProfessional("ATENCIÓN", getString(R.string.system_fails), ProfessionalLoginActivity.this);
            }*/
        }
    };

    private final Response.ErrorListener onPostsError = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getApplicationContext(), scrollview, mProgressView);
            if (networkResponse != null && networkResponse.statusCode == 401) {
                Utils.alertError("ATENCIÓN", getString(R.string.system_fails), EditProfileActivity.this);
            }
            Log.e("PostActivity", error.toString());
        }
    };


    private void fetchPostsUpdate() {
        StringRequest request = new StringRequest(Request.Method.POST, endpointUpdate, onPostsLoadedUpdated, onPostsErrorUpdated)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("user_id", prefManager.getUserId());
                params.put("first_name", name_str);
                params.put("user_login", user_str);
                if (!pass_str.isEmpty()){
                    params.put("pass1", pass_str);
                    params.put("pass2", pass_str);
                }
                params.put("user_email", email_str);
                params.put("dni", dni_str);
                params.put("direccion", address_str);
                params.put("código_postal", cp_str);
                params.put("localidad", city_str);
                params.put("provincia", province_str);
                params.put("pais", country_str);
                params.put("telefono", phone_number_str);
                params.put("fecha_nacimiento", birth_str);
                params.put("newsletter", newsletter_str);
                Log.d("AFEMAFA", params.toString());
                return params;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), EditProfileActivity.this);
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoadedUpdated = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            Utils.showProgress(false, getApplicationContext(), scrollview, mProgressView);
            AnswerUpdateProfile answer = gson.fromJson(response, AnswerUpdateProfile.class);
            Utils.alertError("ATENCIÓN", answer.getMensaje(), EditProfileActivity.this);

            /*answer = gson.fromJson(response, Answer.class);
            try{
                startActivity(new Intent(MainActivity.this, MenuActivity.class));
            } catch (JsonParseException e) {
                Utils.alertErrorProfessional("ATENCIÓN", getString(R.string.system_fails), ProfessionalLoginActivity.this);
            }*/
        }
    };

    private final Response.ErrorListener onPostsErrorUpdated = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getApplicationContext(), scrollview, mProgressView);
            if (networkResponse != null && networkResponse.statusCode == 401) {
                Utils.alertError("ATENCIÓN", getString(R.string.system_fails), EditProfileActivity.this);
            }
            Log.e("PostActivity", error.toString());
        }
    };

    //////// POST
    private void fetchPostsLegalText() {
        StringRequest request = new StringRequest(Request.Method.GET, endpointLegalText, onPostsLoadedLegalText, onPostsErrorLegalText)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), EditProfileActivity.this);
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoadedLegalText = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            LegalText answer = gson.fromJson(response, LegalText.class);
            try {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(answer.getUrl()));
                startActivity(i);
            } catch(Exception e){
                Log.e("AFEMAFA", "Error opening legal text url");
            }

            Utils.showProgress(false, getApplicationContext(), scrollview, mProgressView);

        }
    };

    private final Response.ErrorListener onPostsErrorLegalText = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getApplicationContext(), scrollview, mProgressView);
            Utils.alertError("ATENCIÓN", getString(R.string.system_fails), EditProfileActivity.this);
            Log.e("PostActivity", error.toString());
        }
    };

    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            int year;
            int month;
            int day;
            if (birth_et.getText().toString().isEmpty()) {
                final Calendar c = Calendar.getInstance();
                year = c.get(Calendar.YEAR);
                month = c.get(Calendar.MONTH);
                day = c.get(Calendar.DAY_OF_MONTH);
            } else {
                String date_str = birth_et.getText().toString();
                String separador = Pattern.quote("/");
                String[] date_array= date_str.split(separador, 3);
                Log.d("AFEMAFA", date_array[0] + date_array[1] + date_array[2]);
                year = Integer.valueOf(date_array[2]);
                month = Integer.valueOf(date_array[1])-1;
                day = Integer.valueOf(date_array[0]);
            }
            DatePickerDialog dialogDatePicker = new DatePickerDialog(getActivity(), android.R.style.Theme_Holo_Light_Dialog, this, year, month, day);
            return dialogDatePicker;
        }
        public void onDateSet(DatePicker view, int year, int month, int day) {
            birth_et.setText(String.valueOf(day).concat("/").concat(String.valueOf(month +1)).concat("/").concat(String.valueOf(year)));
        }
    }

}
