package com.deltaceti.afemefa;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.LegalText;
import com.deltaceti.afemefa.json.RecoverPass;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;


public class MessageContactFragment extends Fragment {

    private TextInputLayout name_layout, email_layout, subject_layout, message_layout;

    private TextInputEditText name_et, email_et, subject_et, message_et;

    private String name_str, email_str, subject_str, message_str;

    private TextView terms_tv, terms_text_tv;

    private Button send_btn;

    private CheckBox terms_checkbox;

    private RequestQueue requestQueue;
    private Gson gson;
    private String endpointLogin, endpointLegalText;
    private View mProgressView;
    private View mLoginFormView;

    View focusView = null;


    public MessageContactFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_contact_message, container, false);

        send_btn = v.findViewById(R.id.btn_send);

        name_layout = v.findViewById(R.id.name_layout);
        email_layout = v.findViewById(R.id.email_layout);
        subject_layout = v.findViewById(R.id.subject_layout);
        message_layout = v.findViewById(R.id.message_layout);

        name_et = v.findViewById(R.id.name_et);
        email_et = v.findViewById(R.id.email_et);
        subject_et = v.findViewById(R.id.subject_et);
        message_et = v.findViewById(R.id.message_et);
        mLoginFormView = v.findViewById(R.id.scrollView1);
        mProgressView = v.findViewById(R.id.login_progress);

        terms_checkbox = v.findViewById(R.id.terms_checkbox);
        terms_tv = v.findViewById(R.id.terms_tv);
        terms_text_tv = v.findViewById(R.id.terms_text_tv);

        terms_text_tv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                if (Utils.checkConnectivity(getActivity())) {
                    Utils.showProgress(true, getContext(), mLoginFormView, mProgressView);
                    requestQueue = Volley.newRequestQueue(getContext());
                    gson = new GsonBuilder().serializeNulls().create();
                    endpointLegalText = getString(R.string.base_url).concat(getString(R.string.legal_text_path));
                    fetchPostsLegalText();
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), getActivity());
                }
            }
        });

        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptSend();
            }
        });

        return v;
    }

    private void attemptSend(){
        name_layout.setError(null);
        email_layout.setError(null);
        subject_layout.setError(null);
        message_layout.setError(null);

        name_str = name_et.getText().toString();
        email_str = email_et.getText().toString();
        subject_str = subject_et.getText().toString();
        message_str = message_et.getText().toString();

        boolean cancel = false;
        terms_tv.setVisibility(View.GONE);


        if (TextUtils.isEmpty(message_str)) {
            message_layout.setError(getString(R.string.empty_generic));
            focusView = message_et;
            cancel = true;
        }

        if (TextUtils.isEmpty(subject_str)) {
            subject_layout.setError(getString(R.string.empty_generic));
            focusView = subject_et;
            cancel = true;
        }

        if (TextUtils.isEmpty(email_str)) {
            email_layout.setError(getString(R.string.empty_generic));
            focusView = email_et;
            cancel = true;
        }

        if (TextUtils.isEmpty(name_str)) {
            name_layout.setError(getString(R.string.empty_generic));
            focusView = name_et;
            cancel = true;
        }
        if (!terms_checkbox.isChecked()){
            terms_tv.setVisibility(View.VISIBLE);
            focusView = terms_checkbox;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
            mLoginFormView.scrollTo(0, focusView.getBottom());
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            if (Utils.checkConnectivity(getActivity())) {
                Utils.showProgress(true, getContext(), mLoginFormView, mProgressView);
                requestQueue = Volley.newRequestQueue(getContext());
                gson = new GsonBuilder().serializeNulls().create();
                endpointLogin = getString(R.string.base_url).concat(getString(R.string.contact_path));
                fetchPosts();
            } else {
                Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), getActivity());
            }

        }
    }

    //////// POST
    private void fetchPosts() {
        StringRequest request = new StringRequest(Request.Method.POST, endpointLogin, onPostsLoaded, onPostsError)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("your-name", name_str);
                params.put("your-email", email_str);
                params.put("your-subject", subject_str);
                params.put("your-message", message_str);
                return params;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else if (response.statusCode==401) {
                    email_layout.setError(getString(R.string.invalid_user));
                    focusView = email_et;
                    focusView.requestFocus();
                    return null;
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoaded = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            RecoverPass answer = gson.fromJson(response, RecoverPass.class);
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            AlertDialog.Builder builder = new AlertDialog.Builder(
                    getActivity(), R.style.AppThemeDialog);
            builder.setCancelable(false);
            builder.setTitle("ATENCIÓN");
            builder.setMessage(answer.getMensaje());
            builder.setPositiveButton("OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int which) {
                            dialog.dismiss();
                        }
                    });

            AlertDialog alert = builder.create();
            alert.show();
        }
    };

    private final Response.ErrorListener onPostsError = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            if (networkResponse != null && networkResponse.statusCode == 401) {
                // HTTP Status Code: 401 Unauthorized
                email_layout.setError(getString(R.string.invalid_user));
                focusView = email_et;
                focusView.requestFocus();
            }
            else {
                Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
            }
            Log.e("PostActivity", error.toString());
        }
    };

    //////// POST
    private void fetchPostsLegalText() {
        StringRequest request = new StringRequest(Request.Method.GET, endpointLegalText, onPostsLoadedLegalText, onPostsErrorLegalText)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getContext());
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoadedLegalText = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            LegalText answer = gson.fromJson(response, LegalText.class);

            try {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(answer.getUrl()));
                startActivity(i);
            } catch(Exception e){
                Log.e("AFEMAFA", "Error opening legal text url");
            }

            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);

        }
    };

    private final Response.ErrorListener onPostsErrorLegalText = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getContext());
            Log.e("PostActivity", error.toString());
        }
    };
}
