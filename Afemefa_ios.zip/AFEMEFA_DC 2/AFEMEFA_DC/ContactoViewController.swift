//
//  ContactoViewController.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 13/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit


class ContactoViewController: UIViewController {
    
    @IBOutlet weak var ContainerOficinas: UIView!
    @IBOutlet weak var ContainerMensajes: UIView!
    
    var mensajesVC : ContactoMensajes!
    var oficinasVC : ContactoOficinas!

    @IBOutlet weak var segmentoContacto: UISegmentedControl!

    
    var datosProvincias : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()
    var datosLocalidades : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()
    var datosEspecialidades : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()
    
    var dataWSMed : [String: String] = ["especialidad":"","especialidadID":"","provincia":"","provinciaID":"","localidad":"","localidadID":"","cp":"","nombreCentro":"","profSanitario":""]
    var dataWSDen : [String: String] = ["provincia":"","provinciaID":"", "localidad":"", "localidadID":"", "cp":"","nombreCentro":"", "profSanitario":""]
    
    override func viewDidLayoutSubviews() {
        
//        self.picker.frame = CGRect(x: 0, y: self.view.frame.size.height - 200, width: self.view.frame.size.width, height: 200)
        
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @IBAction func segmentedAction(_ sender: Any) {
        switch segmentoContacto.selectedSegmentIndex {
        case 0:
            self.ContainerMensajes.isHidden = false
            self.ContainerOficinas.isHidden = true
            break
        case 1:
            self.ContainerMensajes.isHidden = true
            self.ContainerOficinas.isHidden = false
            break
        default:
            break
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        let segAttributes: NSDictionary = [
            NSAttributedString.Key.foregroundColor: UIColor(red: 164/255, green: 203/255, blue: 82/255, alpha: 1), NSAttributedString.Key.font: UIFont(name: "OpenSans-Bold", size: 13)!
        ]
        let segAttributesWhites: NSDictionary = [
            NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: UIFont(name: "OpenSans-Bold", size: 13)!
        ]
        segmentoContacto.setTitleTextAttributes(segAttributes as [NSObject : AnyObject] as [NSObject : AnyObject] as? [NSAttributedString.Key : Any], for: UIControl.State.selected)
        segmentoContacto.setTitleTextAttributes(segAttributesWhites as [NSObject : AnyObject] as [NSObject : AnyObject] as? [NSAttributedString.Key : Any], for: UIControl.State.normal)

        
        self.ContainerMensajes.isHidden = false
        self.ContainerOficinas.isHidden = true
        
        // Do any additional setup after loading the view, typically from a nib.
        
        
//        self.setupKeyboardDismissRecognizer()
        
//        self.tableData.delegate = self
//        self.tableData.dataSource = self
//
//        // Connect data:
//        self.picker.delegate = self
//        self.picker.dataSource = self
//
//        self.picker.isHidden = true
//
        
//        let customView = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 60))
//        customView.backgroundColor = UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
//        let button = UIButton(frame: CGRect(x: 10, y: 5, width: UIScreen.main.bounds.size.width - 20, height: 50))
//        button.center.x = self.view.center.x
//        button.backgroundColor = UIColor(red: 164/255, green: 203/255, blue: 82/255, alpha: 1)
//        button.setTitle("Buscar", for: .normal)
//        button.setTitleColor(UIColor.black, for: .normal)
//        button.layer.cornerRadius = 5.0
//        button.layer.shadowColor = UIColor.black.cgColor
//        button.layer.shadowOpacity = 0.2
//        button.layer.shadowOffset = CGSize.zero
//        button.layer.shadowRadius = 2
//        button.addTarget(self, action: #selector(enterAction), for: .touchUpInside)
//        customView.addSubview(button)
//
//        tableData.tableFooterView = customView
//
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
        
//        self.view.showHUD(inView: self.view)
//        self.callWSProvincias()
    }
    
//    func callWSProvincias() {
//
//        let urlToRequest = "\(Constants.serverIP)/centros-inicio"
//        func dataRequest() {
//            let url4 = URL(string: urlToRequest)!
//            let session4 = URLSession.shared
//            let request = NSMutableURLRequest(url: url4)
//            request.httpMethod = "GET"
//            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
//
//            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
//
//                if let response = response as? HTTPURLResponse {
//
//                    switch response.statusCode {
//                    case 200:
//                        if let data = data {
//                            do {
//
//                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
//                                DispatchQueue.main.async{
//
//                                    self.datosEspecialidades = json["especialidades"] as! [Dictionary<String, AnyObject>]
//                                    self.datosProvincias = json["provincias"] as! [Dictionary<String, AnyObject>]
//                                    self.view.hideHUD()
//                                    self.picker.reloadAllComponents()
//                                }
//
//
//                            } catch let error {
//                                self.view.hideHUD()
//                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
//                                print("Error login user:", error)
//                            }
//                        }
//                        break
//                    case 204:
//                        DispatchQueue.main.async{
//                            self.view.hideHUD()
//                            self.callAlert(msg: "No se ha encontrado datos.")
//                        }
//                        break
//                    case 400:
//                        DispatchQueue.main.async{
//                            self.view.hideHUD()
//                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
//                        }
//                        break
//                    case 500:
//                        DispatchQueue.main.async{
//                            self.view.hideHUD()
//                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
//                        }
//
//                    default:
//                        break
//                    }
//                }
//
//                guard let _: Data = data, let _: URLResponse = response, error == nil else {
//                    print("*****error")
//                    return
//                }
//
//                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
//                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
//            }
//            task.resume()
//        }
//        dataRequest()
//
//    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return 1
//    }
//
//
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//
//        if isMedical {
//            return "Encuentra tu centro médico o facultativo"
//        }else {
//            return "Encuentra tu centro dental"
//        }
//    }
//
//
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        let headerView = UIView()
//        headerView.backgroundColor =  UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
//
//        let headerLabel = UILabel(frame: CGRect(x: 10, y: 10, width:
//            tableView.bounds.size.width, height: tableView.bounds.size.height))
//        headerLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 13)
//        headerLabel.textColor = UIColor.lightGray
//        if isMedical {
//            headerLabel.text = "Encuentra tu centro médico o facultativo"
//        }else {
//            headerLabel.text = "Encuentra tu centro dental"
//        }
//
//        headerLabel.sizeToFit()
//        headerView.addSubview(headerLabel)
//
//        return headerView
//    }
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//
//        if isMedical {
//            return 6
//        }else {
//            return 5
//        }
//
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//
//        let cell = tableView.dequeueReusableCell(withIdentifier: "registerUserCell", for: indexPath) as! registerUserCell
//
//        cell.detailTxt.delegate = self
//        cell.detailTxt.isSecureTextEntry = false
//
//        if isMedical {
//            if indexPath.row == 0 {
//                cell.titleLabel.text = "Especialidad"
//
//                cell.detailTxt.placeholder = ""
//                cell.detailTxt.tag = 1
//                cell.detailTxt.keyboardType = .default
//                cell.detailTxt.text = ""
//                if dataWSMed["especialidad"] != "" {
//                    cell.detailTxt.text = dataWSMed["especialidad"]
//                }
//            }else if indexPath.row == 1 {
//                cell.titleLabel.text = "Provincia"
//                cell.detailTxt.placeholder = ""
//                cell.detailTxt.tag = 2
//                cell.detailTxt.keyboardType = .default
//                cell.detailTxt.text = ""
//                if dataWSMed["provincia"] != "" {
//                    cell.detailTxt.text = dataWSMed["provincia"]
//                }
//            }else if indexPath.row == 2 {
//                cell.titleLabel.text = "Localidad"
//                cell.detailTxt.placeholder = ""
//                cell.detailTxt.tag = 3
//                cell.detailTxt.keyboardType = .default
//                cell.detailTxt.text = ""
//                if dataWSMed["localidad"] != "" {
//                    cell.detailTxt.text = dataWSMed["localidad"]
//                }
//            }else if indexPath.row == 3 {
//                cell.titleLabel.text = "C.P"
//                cell.detailTxt.placeholder = "Introduce tu código postal"
//                cell.detailTxt.tag = 4
//                cell.detailTxt.keyboardType = .numberPad
//                cell.detailTxt.text = ""
//                if dataWSMed["cp"] != "" {
//                    cell.detailTxt.text = dataWSMed["cp"]
//                }
//            }else if indexPath.row == 4 {
//                cell.titleLabel.text = "Nombre/Centro"
//                cell.detailTxt.placeholder = ""
//                cell.detailTxt.tag = 5
//                cell.detailTxt.keyboardType = .emailAddress
//                cell.detailTxt.text = ""
//                if dataWSMed["nombreCentro"] != "" {
//                    cell.detailTxt.text = dataWSMed["nombreCentro"]
//                }
//            }else if indexPath.row == 5 {
//                cell.titleLabel.text = "Prof. Sanitario"
//                cell.detailTxt.placeholder = ""
//                cell.detailTxt.tag = 6
//                cell.detailTxt.keyboardType = .emailAddress
//                cell.detailTxt.text = ""
//                if dataWSMed["profSanitario"] != "" {
//                    cell.detailTxt.text = dataWSMed["profSanitario"]
//                }
//            }
//        }else {
//            if indexPath.row == 0 {
//                cell.titleLabel.text = "Provincia"
//                cell.detailTxt.placeholder = ""
//                cell.detailTxt.tag = 2
//                cell.detailTxt.keyboardType = .default
//                cell.detailTxt.text = ""
//                if dataWSDen["provincia"] != "" {
//                    cell.detailTxt.text = dataWSDen["provincia"]
//                }
//            }else if indexPath.row == 1 {
//                cell.titleLabel.text = "Localidad"
//                cell.detailTxt.placeholder = ""
//                cell.detailTxt.tag = 3
//                cell.detailTxt.keyboardType = .default
//                cell.detailTxt.text = ""
//                if dataWSDen["localidad"] != "" {
//                    cell.detailTxt.text = dataWSDen["localidad"]
//                }
//            }else if indexPath.row == 2 {
//                cell.titleLabel.text = "C.P"
//                cell.detailTxt.placeholder = "Introduce tu código postal"
//                cell.detailTxt.tag = 4
//                cell.detailTxt.keyboardType = .numberPad
//                cell.detailTxt.text = ""
//                if dataWSDen["cp"] != "" {
//                    cell.detailTxt.text = dataWSDen["cp"]
//                }
//            }else if indexPath.row == 3 {
//                cell.titleLabel.text = "Nombre/Centro"
//                cell.detailTxt.placeholder = ""
//                cell.detailTxt.tag = 5
//                cell.detailTxt.keyboardType = .default
//                cell.detailTxt.text = ""
//                if dataWSDen["nombreCentro"] != "" {
//                    cell.detailTxt.text = dataWSDen["nombreCentro"]
//                }
//            }else if indexPath.row == 4 {
//                cell.titleLabel.text = "Prof. Sanitario"
//                cell.detailTxt.placeholder = ""
//                cell.detailTxt.tag = 6
//                cell.detailTxt.keyboardType = .default
//                cell.detailTxt.text = ""
//                if dataWSDen["profSanitario"] != "" {
//                    cell.detailTxt.text = dataWSDen["profSanitario"]
//                }
//            }
//
//        }
//
//        return cell
//    }
//
//
//
//    func textFieldDidEndEditing(_ textField: UITextField) {
//
//        switch textField.tag {
//
//        case 1:
//            if textField.text != "" {
//                dataWSMed["especialidad"] = textField.text!
//            }
//            break
//        case 2:
//
//            if isMedical {
//                if textField.text != "" {
//                    dataWSMed["provincia"] = textField.text!
//                }
//            }else {
//                if textField.text != "" {
//                    dataWSDen["provincia"] = textField.text!
//                }
//            }
//
//            break
//        case 3:
//            if isMedical {
//                if textField.text != "" {
//                    dataWSMed["localidad"] = textField.text!
//                }
//            }else {
//                if textField.text != "" {
//                    dataWSDen["localidad"] = textField.text!
//                }
//            }
//
//            break
//        case 4:
//            if isMedical {
//                if textField.text != "" {
//                    dataWSMed["cp"] = textField.text!
//                }
//            }else {
//                if textField.text != "" {
//                    dataWSDen["cp"] = textField.text!
//                }
//            }
//
//            break
//        case 5:
//            if isMedical {
//                if textField.text != "" {
//                    dataWSMed["nombreCentro"] = textField.text!
//                }
//            }else {
//                if textField.text != "" {
//                    dataWSDen["nombreCentro"] = textField.text!
//                }
//            }
//
//            break
//        case 6:
//            if isMedical {
//                if textField.text != "" {
//                    dataWSMed["profSanitario"] = textField.text!
//                }
//            }else {
//                if textField.text != "" {
//                    dataWSDen["profSanitario"] = textField.text!
//                }
//            }
//
//            break
//
//        default:
//            break
//        }
//        textField.resignFirstResponder()
//    }
//
//    func setupKeyboardDismissRecognizer(){
//        let tapRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(
//            target: self,
//            action: #selector(self.dismissKeyboard))
//
//        self.view.addGestureRecognizer(tapRecognizer)
//    }
//
//    @objc func dismissKeyboard()
//    {
//        self.picker.isHidden = true
//        view.endEditing(true)
//    }
    
//    @IBAction func enterAction(_ sender: Any) {
//
//        self.dismissKeyboard()
//
//        if self.validateFields() != ""{
//            DispatchQueue.main.async{
//                self.callAlert(msg: "Debe revisar los siguientes campos:\n\(self.validateFields())")
//            }
//        }else {
//
//            self.view.showHUD(inView: self.view)
//
//            let urlToRequest = "\(Constants.serverIP)/centros-busqueda"
//            func dataRequest() {
//                let url4 = URL(string: urlToRequest)!
//                let session4 = URLSession.shared
//                let request = NSMutableURLRequest(url: url4)
//                request.httpMethod = "POST"
//
//                request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
//
//                var paramString = ""
//                if isMedical {
//                    paramString = "especialidad=\(String(describing: dataWSMed["especialidadID"]!))&provincia=\(String(describing: dataWSMed["provinciaID"]!))&localidad=\(String(describing: dataWSMed["localidadID"]!))&cp=\(String(describing: dataWSMed["cp"]!))&nombre_centro=\(String(describing: dataWSMed["nombreCentro"]!))&profesional_sanitario=\(String(describing: dataWSMed["profSanitario"]!))"
//                }else {
//                    paramString = "provincia=\(String(describing: dataWSDen["provinciaID"]!))&localidad=\(String(describing: dataWSDen["localidadID"]!))&cp=\(String(describing: dataWSDen["cp"]!))&nombre_centro=\(String(describing: dataWSDen["nombreCentro"]!))&profesional_sanitario=\(String(describing: dataWSMed["profSanitario"]!))"
//                }
//
//
//                //request.setValue("application/json", forHTTPHeaderField: "Content-Type")
//                request.httpBody = paramString.data(using: String.Encoding.utf8, allowLossyConversion: false)
//
//                //request.httpBody = paramString.data(using: String.Encoding.utf8)
//                let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
//
//                    if let response = response as? HTTPURLResponse {
//
//                        switch response.statusCode {
//                        case 200:
//                            if let data = data {
//                                do {
//
//                                    let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
//
//                                    DispatchQueue.main.async{
//                                        self.view.hideHUD()
//
//                                    }
//                                    print(json)
//
//                                } catch let error {
//                                    self.view.hideHUD()
//                                    self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
//                                    print("Error login user:", error)
//                                }
//                            }
//                            break
//                        case 204:
//                            DispatchQueue.main.async{
//                                self.view.hideHUD()
//                                self.callAlert(msg: "No se han encontrado centros.")
//                            }
//                            break
//
//                        case 500:
//                            DispatchQueue.main.async{
//                                self.view.hideHUD()
//                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
//                            }
//
//                        default:
//                            break
//                        }
//                    }
//
//                    guard let _: Data = data, let _: URLResponse = response, error == nil else {
//                        print("*****error")
//                        return
//                    }
//
//                    //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
//                    //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
//                }
//                task.resume()
//            }
//            dataRequest()
//        }
//
//    }
//
//    func validateFields() -> String {
//
//        print(dataWSMed)
//
//        var mensaje = ""
//
//        if isMedical {
//
//            if dataWSMed["especialidad"] == "" {
//                mensaje = "Especialidad"
//            }
//
//            if dataWSMed["provincia"] == "" {
//                mensaje = mensaje + "\nProvincia"
//            }
//
//            if dataWSMed["localidad"] == "" {
//                mensaje = mensaje + "\nLocalidad"
//            }
//
//            //            if dataWSMed["nombreCentro"] == "" {
//            //                mensaje = mensaje + "\nNombre centro"
//            //            }
//            //
//            //            if dataWSMed["profSanitario"] == "" {
//            //                mensaje = mensaje + "\nProfesional sanitario"
//            //            }
//            //
//            //            if dataWSMed["cp"] == "" {
//            //                mensaje = mensaje + "\nCódigo postal"
//            //            }
//
//        }else {
//            if dataWSDen["provincia"] == "" {
//                mensaje = "Provincia"
//            }
//
//            if dataWSDen["localidad"] == "" {
//                mensaje = mensaje + "\nLocalidad"
//            }
//
//            //            if dataWSDen["nombreCentro"] == "" {
//            //                mensaje = mensaje + "\nNombre centro"
//            //            }
//            //
//            //            if dataWSDen["profSanitario"] == "" {
//            //                mensaje = mensaje + "\nProfesional sanitario"
//            //            }
//            //
//            //            if dataWSDen["cp"] == "" {
//            //                mensaje = mensaje + "\nCódigo postal"
//            //            }
//        }
//
//
//
//        return mensaje
//
//    }
//
//    func isValidEmail(email:String?) -> Bool {
//
//        guard email != nil else { return false }
//
//        let regEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
//
//        let pred = NSPredicate(format:"SELF MATCHES %@", regEx)
//        return pred.evaluate(with: email)
//    }
//
//    func isvalidDate(date:String?) -> Bool {
//
//        let dateFormatterGet = DateFormatter()
//        dateFormatterGet.dateFormat = "dd/MM/yyyy"
//
//
//        if dateFormatterGet.date(from: date!) != nil {
//            return true
//
//        } else {
//            // invalid format
//            return false
//
//        }
//
//    }
//
//    func callAlert(msg:String?) {
//        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
//        self.present(alert, animated: true)
//
//    }
//
//    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
//
//        self.activeTextField = textField
//
//        if textField.tag == 1 {
//            self.picker.reloadAllComponents()
//            self.picker.isHidden = false
//            return false
//        }else if textField.tag == 2 {
//            self.picker.reloadAllComponents()
//            self.picker.isHidden = false
//            return false
//        }else if textField.tag == 3 {
//            self.picker.reloadAllComponents()
//            self.picker.isHidden = false
//            return false
//        }
//        self.picker.isHidden = true
//        return true
//    }
//
//    func textFieldDidBeginEditing(_ textField: UITextField) {
//
//    }
//
//
//    // Number of columns of data
//    func numberOfComponents(in pickerView: UIPickerView) -> Int {
//
//        return 1
//    }
//
//    // The number of rows of data
//    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
//
//        if self.activeTextField.tag == 1 {
//            return self.datosEspecialidades.count
//        }else if self.activeTextField.tag == 2 {
//            return self.datosProvincias.count
//        }else if self.activeTextField.tag == 3 {
//            return self.datosLocalidades.count
//        }
//
//        return self.datosEspecialidades.count
//    }
//
//    // The data to return fopr the row and component (column) that's being passed in
//    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
//        if self.activeTextField.tag == 1 {
//            return self.datosEspecialidades[row]["nombre"] as? String
//        }else if self.activeTextField.tag == 2 {
//            return self.datosProvincias[row]["nombre"] as? String
//        }else if self.activeTextField.tag == 3 {
//            return self.datosLocalidades[row]["nombre"] as? String
//        }
//        return self.datosEspecialidades[row]["nombre"] as? String
//
//    }
//
//    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
//        // This method is triggered whenever the user makes a change to the picker selection.
//        // The parameter named row and component represents what was selected.
//        if self.activeTextField.tag == 1 {
//            if isMedical {
//                self.dataWSMed["especialidadID"] = String(self.datosEspecialidades[row]["id"] as! Int)
//                self.dataWSMed["especialidad"] = self.datosEspecialidades[row]["nombre"] as? String
//            }
//            //            return self.datosEspecialidades[row]["nombre"] as? String
//        }else if self.activeTextField.tag == 2 {
//            if isMedical {
//                self.dataWSMed["provinciaID"] = String(self.datosProvincias[row]["id"] as! Int)
//                self.dataWSMed["provincia"] = self.datosProvincias[row]["nombre"] as? String
//            }else {
//                self.dataWSDen["provinciaID"] = String(self.datosProvincias[row]["id"] as! Int)
//                self.dataWSDen["provincia"] = self.datosProvincias[row]["nombre"] as? String
//            }
//            self.view.showHUD(inView: self.view)
//            self.callWSLocalidades(idProvincia: String(self.datosProvincias[row]["id"] as! Int))
//        }else if self.activeTextField.tag == 3 {
//            if isMedical {
//                self.dataWSMed["localidadID"] = String(self.datosLocalidades[row]["id"] as! Int)
//                self.dataWSMed["localidad"] = self.datosLocalidades[row]["nombre"] as? String
//            }else {
//                self.dataWSDen["localidadID"] = String(self.datosLocalidades[row]["id"] as! Int)
//                self.dataWSDen["localidad"] = self.datosLocalidades[row]["nombre"] as? String
//            }
//
//        }
//        self.tableData.reloadData()
//    }
//
//    func callWSLocalidades(idProvincia : String?) {
//
//        let urlToRequest = "\(Constants.serverIP)/centros-localidad"
//        func dataRequest() {
//            let url4 = URL(string: urlToRequest)!
//            let session4 = URLSession.shared
//            let request = NSMutableURLRequest(url: url4)
//            request.httpMethod = "POST"
//            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
//            let paramString = "idProvincia=\(String(describing: idProvincia!))"
//            request.httpBody = paramString.data(using: String.Encoding.utf8)
//
//            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
//
//                if let response = response as? HTTPURLResponse {
//
//                    switch response.statusCode {
//                    case 200:
//                        if let data = data {
//                            do {
//
//                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
//                                DispatchQueue.main.async{
//
//                                    self.datosLocalidades = json["localidades"] as! [Dictionary<String, AnyObject>]
//
//                                    self.view.hideHUD()
//                                    //self.picker.reloadAllComponents()
//                                }
//
//
//                            } catch let error {
//                                self.view.hideHUD()
//                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
//                                print("Error login user:", error)
//                            }
//                        }
//                        break
//                    case 204:
//                        DispatchQueue.main.async{
//                            self.view.hideHUD()
//                            self.callAlert(msg: "No se ha encontrado datos.")
//                        }
//                        break
//                    case 400:
//                        DispatchQueue.main.async{
//                            self.view.hideHUD()
//                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
//                        }
//                        break
//                    case 500:
//                        DispatchQueue.main.async{
//                            self.view.hideHUD()
//                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
//                        }
//
//                    default:
//                        break
//                    }
//                }
//
//                guard let _: Data = data, let _: URLResponse = response, error == nil else {
//                    print("*****error")
//                    return
//                }
//
//                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
//                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
//            }
//            task.resume()
//        }
//        dataRequest()
//    }
}
