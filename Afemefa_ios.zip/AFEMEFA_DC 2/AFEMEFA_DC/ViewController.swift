//
//  ViewController.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 21/11/2018.
//  Copyright © 2018 Delta Ceti. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    //Declaracion de variables locales
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var userTxt: UITextField!
    @IBOutlet weak var passTxt: UITextField!
    @IBOutlet weak var enterBtn: UIButton!
    @IBOutlet weak var registerBtn: UIButton!
    @IBOutlet weak var legalBtn: UIButton!
    @IBOutlet weak var recoverPassBtn: UIButton!
    @IBOutlet weak var logoImg: UIImageView!
    @IBOutlet weak var descrLbl: UILabel!
    
    var usuario = ""
    var password = ""
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height / 2
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
  
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 1136:
                print("iPhone 5 or 5S or 5C")
                let notificationCenter = NotificationCenter.default
                notificationCenter.addObserver(self, selector: #selector(self.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
                notificationCenter.addObserver(self, selector: #selector(self.keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
            case 1334:
                print("iPhone 6/6S/7/8")
                
            case 2208:
                print("iPhone 6+/6S+/7+/8+")
                
            case 2436:
                print("iPhone X")
                
            default:
                print("unknown")
                let notificationCenter = NotificationCenter.default
                notificationCenter.addObserver(self, selector: #selector(self.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
                notificationCenter.addObserver(self, selector: #selector(self.keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
            }
        }
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
        self.setupKeyboardDismissRecognizer()
        
    }
    
    func goToLogin(user: String, pass: String) {
        
            // This shows how you can specify the settings/parameters instead of using the default/shared parameters
            self.view.showHUD(inView: self.view)
            
            let urlToRequest = "\(Constants.serverIP)/login"
            func dataRequest() {
                let url4 = URL(string: urlToRequest)!
                let session4 = URLSession.shared
                let request = NSMutableURLRequest(url: url4)
                request.httpMethod = "POST"
                //request.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
                //request.addValue("application/json", forHTTPHeaderField: "Accept")
                
                request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
                let paramString = "username=\(user)&password=\(pass)"
                request.httpBody = paramString.data(using: String.Encoding.utf8)
                let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                    
                    if let response = response as? HTTPURLResponse {
                        
                        switch response.statusCode {
                        case 200:
                            if let data = data {
                                do {
                                    
                                    let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                    
                                    DispatchQueue.main.async{
                                        self.view.hideHUD()
                                        
                                        
                                        
                                        if json["usuario"]!["active"]! as! String == "1" {
                                            
                                            let userDefaults = UserDefaults.standard
                                            userDefaults.set(json["usuario"]!, forKey: "user")
                                            userDefaults.set(pass, forKey: "pass")
                                            
                                            userDefaults.synchronize()
                                            
                                            
                                            
                                            self.performSegue(withIdentifier: "login_to_home", sender: nil)
                                        }else {
                                            self.callAlert(msg: "Usuario desactivado.")
                                        }
                                        
                                        
                                    }
                                    print(json)
                                    
                                } catch let error {
                                    self.view.hideHUD()
                                    self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                    print("Error login user:", error)
                                }
                            }
                            break
                        case 400:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            break
                        case 401:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Usuario o contraseña incorrectos.")
                            }
                            break
                        case 500:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            
                        default:
                            break
                        }
                    }
                    
                    guard let _: Data = data, let _: URLResponse = response, error == nil else {
                        print("*****error")
                        return
                    }
                    
                    //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
                }
                task.resume()
            }
            dataRequest()
        
    }
    
    override func viewDidLayoutSubviews() {
        self.customizeUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.passTxt.text = ""
        self.userTxt.text = ""
        
        let userDefaults = UserDefaults.standard
        let user = userDefaults.dictionary(forKey: "user")
        let pass = userDefaults.string(forKey: "pass")
        
        
        if user != nil && pass != nil{
            usuario = (user?["usuario"] as? String)!
            password = pass!
            
            self.userTxt.text = usuario
            self.passTxt.text = password
            DispatchQueue.main.async{
                self.goToLogin(user: self.usuario, pass: self.password)
            }
        }
    }

    //Customizar elementos
    func customizeUI () {
        
        
        
        self.userTxt.delegate = self
        self.passTxt.delegate = self
        
        self.enterBtn.layer.cornerRadius = 5.0
        self.viewContainer.layer.cornerRadius = 10.0
        
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 1136:
                print("iPhone 5 or 5S or 5C")
                self.logoImg.frame = CGRect(x: self.logoImg.frame.origin.x, y: 50, width: self.logoImg.frame.size.width - 30, height: self.logoImg.frame.size.height - 30)
                self.recoverPassBtn.titleLabel?.adjustsFontSizeToFitWidth = true
                self.legalBtn.titleLabel?.adjustsFontSizeToFitWidth = true
            case 1334:
                print("iPhone 6/6S/7/8")
            case 2208:
                print("iPhone 6+/6S+/7+/8+")
            case 2436:
                print("iPhone X")
                DispatchQueue.main.async{
                    self.logoImg.frame = CGRect(x: self.logoImg.frame.origin.x, y: 120, width: self.logoImg.frame.size.width, height: self.logoImg.frame.size.height)

                    self.descrLbl.frame = CGRect(x: self.descrLbl.frame.origin.x, y: self.logoImg.frame.origin.y + self.logoImg.frame.size.height + 50, width: self.descrLbl.frame.size.width, height: self.descrLbl.frame.size.height)

                    self.viewContainer.frame = CGRect(x: self.viewContainer.frame.origin.x, y: self.viewContainer.frame.origin.y - 20, width: self.viewContainer.frame.size.width, height: self.viewContainer.frame.size.height)
                }
            default:
                print("unknown")
                DispatchQueue.main.async{
                    self.logoImg.frame = CGRect(x: self.logoImg.frame.origin.x, y: 120, width: self.logoImg.frame.size.width, height: self.logoImg.frame.size.height)
                    
                    self.descrLbl.frame = CGRect(x: self.descrLbl.frame.origin.x, y: self.logoImg.frame.origin.y + self.logoImg.frame.size.height + 50, width: self.descrLbl.frame.size.width, height: self.descrLbl.frame.size.height)
                    
                    self.viewContainer.frame = CGRect(x: self.viewContainer.frame.origin.x, y: self.viewContainer.frame.origin.y - 20, width: self.viewContainer.frame.size.width, height: self.viewContainer.frame.size.height)
                }
            }
        }
    }
    
    @IBAction func enterAction(_ sender: Any) {
        
        //validate fields
        //if everything is correct, call login webservice.
        if self.validateFields() {
            
            // This shows how you can specify the settings/parameters instead of using the default/shared parameters
            self.view.showHUD(inView: self.view)
            
            let urlToRequest = "\(Constants.serverIP)/login"
            func dataRequest() {
                let url4 = URL(string: urlToRequest)!
                let session4 = URLSession.shared
                let request = NSMutableURLRequest(url: url4)
                request.httpMethod = "POST"
                //request.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
                //request.addValue("application/json", forHTTPHeaderField: "Accept")

                request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
                let paramString = "username=\(String(describing: userTxt.text!))&password=\(String(describing: passTxt.text!))"
                request.httpBody = paramString.data(using: String.Encoding.utf8)
                let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                    
                    if let response = response as? HTTPURLResponse {
                        
                        switch response.statusCode {
                            case 200:
                                if let data = data {
                                    do {
                                        
                                        let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>

                                        DispatchQueue.main.async{
                                            self.view.hideHUD()
                                            
                                            if json["usuario"]!["active"]! as! String == "1" {
                                                
                                                let userDefaults = UserDefaults.standard
                                                userDefaults.set(json["usuario"]!, forKey: "user")
                                                userDefaults.set(self.passTxt.text, forKey: "pass")
                                                
                                                userDefaults.synchronize()
                                                
                                                
                                                
                                                self.performSegue(withIdentifier: "login_to_home", sender: nil)
                                            }else {
                                                self.callAlert(msg: "Usuario desactivado.")
                                            }
                                            

                                        }
                                        print(json)
                                        
                                    } catch let error {
                                        self.view.hideHUD()
                                        self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                        print("Error login user:", error)
                                    }
                                }
                            break
                        case 400:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            break
                        case 401:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Usuario o contraseña incorrectos.")
                            }
                            break
                        case 500:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            
                            default:
                            break
                    }
                }
                    
                    guard let _: Data = data, let _: URLResponse = response, error == nil else {
                        print("*****error")
                        return
                    }
                    
//                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
//                    print("*****This is the data 4: \(dataString)") //JSONSerialization
                }
                task.resume()
            }
            dataRequest()
        }
       
    }
    
    @IBAction func recoverPassAction(_ sender: Any) {
        
        //open recovery pass view
        performSegue(withIdentifier: "login_to_recover_pass", sender: nil)
        
    }
    
    @IBAction func legalAction(_ sender: Any) {
        
        //open legal view
        performSegue(withIdentifier: "login_to_advice_segue", sender: nil)

        
    }
    
    @IBAction func registerAction(_ sender: Any) {
        
        //open register view
        performSegue(withIdentifier: "login_to_register", sender: nil)

        
    }
    
    func validateFields () -> Bool {
        
        if userTxt.text == "" {//!isValidEmail(email: userTxt.text) {
            self.callAlert(msg: "Debe escribir un usuario válido.")
            return false
        }
        
        if passTxt.text == "" {
            self.callAlert(msg: "Debe escribir una contraseña válida.")
            return false
        }

        
        return true
    }
    
    func isValidEmail(email:String?) -> Bool {
        
        guard email != nil else { return false }
        
        let regEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let pred = NSPredicate(format:"SELF MATCHES %@", regEx)
        return pred.evaluate(with: email)
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    func textFieldShouldReturn(_ scoreText: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    func setupKeyboardDismissRecognizer(){
        let tapRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(ViewController.dismissKeyboard))
        
        self.view.addGestureRecognizer(tapRecognizer)
    }
    
    @objc func dismissKeyboard()
    {
        view.endEditing(true)
    }
    
}


var red = UIColor(red: 105.0/255.0, green: 155.0/255.0, blue: 199.0/255.0, alpha: 1.0)

var hudView = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))

//var labelView = UILabel(frame: CGRect(x: 5, y: 75, width: 90, height: 20))

var indicatorView = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))

extension UIView {
    func showHUD(inView: UIView) {
        hudView.center = CGPoint(x: inView.frame.size.width/2, y: inView.frame.size.height/2)
        hudView.backgroundColor = red
        hudView.alpha = 0.9
        hudView.layer.cornerRadius = hudView.bounds.size.width/2
        
        //labelView.text = "Cargando..."
        //labelView.textColor = UIColor.white
        
        indicatorView.center = CGPoint(x: hudView.frame.size.width/2, y: hudView.frame.size.height/2)
        indicatorView.style = UIActivityIndicatorView.Style.white
        hudView.addSubview(indicatorView)
        //hudView.addSubview(labelView)
        inView.addSubview(hudView)
        indicatorView.startAnimating()
    }
    
    func hideHUD() {  hudView.removeFromSuperview()  }
}
