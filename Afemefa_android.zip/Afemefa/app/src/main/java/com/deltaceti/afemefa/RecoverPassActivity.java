package com.deltaceti.afemefa;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.Answer;
import com.deltaceti.afemefa.json.RecoverPass;
import com.deltaceti.afemefa.json.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class RecoverPassActivity extends AppCompatActivity {

    private Button recovery_pass_btn;

    private String email_str;

    private TextInputLayout email_layout;
    private TextInputEditText email_et;
    View focusView = null;

    private RequestQueue requestQueue;
    private Gson gson;
    private String endpointLogin;
    private View mProgressView;
    private View mLoginFormView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recover_pass);
        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        recovery_pass_btn = findViewById(R.id.btn_recover);
        email_layout = findViewById(R.id.email_layout);
        email_et = findViewById(R.id.email_et);

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);

        recovery_pass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attempt();
            }
        });


    }

    private void attempt(){
        email_layout.setError(null);

        email_str = email_et.getText().toString();

        boolean cancel = false;


        // Check for a valid email address.
        if (TextUtils.isEmpty(email_str)) {
            email_layout.setError(getString(R.string.empty_email));
            focusView = email_et;
            cancel = true;
        }
        /*else if (!Utils.isEmailValid(email_str)) {
            email_layout.setError(getString(R.string.invalid_email));
            focusView = email_et;
            cancel = true;
        }*/

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            if (Utils.checkConnectivity(this)) {
                Utils.showProgress(true, getApplicationContext(), mLoginFormView, mProgressView);
                requestQueue = Volley.newRequestQueue(getApplicationContext());
                gson = new GsonBuilder().serializeNulls().create();
                endpointLogin = getString(R.string.base_url).concat(getString(R.string.recover_pass_path));
                fetchPosts();
            } else {
                Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), RecoverPassActivity.this);
            }

        }
    }


    //////// POST
    private void fetchPosts() {
        StringRequest request = new StringRequest(Request.Method.POST, endpointLogin, onPostsLoaded, onPostsError)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", email_str);
                return params;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else if (response.statusCode==401) {
                    email_layout.setError(getString(R.string.invalid_user));
                    focusView = email_et;
                    focusView.requestFocus();
                    return null;
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), RecoverPassActivity.this);
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoaded = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            RecoverPass answer = gson.fromJson(response, RecoverPass.class);
            Utils.showProgress(false, getApplicationContext(), mLoginFormView, mProgressView);
            AlertDialog.Builder builder = new AlertDialog.Builder(
                    RecoverPassActivity.this, R.style.AppThemeDialog);
            builder.setCancelable(false);
            builder.setTitle("ATENCIÓN");
            builder.setMessage(answer.getMensaje());
            builder.setPositiveButton("OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int which) {
                            dialog.dismiss();
                            startActivity(new Intent(RecoverPassActivity.this, MainActivity.class));
                        }
                    });

            AlertDialog alert = builder.create();
            alert.show();
        }
    };

    private final Response.ErrorListener onPostsError = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getApplicationContext(), mLoginFormView, mProgressView);
            if (networkResponse != null && networkResponse.statusCode == 401) {
                // HTTP Status Code: 401 Unauthorized
                email_layout.setError(getString(R.string.invalid_user));
                focusView = email_et;
                focusView.requestFocus();
            }
            else {
                Utils.alertError("ATENCIÓN", getString(R.string.system_fails), RecoverPassActivity.this);
            }
            Log.e("PostActivity", error.toString());
        }
    };

}
