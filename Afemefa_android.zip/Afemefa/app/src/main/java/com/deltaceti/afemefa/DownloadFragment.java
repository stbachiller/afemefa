package com.deltaceti.afemefa;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.AnswerDownloads;
import com.deltaceti.afemefa.json.Download;
import com.deltaceti.afemefa.json.LateralText;
import com.deltaceti.afemefa.sql.DatabaseHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;


public class DownloadFragment extends Fragment {


    public static TabLayout tabLayout;
    public static ViewPager viewPager;
    public static int int_items = 2;
    private DatabaseHelper db;
    private View rootView;
    private View mProgressView;
    private View mLoginFormView;

    private String endpointDownload;
    private RequestQueue requestQueue;
    private Gson gson;
    private PrefManager prefManager;

    public DownloadFragment() {
        // Required empty public constructor
    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_download,container, false);


        tabLayout = rootView.findViewById(R.id.tab_layout);
        mLoginFormView = rootView.findViewById(R.id.login_form);
        mProgressView = rootView.findViewById(R.id.login_progress);
        tabLayout.addTab(tabLayout.newTab().setText("PÚBLICAS"));
        tabLayout.addTab(tabLayout.newTab().setText("PRIVADAS"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);


        viewPager = rootView.findViewById(R.id.pager);

        db = DatabaseHelper.getInstance(getContext());
        Utils.showProgress(true, getContext(), (View) viewPager, mProgressView);
        requestQueue = Volley.newRequestQueue(getContext());
        gson = new GsonBuilder().serializeNulls().create();
        prefManager = new PrefManager(getContext());


        endpointDownload = getString(R.string.base_url).concat(getString(R.string.download_path)).concat("/").concat(prefManager.getUserId());
        fetchPosts();



        final PagerAdapter adapter = new PagerAdapter
                (getFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        return rootView;

    }

    class PagerAdapter extends FragmentStatePagerAdapter {

        int mNumOfTabs;

        public PagerAdapter(FragmentManager fm, int NumOfTabs) {
            super(fm);
            this.mNumOfTabs = NumOfTabs;
        }

        /**
         * Return fragment with respect to Position .
         */

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new PublicDownloadFragment();
                case 1:
                    return new PrivateDownloadFragment();
            }
            return null;
        }


        @Override
        public int getCount() {
            return int_items;
        }

        /**
         * This method returns the title of the tab according to the position.
         */

        @Override
        public CharSequence getPageTitle(int position) {

            switch (position) {
                case 0:
                    String recent_news = "My Order";
                    return recent_news;
                case 1:
                    String category = "Popular Items";
                    return category;
            }
            return null;
        }
    }

    private void fetchPosts() {
        StringRequest request = new StringRequest(Request.Method.GET, endpointDownload, onPostsLoadedTextLateral, onPostsErrorTextLateral)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }


            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoadedTextLateral = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Utils.showProgress(false, getContext(), (View) viewPager, mProgressView);
            Log.i("PostActivity", response);
            AnswerDownloads answer = gson.fromJson(response, AnswerDownloads.class);
            JsonArray list_user = answer.getDescargasUsuario();
            ArrayList<Download> download_list = new ArrayList<>();
            for (int i = 0; i < list_user.size(); i++) {
                Download download = gson.fromJson(list_user.get(i), Download.class);
                Log.d("AFEMAFA", download.getFecha_creacion());
                download.setTipoUser("user");
                download_list.add(download);
            }
            JsonArray list_mutualista = answer.getDescargasMutualista();
            for (int i = 0; i < list_mutualista.size(); i++) {
                Download download = gson.fromJson(list_mutualista.get(i), Download.class);
                download.setTipoUser("mutualista");
                download_list.add(download);
            }
            db.addDownload(download_list);

            }
    };

    private final Response.ErrorListener onPostsErrorTextLateral = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getContext(), (View) viewPager, mProgressView);
            Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
            Log.e("PostActivity", error.toString());
        }
    };

}
