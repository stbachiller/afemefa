package com.deltaceti.afemefa.json;

import com.google.gson.JsonElement;

/**
 * Created by arr375 on 13/02/2017.
 */

public class RecoverPass {

    private String mensaje;
    private String resultado;


    public String getMensaje() {
        return mensaje;
    }

    public String getResultado() {
        return resultado;
    }
}
