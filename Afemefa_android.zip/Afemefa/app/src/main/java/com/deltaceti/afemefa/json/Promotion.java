package com.deltaceti.afemefa.json;

import java.io.Serializable;

/**
 * Created by arr375 on 13/02/2017.
 */

public class Promotion implements Serializable {

    private String titulo;
    private String texto;
    private String url_imagen;
    private String url_contenido;

    public Promotion(String titulo, String texto, String url_imagen, String url_contenido) {
        this.titulo = titulo;
        this.texto = texto;
        this.url_imagen = url_imagen;
        this.url_contenido = url_contenido;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getTexto() {
        return texto;
    }

    public String getUrl_imagen() {
        return url_imagen;
    }

    public String getUrl_contenido() {
        return url_contenido;
    }
}
