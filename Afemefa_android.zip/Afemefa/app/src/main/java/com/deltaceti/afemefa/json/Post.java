package com.deltaceti.afemefa.json;

import com.google.gson.JsonArray;

import java.io.Serializable;

/**
 * Created by arr375 on 13/02/2017.
 */

public class Post implements Serializable {

    private String id;
    private String titulo;
    private String url_imagen_destacada;
    private String contenidoPlano;
    private String contenido;
    private String fecha_creacion;
    private String fecha_modificacion;

    public Post(String id, String titulo, String url_imagen_destacada, String contenidoPlano, String fecha_creacion, String fecha_modificacion) {
        this.id = id;
        this.titulo = titulo;
        this.url_imagen_destacada = url_imagen_destacada;
        this.contenidoPlano = contenidoPlano;
        this.fecha_creacion = fecha_creacion;
        this.fecha_modificacion = fecha_modificacion;
    }

    public String getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getUrl_imagen_destacada() {
        return url_imagen_destacada;
    }

    public String getContenidoPlano() {
        return contenidoPlano;
    }

    public String getContenido() {
        return contenido;
    }

    public String getFecha_creacion() {
        return fecha_creacion;
    }

    public String getFecha_modificacion() {
        return fecha_modificacion;
    }
}
