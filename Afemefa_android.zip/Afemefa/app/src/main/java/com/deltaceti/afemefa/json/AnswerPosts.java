package com.deltaceti.afemefa.json;

import com.google.gson.JsonArray;

/**
 * Created by arr375 on 13/02/2017.
 */

public class AnswerPosts {

    private String mensaje;
    private JsonArray datos;
    private String url_blog;

    public JsonArray getDatos() {
        return datos;
    }
    public String getUrlBlog() { return url_blog; }
}
