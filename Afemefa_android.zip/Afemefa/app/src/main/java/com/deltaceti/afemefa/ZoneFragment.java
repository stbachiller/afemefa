package com.deltaceti.afemefa;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.LateralText;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ZoneFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link ZoneFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ZoneFragment extends Fragment {

    private LinearLayout edit_profile_ll, promotions_ll, authorizations_ll, claims_ll;
    //private ListView listview;
    //private TextView insurances_tv;
    private String endpointTextLateral="";
    private PrefManager pref_manager;
    private Gson gson;
    private RequestQueue requestQueue;
    private View mLoginFormView, mProgressView;
    private ListView list_view;


    public ZoneFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_zone, container, false);
        edit_profile_ll = v.findViewById(R.id.edit_profile_ll);
        promotions_ll = v.findViewById(R.id.promotions_ll);
        authorizations_ll = v.findViewById(R.id.authorization_ll);
        claims_ll = v.findViewById(R.id.claims_ll);

        //insurances_tv = v.findViewById(R.id.innsurances_tv);
        mLoginFormView = v.findViewById(R.id.login_form);
        mProgressView = v.findViewById(R.id.login_progress);
        list_view = v.findViewById(R.id.list);

        gson = new GsonBuilder().serializeNulls().create();
        pref_manager = new PrefManager(getContext());


        requestQueue = Volley.newRequestQueue(getContext());

        //if (pref_manager.getMenuLateralText().compareTo("defaultStringIfNothingFound")==0) {
        endpointTextLateral = getString(R.string.base_url).concat(getString(R.string.lateral_text_path)).concat("/").concat(pref_manager.getUserId());
        Utils.showProgress(true, getContext(), mLoginFormView, mProgressView);
        //TEXTO LATERAL
        fetchPostsTextLateral();
        //} else {
          //  insurances_tv.setText(Html.fromHtml(pref_manager.getMenuLateralText()));
        //}

//        listview = v.findViewById(R.id.item_list);
//
//        /// Getting list of Strings from your resource
//        List<String> testList = new ArrayList<>();
//        testList.add("Salud Estandar");
//        testList.add("Salud joven");
//        testList.add("Suplemento Decesos");
//        testList.add("Suplemento Dental");
//        testList.add("Salud Premium");
//
//        // Instanciating Adapter
//        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity().getApplicationContext(),
//                android.R.layout.simple_list_item_1, testList);
//
//        // setting adapter on listview
//        listview.setAdapter(adapter);

        edit_profile_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), EditProfileActivity.class));
            }
        });

        promotions_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), PromotionActivity.class));
            }
        });

        authorizations_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), AuthorizationActivity.class));
            }
        });

        claims_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), ClaimsActivity.class));
            }
        });
        return v;
    }


    private void fetchPostsTextLateral() {
        StringRequest request = new StringRequest(Request.Method.GET, endpointTextLateral, onPostsLoadedTextLateral, onPostsErrorTextLateral)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }


            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    //Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoadedTextLateral = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            LateralText answer = gson.fromJson(response, LateralText.class);

            Type type = new TypeToken<List<String>>(){}.getType();
            List<String> list = gson.fromJson(answer.getTexto(), type ); //convert List to Array in Java String [] strArray = list.toArray(new String[0]);

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),
                    android.R.layout.simple_list_item_1, android.R.id.text1,
                    list.toArray(new String[list.size()]));
            list_view.setAdapter(adapter);
            //insurances_tv.setText(Html.fromHtml(answer.getTexto()));

        }
    };

    private final Response.ErrorListener onPostsErrorTextLateral = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            //Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
            Log.e("PostActivity", error.toString());
        }
    };
}
