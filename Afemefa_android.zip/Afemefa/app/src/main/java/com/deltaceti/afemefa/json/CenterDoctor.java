package com.deltaceti.afemefa.json;

import java.io.Serializable;

/**
 * Created by arr on 01/11/2017.
 */

public class CenterDoctor implements Serializable {

    private Integer id;
    private String nombre_centro;
    private String profesional_sanitario;
    private String direccion;
    private String telefono;
    private String web;
    private String observaciones;
    private String url;
    private String provincia;
    private String localidad;
    private String especialidad;
    private String coordenadas;

    public Integer getId() {
        return id;
    }

    public String getNombre_centro() {
        return nombre_centro;
    }

    public String getProfesional_sanitario() {
        return profesional_sanitario;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getWeb() {
        return web;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public String getUrl() {
        return url;
    }

    public String getProvincia() {
        return provincia;
    }

    public String getLocalidad() {
        return localidad;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public String getCoordenadas() {
        return coordenadas;
    }
}
