package com.deltaceti.afemefa.list;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.deltaceti.afemefa.R;
import com.deltaceti.afemefa.json.Download;
import com.deltaceti.afemefa.json.Post;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by arr375 on 14/02/2017.
 */

public class PostAdapter extends ArrayAdapter<Post> implements View.OnClickListener {
    //implements View.OnClickListener
    private ArrayList<Post> downloads;
    Context mContext;




    // View lookup cache
    private static class ViewHolder {
        ImageView image;
        TextView date;
        TextView title;
        TextView text;
    }

    public PostAdapter(ArrayList<Post> data, Context context) {
        super(context, R.layout.row_post, data);
        this.downloads = data;
        this.mContext = context;

    }

    @Override
    public void onClick(View v) {

        int position = (Integer) v.getTag();


//        Object object = getItem(position);
//        Event event = (Event) object;
//
//
//        Intent intent = new Intent();
//        intent.putExtra("Event", event);
//        intent.setClass(v.getContext(), EventActivity.class);
//        v.getContext().startActivity(intent);


    }

    private int lastPosition = -1;

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // Get the data item for this position

        // Check if an existing view is being reused, otherwise inflate the view
        //ViewHolder viewHolder; // view lookup cache stored in tag
        final ViewHolder holder;



        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.row_post, parent, false);
            holder = new ViewHolder();


            holder.image = (ImageView) convertView.findViewById(R.id.image);
            holder.date = (TextView) convertView.findViewById(R.id.date_tv);
            holder.title = (TextView) convertView.findViewById(R.id.title_tv);
            holder.text = (TextView) convertView.findViewById(R.id.text_tv);


            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Post post = getItem(position);

        Log.d("AFEMEFA", post.getFecha_creacion());

                //dataSet.get(position);

        //Animation animation = AnimationUtils.loadAnimation(mContext, (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);
        //result.startAnimation(animation);
        //lastPosition = position


        try {
            Picasso.with(this.mContext).load(post.getUrl_imagen_destacada()).into(holder.image);
            holder.date.setText(post.getFecha_creacion());
            holder.title.setText(post.getTitulo());
            holder.text.setText(post.getContenidoPlano());
        } catch (Exception e) {

        }


        //viewHolder.foto.setImageBitmap(bitmap);
        // Return the completed view to render on screen
        return convertView;
    }


}
