package com.deltaceti.afemefa.list;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.deltaceti.afemefa.R;
import com.deltaceti.afemefa.json.Post;
import com.deltaceti.afemefa.json.Promotion;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by arr375 on 14/02/2017.
 */

public class PromotionAdapter extends ArrayAdapter<Promotion> implements View.OnClickListener {
    //implements View.OnClickListener
    private ArrayList<Promotion> promotions;
    Context mContext;




    // View lookup cache
    private static class ViewHolder {
        ImageView image;
        TextView title;
        TextView text;
    }

    public PromotionAdapter(ArrayList<Promotion> data, Context context) {
        super(context, R.layout.row_promotion, data);
        this.promotions = data;
        this.mContext = context;

    }

    @Override
    public void onClick(View v) {

        int position = (Integer) v.getTag();


//        Object object = getItem(position);
//        Event event = (Event) object;
//
//
//        Intent intent = new Intent();
//        intent.putExtra("Event", event);
//        intent.setClass(v.getContext(), EventActivity.class);
//        v.getContext().startActivity(intent);


    }

    private int lastPosition = -1;

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // Get the data item for this position

        // Check if an existing view is being reused, otherwise inflate the view
        //ViewHolder viewHolder; // view lookup cache stored in tag
        final ViewHolder holder;



        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.row_promotion, parent, false);
            holder = new ViewHolder();


            holder.image = (ImageView) convertView.findViewById(R.id.image);
            holder.title = (TextView) convertView.findViewById(R.id.title_tv);
            holder.text = (TextView) convertView.findViewById(R.id.text_tv);


            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Promotion promotion = getItem(position);

        Log.d("AFEMEFA", promotion.getTitulo());

                //dataSet.get(position);

        //Animation animation = AnimationUtils.loadAnimation(mContext, (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);
        //result.startAnimation(animation);
        //lastPosition = position


        try {
            Picasso.with(this.mContext).load(promotion.getUrl_imagen()).into(holder.image);
            holder.title.setText(promotion.getTitulo());
            holder.text.setText(promotion.getTexto());
        } catch (Exception e) {

        }


        //viewHolder.foto.setImageBitmap(bitmap);
        // Return the completed view to render on screen
        return convertView;
    }


}
