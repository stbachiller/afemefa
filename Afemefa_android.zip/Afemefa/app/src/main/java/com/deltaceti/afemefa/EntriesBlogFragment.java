package com.deltaceti.afemefa;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.AnswerDownloads;
import com.deltaceti.afemefa.json.AnswerPosts;
import com.deltaceti.afemefa.json.Download;
import com.deltaceti.afemefa.json.LateralText;
import com.deltaceti.afemefa.json.Post;
import com.deltaceti.afemefa.list.PostAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link EntriesBlogFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link EntriesBlogFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EntriesBlogFragment extends Fragment {

    private String endpointBlogEntries, endpointSlider;
    private PrefManager pref_manager;
    private Gson gson;
    private RequestQueue requestQueue;
    private View mLoginFormView, mProgressView;
    private LinearLayout background_ll;

    private static PostAdapter adapter;
    private AnswerPosts answer = null;

    private String link_string = "", url_blog = "";

    private ListView post_listview;
    private ArrayList<Post> posts_list;
    private TextView see_more_tv, title_tv, text_tv;

    public EntriesBlogFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_blog_entries, container, false);

        post_listview = v.findViewById(R.id.list);

        mLoginFormView = v.findViewById(R.id.login_form);
        mProgressView = v.findViewById(R.id.login_progress);
        see_more_tv = v.findViewById(R.id.see_more_tv);
        title_tv = v.findViewById(R.id.title_tv);
        text_tv = v.findViewById(R.id.text_tv);
        background_ll = v.findViewById(R.id.background_ll);


        gson = new GsonBuilder().serializeNulls().create();
        pref_manager = new PrefManager(getContext());
        requestQueue = Volley.newRequestQueue(getContext());

        //NavigationView hola = getActivity().findViewById(R.id.navview);

        endpointSlider = getString(R.string.base_url).concat(getString(R.string.slider_path));
        Utils.showProgress(true, getContext(), mLoginFormView, mProgressView);
        fetchPostsSlider();

        Long timestamp_now = System.currentTimeMillis();
        if (pref_manager.getTimeStampPosts()!=0){
            if((timestamp_now - pref_manager.getTimeStampPosts())>300000){
                endpointBlogEntries = getString(R.string.base_url).concat(getString(R.string.posts_path));
                //hola.setVisibility(View.GONE);
                Utils.showProgress(true, getContext(), mLoginFormView, mProgressView);
                fetchPosts();
            } else {
                String value = pref_manager.getPOSTS();
                Type listType = new TypeToken<ArrayList<Post>>(){}.getType();
                posts_list = gson.fromJson(value, listType);
                url_blog = pref_manager.getUrlBlog();
                fill_list(posts_list);
            }
        } else {
            requestQueue = Volley.newRequestQueue(getContext());
            endpointBlogEntries = getString(R.string.base_url).concat(getString(R.string.posts_path));
            Utils.showProgress(true, getContext(), mLoginFormView, mProgressView);
            fetchPosts();
        }

        see_more_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (url_blog.compareTo("")!=0) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url_blog));
                    startActivity(i);
                }
            }
        });

        background_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (link_string.compareTo("")!=0) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(link_string));
                    startActivity(i);
                }
            }
        });



        post_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Post post = posts_list.get(position);
                Bundle bundle=new Bundle();
                bundle.putSerializable("post", post);
                Intent intent = new Intent(getActivity(), BlogEntryActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });


//        listview = v.findViewById(R.id.item_list);
//
//        /// Getting list of Strings from your resource
//        List<String> testList = new ArrayList<>();
//        testList.add("Salud Estandar");
//        testList.add("Salud joven");
//        testList.add("Suplemento Decesos");
//        testList.add("Suplemento Dental");
//        testList.add("Salud Premium");
//
//        // Instanciating Adapter
//        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity().getApplicationContext(),
//                android.R.layout.simple_list_item_1, testList);
//
//        // setting adapter on listview
//        listview.setAdapter(adapter);


        return v;
    }


    private void fetchPosts() {
        StringRequest request = new StringRequest(Request.Method.GET, endpointBlogEntries, onPostsLoadedTextLateral, onPostsErrorTextLateral)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }


            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoadedTextLateral = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);

            answer = gson.fromJson(response, AnswerPosts.class);
            //pref_manager.setMenuLateralText(answer.getTexto());
            JsonArray list_posts = answer.getDatos();
            posts_list = new ArrayList<>();
            for (int i = 0; i < list_posts.size(); i++) {
                Post post = gson.fromJson(list_posts.get(i), Post.class);
                Log.d("AFEMAFA", post.getTitulo());
                posts_list.add(post);
            }

            pref_manager.setPosts(gson.toJson(posts_list));
            url_blog = answer.getUrlBlog();
            pref_manager.setUrlBlog(url_blog);
            pref_manager.setTimeStampPosts(System.currentTimeMillis());
            fill_list(posts_list);
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            /*answer = gson.fromJson(response, Answer.class);
            try{
                startActivity(new Intent(MainActivity.this, MenuActivity.class));
            } catch (JsonParseException e) {
                Utils.alertErrorProfessional("ATENCIÓN", getString(R.string.system_fails), ProfessionalLoginActivity.this);
            }*/
        }
    };

    private final Response.ErrorListener onPostsErrorTextLateral = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
            Log.e("PostActivity", error.toString());
        }
    };


    private void fetchPostsSlider() {
        StringRequest request = new StringRequest(Request.Method.GET, endpointSlider, onPostsLoaded, onPostsError)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }


            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoaded = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);


            JsonObject root = gson.fromJson(response, JsonObject.class);
            JsonObject element = root.get("android").getAsJsonObject().get("1").getAsJsonObject();
            String title_string =  element.get("titulo").getAsString();
            String text_string =  element.get("texto").getAsString();
            link_string =  element.get("enlace").getAsString();
            Log.i("PostActivity", title_string);
            Log.i("PostActivity", text_string);
            Log.i("PostActivity", link_string);
            String url_image_string = element.get("imagenes").getAsJsonObject().get("ST").getAsString();
            Log.i("PostActivity", url_image_string);

            /*try {
                URL imageUrl = new URL(url_image_string);
                Bitmap bitmap = BitmapFactory.decodeStream(imageUrl.openConnection().getInputStream());
                BitmapDrawable background = new BitmapDrawable(getResources(), bitmap);
                background_ll.setBackground(new BitmapDrawable(getActivity().getResources(), result));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }*/
            text_tv.setText(text_string);
            title_tv.setText(title_string);


            final ImageView img = new ImageView(getContext());
            Picasso.with(img.getContext()).load(url_image_string).into(img, new com.squareup.picasso.Callback() {
                @Override
                public void onSuccess() {
                    background_ll.setBackground(img.getDrawable());
                }

                @Override
                public void onError() {
                }
            });


            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);

        }
    };

    private final Response.ErrorListener onPostsError = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
            Log.e("PostActivity", error.toString());
        }
    };

    private void fill_list(ArrayList<Post> posts_list){
        adapter = new PostAdapter(posts_list, getContext());
        post_listview.setAdapter(adapter);
    }
}
