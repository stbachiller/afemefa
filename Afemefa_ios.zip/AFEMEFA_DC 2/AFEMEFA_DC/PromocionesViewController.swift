//
//  PromocionesViewController.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 16/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import  UIKit

class PromocionesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tablePromociones: UITableView!
    var datosPromociones : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        self.tablePromociones.delegate = self
        self.tablePromociones.dataSource = self
        
        self.tablePromociones.rowHeight = UITableView.automaticDimension
        self.tablePromociones.estimatedRowHeight = 250
        
        self.view.showHUD(inView: self.view)
         self.callWSPromociones()
         
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    
    
    func callWSPromociones() {
        
        
        let urlToRequest = "\(Constants.serverIP)/promociones"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "GET"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                DispatchQueue.main.async{
                                    
                                    //print(json["pagina"] as! Dictionary<String, AnyObject>)
                                    self.datosPromociones = json["promociones"] as! [Dictionary<String, AnyObject>]
                                    self.view.hideHUD()
                                    self.tablePromociones.reloadData()
                                }
                                
                            } catch let error {
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 204:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se ha encontrado la página indicada.")
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 237
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 237//UITableView.automaticDimension
    }
    
    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return "Promociones exclusivas para mutualistas"
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor =  UIColor.clear//(red: 239/255, green: 239/255, blue: 244/255, alpha: 1)
        
        let headerLabel = UILabel(frame: CGRect(x: 0, y: 20, width:
            tableView.bounds.size.width, height: tableView.bounds.size.height))
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 13)
        headerLabel.textColor = UIColor.lightGray
        headerLabel.text = "Promociones exclusivas para mutualistas"
        headerLabel.sizeToFit()
        headerView.addSubview(headerLabel)
        
        return headerView
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return datosPromociones.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PromocionesCellID", for: indexPath) as! PromocionesCell
        
        let promocion = self.datosPromociones[indexPath.row]
        cell.labelTxt.text = promocion["texto"] as? String
        cell.labelTxt.sizeToFit()
        cell.titleTxt.text = promocion["titulo"] as? String
        cell.imageCell.downloaded(from: (promocion["url_imagen"] as? String)!)
        cell.imageCell.clipsToBounds = true
        cell.imageCell.layer.cornerRadius = 5.0
        
        
        cell.imageCell.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        //cell.viewContainer.clipsToBounds = true
        cell.viewContainer.layer.shadowColor = UIColor.black.cgColor
        cell.viewContainer.layer.shadowOpacity = 0.5
        cell.viewContainer.layer.shadowOffset = CGSize.zero
        cell.viewContainer.layer.shadowRadius = 3
        cell.viewContainer.layer.cornerRadius = 5.0
        cell.viewContainer.layer.borderWidth = 0.1
        
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 1136:
                print("iPhone 5 or 5S or 5C")
                cell.imageCell.contentMode = .scaleAspectFit
                break
                
            case 1334:
                print("iPhone 6/6S/7/8")
                cell.imageCell.contentMode = .scaleAspectFill
                break
                
            case 2208:
                print("iPhone 6+/6S+/7+/8+")
                cell.imageCell.contentMode = .scaleAspectFill
                
                break
            case 2436:
                print("iPhone X")
                cell.imageCell.contentMode = .scaleAspectFill
                
                break
                
            default:
                print("unknown")
                cell.imageCell.contentMode = .scaleAspectFill
                
                
            }
        }
        
    
 
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        tableView.deselectRow(at: indexPath, animated: true)
        
        let promocion = self.datosPromociones[indexPath.row]

        guard let url = URL(string: (promocion["url_contenido"] as? String)!) else { return }
        UIApplication.shared.open(url)
    }
    
    
}

//extension UIImageView {
//    func downloaded(from url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFill) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
//        contentMode = mode
//        URLSession.shared.dataTask(with: url) { data, response, error in
//            guard
//                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
//                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
//                let data = data, error == nil,
//                let image = UIImage(data: data)
//                else { return }
//            DispatchQueue.main.async() {
//                self.image = image
//            }
//            }.resume()
//    }
//    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleAspectFill) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
//        guard let url = URL(string: link) else { return }
//        downloaded(from: url, contentMode: mode)
//    }
//
//
//
//
//}
