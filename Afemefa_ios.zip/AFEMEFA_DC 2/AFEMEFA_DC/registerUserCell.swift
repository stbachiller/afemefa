//
//  registerUserCell.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 25/11/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit

class registerUserCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var asterizco: UILabel!
    @IBOutlet weak var detailTxt: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
