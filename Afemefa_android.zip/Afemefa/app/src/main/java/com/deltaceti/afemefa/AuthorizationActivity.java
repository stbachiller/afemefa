package com.deltaceti.afemefa;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.MessageResponse;
import com.deltaceti.afemefa.json.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class AuthorizationActivity extends AppCompatActivity {

    private TextInputLayout message_1_layout, message_2_layout;
    private TextInputEditText message_1_et, message_2_et;
    private String message_1_str, message_2_str, file_base64_str="", autenticity_str = "0";
    private Button send_btn;
    private ScrollView scrollview;
    private View mProgressView;
    private CheckBox autenticity_cb;

    private LinearLayout attachment_ly, attachment_ly_2;
    private ImageView file_ext_im, file_delete_im;
    private TextView file_name_tv, autenticity_tv;
    private static final int REQUEST_BROWSE = 100, PETICION_PERMISO_ALMACENAMIENTO=200;

    private RequestQueue requestQueue;
    private Gson gson;
    private String endpointAuthorization;
    private PrefManager pref_manager;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authorization);
        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        send_btn = findViewById(R.id.btn_send);

        message_1_layout = findViewById(R.id.message_1_layout);
        message_2_layout = findViewById(R.id.message_2_layout);

        message_1_et = findViewById(R.id.message_1_et);
        message_2_et = findViewById(R.id.message_2_et);

        scrollview = findViewById(R.id.scrollView1);
        mProgressView = findViewById(R.id.login_progress);
        attachment_ly = findViewById(R.id.attachment_ly);

        attachment_ly_2 = findViewById(R.id.attachment_ly_2);
        file_ext_im = findViewById(R.id.file_ext_im);
        file_name_tv = findViewById(R.id.file_name_tv);
        file_delete_im = findViewById(R.id.file_delete_im);

        autenticity_cb = findViewById(R.id.autenticity_cb);
        autenticity_tv = findViewById(R.id.autenticity_tv);

        endpointAuthorization = getString(R.string.base_url).concat(getString(R.string.authorization_path));
        pref_manager = new PrefManager(this);

        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptSend();
            }
        });


        attachment_ly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Afemafa", "CLICK");
                if (ContextCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED) {
                    attemptSelectFile();
                } else {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            PETICION_PERMISO_ALMACENAMIENTO);
                }
            }
        });

        file_delete_im.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attachment_ly_2.setVisibility(View.GONE);
                attachment_ly.setVisibility(View.VISIBLE);
            }
        });
    }

    private void attemptSend(){
        message_1_layout.setError(null);
        message_2_layout.setError(null);

        message_1_str = message_1_et.getText().toString();
        message_2_str = message_2_et.getText().toString();

        autenticity_tv.setVisibility(View.GONE);

        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(message_2_str)) {
            message_2_layout.setError(getString(R.string.empty_generic));
            focusView = message_2_et;
            cancel = true;
        }
        if (TextUtils.isEmpty(message_1_str)) {
            message_1_layout.setError(getString(R.string.empty_generic));
            focusView = message_1_et;
            cancel = true;
        }
        if (!autenticity_cb.isChecked()){
            autenticity_tv.setVisibility(View.VISIBLE);
            focusView = autenticity_cb;
            cancel = true;
        }
        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
            scrollview.scrollTo(0, focusView.getBottom());
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            if (Utils.checkConnectivity(this)) {
                Utils.showProgress(true, getApplicationContext(), scrollview, mProgressView);
                gson = new GsonBuilder().serializeNulls().create();
                requestQueue = Volley.newRequestQueue(getApplicationContext());
                user = gson.fromJson(pref_manager.getUserInfo(), User.class);
                fetchPosts();
            } else {
                Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), AuthorizationActivity.this);
            }

        }
    }

    void attemptSelectFile(){
        Intent intent = new Intent();
        intent.setType("*/*");
        intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        String[] mimetypes = { "application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/pdf", "image/jpeg", "image/jpg"};
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimetypes);
        startActivityForResult(intent, REQUEST_BROWSE);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(AuthorizationActivity.this, MenuActivity.class);
                //PrefManager prefManager = new PrefManager(MenuActivity.this);
                //prefManager.setId("defaultStringIfNothingFound");
                startActivity(intent);
                finish();
                //super.onBackPressed();
                break;
        }
        return true;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_BROWSE
                && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                Log.d("Afemafa", uri.toString());
                Cursor cursor = this.getContentResolver().query(uri,
                        null, null, null, null);
                cursor.moveToFirst();
                long size = cursor.getLong(cursor.getColumnIndex(OpenableColumns.SIZE));
                String file_name = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));

                cursor.close();
                Log.d("Afemafa", String.valueOf(size));
                Log.d("Afemafa", file_name);

                String base64_encoding = "data:image/jpeg;base64,";
                if (size > 4800000){
                    Utils.alertError("ATENCIÓN", "El tamaño del archivo sobrepasa los 4MB.", AuthorizationActivity.this);
                } else {
                    String ext = "";

                    if (file_name.contains("."))
                        ext = file_name.substring(file_name.lastIndexOf('.'));
                    Log.d("Afemafa", ext);
                    if (ext.compareTo(".pdf")==0) {
                        file_ext_im.setImageResource(R.mipmap.icon_pdf);
                        base64_encoding = "data:application/pdf;base64,";
                    } else if (ext.compareTo(".doc")==0) {
                        file_ext_im.setImageResource(R.mipmap.icon_word);
                        base64_encoding = "data:application/msword;base64,";
                    }

                    file_name_tv.setText(file_name);
                    attachment_ly.setVisibility(View.GONE);
                    attachment_ly_2.setVisibility(View.VISIBLE);
                }
                try {
                    file_base64_str = base64_encoding.concat(Utils.convertToBase64(uri, getApplicationContext()));
                    Log.d("AFEMAFA", file_base64_str);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }



            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PETICION_PERMISO_ALMACENAMIENTO: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    this.attemptSelectFile();

                    return;
                }

                // other 'case' lines to check for other
                // permissions this app might request
            }
        }
    }

    //////// POST
    private void fetchPosts() {
        StringRequest request = new StringRequest(Request.Method.POST, endpointAuthorization, onPostsLoaded, onPostsError)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("asunto", message_1_str);
                params.put("mensaje", message_2_str);
                params.put("autenticidad", "1");
                params.put("adjunto", file_base64_str);
                params.put("hidden-firstname", user.getNombre());
                params.put("hidden-lastname", "");
                params.put("hidden-login", user.getUsuario());
                params.put("hidden-email", user.getEmail());
                Log.d("PostActivity", params.toString());
                return params;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), AuthorizationActivity.this);
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoaded = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            MessageResponse answer = gson.fromJson(response, MessageResponse.class);
            //User user = gson.fromJson(answer.getData(), User.class);
            Utils.showProgress(false, getApplicationContext(), scrollview, mProgressView);
            Utils.alertError("ATENCIÓN", answer.getMensaje(), AuthorizationActivity.this);
        }
    };

    private final Response.ErrorListener onPostsError = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getApplicationContext(), scrollview, mProgressView);
            Utils.alertError("ATENCIÓN", getString(R.string.system_fails), AuthorizationActivity.this);
            Log.e("PostActivity", error.toString());
        }
    };
}
