package com.deltaceti.afemefa;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Build;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.Answer;
import com.deltaceti.afemefa.json.LateralText;
import com.deltaceti.afemefa.json.Login;
import com.deltaceti.afemefa.json.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Button access_btn, register_btn;

    private TextInputLayout user_layout, pass_layout;
    private TextInputEditText user_et, pass_et;

    private TextView user_conditions_tv, recover_pass_tv;

    private String user_str, pass_str;

    private RequestQueue requestQueue;
    private Gson gson;
    private String requestBody;
    private String endpointLogin, endpointTextLateral;
    private Answer answer;

    private View focusView = null;
    private View mProgressView;
    private View mLoginFormView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        access_btn = findViewById(R.id.btn_access);
        register_btn = findViewById(R.id.btn_register);

        user_layout = findViewById(R.id.user_layout);
        pass_layout = findViewById(R.id.pass_layout);

        user_et = findViewById(R.id.user_et);
        pass_et = findViewById(R.id.pass_et);

        user_conditions_tv = findViewById(R.id.user_conditions_tv);
        recover_pass_tv = findViewById(R.id.recover_pass_tv);

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);

        access_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    attemptLogin();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        register_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));
            }
        });

        recover_pass_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, RecoverPassActivity.class));
            }
        });

        user_conditions_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, UserConditionsActivity.class));
            }
        });

    }

    private void attemptLogin() throws JSONException {
        user_layout.setError(null);
        pass_layout.setError(null);

        user_str = user_et.getText().toString();
        pass_str = pass_et.getText().toString();

        boolean cancel = false;


        // Check for a valid password, if the user entered one.
        if (TextUtils.isEmpty(pass_str)) {
            pass_layout.setError(getString(R.string.empty_pass));
            focusView = pass_et;
            cancel = true;
        } else if(!Utils.isPasswordValid(pass_str)){
            pass_layout.setError(getString(R.string.invalid_pass));
            focusView = pass_et;
            cancel = true;
        }

        // Check for a valid user name.
        if (TextUtils.isEmpty(user_str)) {
            user_layout.setError(getString(R.string.empty_user));
            focusView = user_et;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.

            if (Utils.checkConnectivity(this)) {
                Utils.showProgress(true, getApplicationContext(), mLoginFormView, mProgressView);
                requestQueue = Volley.newRequestQueue(getApplicationContext());
                gson = new GsonBuilder().serializeNulls().create();
                /*Login login = new Login(user_str, pass_str);
                requestBody = gson.toJson(login);*/



                endpointLogin = getString(R.string.base_url).concat(getString(R.string.login_path));
                fetchPosts();
                //startActivity(new Intent(MainActivity.this, MenuActivity.class));
            } else {
                Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), MainActivity.this);
            }
        }
    }


    //////// POST
    private void fetchPosts() {
        StringRequest request = new StringRequest(Request.Method.POST, endpointLogin, onPostsLoaded, onPostsError)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", user_str);
                params.put("password", pass_str);
                return params;
            }


            /*@Override
            public byte[] getBody() throws AuthFailureError {

                Log.i("PostActivity", requestBody);
                return requestBody == null ? null : requestBody.getBytes();

            }*/

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else if (response.statusCode==401) {
                    user_layout.setError(getString(R.string.invalid_user));
                    focusView = user_et;
                    focusView.requestFocus();
                    return null;
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), MainActivity.this);
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoaded = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            answer = gson.fromJson(response, Answer.class);
            User user = gson.fromJson(answer.getData(), User.class);

            if (user.getActive().compareTo("1") == 0) {
                Log.d("PostActivity", user.getFecha_nacimiento());
                PrefManager prefManager = new PrefManager(getApplicationContext());
                prefManager.setUserInfo(gson.toJson(user));
                prefManager.setUserId(user.getId());
                startActivity(new Intent(MainActivity.this, MenuActivity.class));
            } else {
                Utils.alertError("ATENCIÓN", getString(R.string.login_no_active), MainActivity.this);
                Utils.showProgress(false, getApplicationContext(), mLoginFormView, mProgressView);
            }
            /*answer = gson.fromJson(response, Answer.class);
            try{
                startActivity(new Intent(MainActivity.this, MenuActivity.class));
            } catch (JsonParseException e) {
                Utils.alertErrorProfessional("ATENCIÓN", getString(R.string.system_fails), ProfessionalLoginActivity.this);
            }*/
        }
    };

    private final Response.ErrorListener onPostsError = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            //Log.d("AFEMAFA", error.getMessage());
            //Log.d("AFEMAFA", error.getClass().getName());
            Utils.showProgress(false, getApplicationContext(), mLoginFormView, mProgressView);
            if (networkResponse != null && networkResponse.statusCode == 401) {
                // HTTP Status Code: 401 Unauthorized
                user_layout.setError(getString(R.string.invalid_user));
                focusView = user_et;
                focusView.requestFocus();
            }
            else {
                Utils.alertError("ATENCIÓN", getString(R.string.system_fails), MainActivity.this);
            }
            Log.e("PostActivity", error.toString());
        }
    };



}
