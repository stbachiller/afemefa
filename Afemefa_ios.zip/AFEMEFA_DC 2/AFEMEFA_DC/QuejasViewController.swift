//
//  QuejasViewController.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 28/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import  UIKit
import MobileCoreServices

class QuejasViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIActionSheetDelegate, UIDocumentPickerDelegate, UIDocumentMenuDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate, UITextViewDelegate {
    
    var dataWS : [String: String] = ["hechos":"","manifiesta":"","documentoAdjunto":"","imagenAdjunto":"","hidden-firstname":"","hidden-lastname":"","hidden-login":"","hidden-email":""]
    
    let documentInteractionController = UIDocumentInteractionController()
    var imagePicker = UIImagePickerController()
    
    var imageAux = UIImage(named: "ico-attach")
    //var activeTextField : UITextView!

    
    @IBOutlet weak var tableData: UITableView!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height / 2
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
//        let notificationCenter = NotificationCenter.default
//        notificationCenter.addObserver(self, selector: #selector(self.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
//        notificationCenter.addObserver(self, selector: #selector(self.keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        // Do any additional setup after loading the view, typically from a nib.
        
        let userDefaults = UserDefaults.standard
        let user = userDefaults.dictionary(forKey: "user")
        
        self.dataWS["hidden-firstname"] = user?["nombre"] as? String
        self.dataWS["hidden-login"] = user?["usuario"] as? String
        self.dataWS["hidden-lastname"] = user?["usuario"] as? String
        self.dataWS["hidden-email"] = user?["email"] as? String
        
        self.setupKeyboardDismissRecognizer()
        
        documentInteractionController.delegate = self
        
        self.tableData.allowsSelection = false
        self.tableData.delegate = self
        self.tableData.dataSource = self
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
        
        let customView = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 100))
        customView.backgroundColor = UIColor.white//(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        let button = UIButton(frame: CGRect(x: 10, y: 5, width: UIScreen.main.bounds.size.width - 20, height: 50))
        button.center.x = self.view.center.x
        button.backgroundColor = UIColor(red: 164/255, green: 203/255, blue: 82/255, alpha: 1)
        button.setTitle("Enviar", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.titleLabel!.font = UIFont(name: "Ubuntu-Medium", size: 20)

        button.layer.cornerRadius = 5.0
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.2
        button.layer.shadowOffset = CGSize.zero
        button.layer.shadowRadius = 2
        button.addTarget(self, action: #selector(enterAction), for: .touchUpInside)
        customView.addSubview(button)
        
        tableData.tableFooterView = customView
    }
    
    func validateFields() -> String {
        
        var mensaje = ""
        
        if dataWS["hechos"] == "" {
            mensaje = "Asunto"
        }
        
        if dataWS["manifiesta"] == "" {
            mensaje = "\nMensaje"
        }
        
        return mensaje
    }
    
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    @IBAction func enterAction(_ sender: Any) {
        
        if self.validateFields() != ""{
            DispatchQueue.main.async{
                self.callAlert(msg: "Debe revisar los siguientes campos:\n\(self.validateFields())")
            }
        }else {
            
            
                    self.view.showHUD(inView: self.view)
                    
                    let urlToRequest = "\(Constants.serverIP)/quejas"
                    func dataRequest() {
                        let url4 = URL(string: urlToRequest)!
                        let session4 = URLSession.shared
                        let request = NSMutableURLRequest(url: url4)
                        request.httpMethod = "POST"
                        
                        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
                        
                        var paramString = ""
                        
                        if self.dataWS["documentoAdjunto"] != "" {
                            
                            self.dataWS["documentoAdjunto"] = "data:application/pdf;base64," + self.dataWS["documentoAdjunto"]!
                            
                            paramString = "hechos=\(String(describing: self.dataWS["hechos"]!))&manifiesta=\(String(describing: self.dataWS["manifiesta"]!))&hidden-firstname=\(String(describing: self.dataWS["hidden-firstname"]!))&hidden-lastname=&hidden-login=\(String(describing: self.dataWS["hidden-login"]!))&hidden-email=\(String(describing: self.dataWS["hidden-email"]!))&adjunto=\(String(describing: self.dataWS["documentoAdjunto"]!))"
                            
                        }else if self.dataWS["imagenAdjunto"] != ""  {
                            
                            self.dataWS["imagenAdjunto"] = "data:image/jpeg;base64," + self.dataWS["imagenAdjunto"]!
                            
                            paramString = "hechos=\(String(describing: self.dataWS["hechos"]!))&manifiesta=\(String(describing: self.dataWS["manifiesta"]!))&hidden-firstname=\(String(describing: self.dataWS["hidden-firstname"]!))&hidden-lastname=&hidden-login=\(String(describing: self.dataWS["hidden-login"]!))&hidden-email=\(String(describing: self.dataWS["hidden-email"]!))&adjunto=\(String(describing: self.dataWS["imagenAdjunto"]!))"
                            
                        } else if self.dataWS["imagenAdjunto"] == "" && self.dataWS["documentoAdjunto"] == "" {
                            
                            paramString = "hechos=\(String(describing: self.dataWS["hechos"]!))&manifiesta=\(String(describing: self.dataWS["manifiesta"]!))&hidden-firstname=\(String(describing: self.dataWS["hidden-firstname"]!))&hidden-lastname=&hidden-login=\(String(describing: self.dataWS["hidden-login"]!))&hidden-email=\(String(describing: self.dataWS["hidden-email"]!))&adjunto="
                        }
                        
                        print(paramString)
                        //request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                        request.httpBody = paramString.data(using: String.Encoding.utf8, allowLossyConversion: false)
                        
                        //request.httpBody = paramString.data(using: String.Encoding.utf8)
                        let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                            
                            if let response = response as? HTTPURLResponse {
                                
                                switch response.statusCode {
                                case 200:
                                    if let data = data {
                                        do {
                                            
                                            let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                            
                                            DispatchQueue.main.async{
                                                self.view.hideHUD()
                                                self.callAlert(msg: "Se ha enviado correctamente el formulario de quejas")
                                            }
                                            print(json)
                                            
                                        } catch let error {
                                            self.view.hideHUD()
                                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                            print("Error login user:", error)
                                        }
                                    }
                                    break
                                case 400:
                                    DispatchQueue.main.async{
                                        self.view.hideHUD()
                                        self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                    }
                                    break
                                case 409:
                                    DispatchQueue.main.async{
                                        self.view.hideHUD()
                                        self.callAlert(msg: "No se ha enviado el email de quejas por cualquier error (no se ha podido adjuntar fichero,…).")
                                    }
                                    break
                                case 401:
                                    DispatchQueue.main.async{
                                        self.view.hideHUD()
                                        self.callAlert(msg: "No se ha encontrado el formulario de solicitud de autorización con ese id")
                                    }
                                    break
                                case 500:
                                    DispatchQueue.main.async{
                                        self.view.hideHUD()
                                        self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                    }
                                    
                                default:
                                    break
                                }
                            }
                            
                            guard let _: Data = data, let _: URLResponse = response, error == nil else {
                                print("*****error")
                                return
                            }
                            
                            //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                            //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
                        }
                        task.resume()
                    }
                    dataRequest()
        }
        
        
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return ""
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return 4
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        switch indexPath.row {
        case 0:
            return 160.0
        case 1:
            return 160.0
        case 2:
            return 150.0
        case 3:
            if UIDevice().userInterfaceIdiom == .phone {
                switch UIScreen.main.nativeBounds.height {
                case 1136:
                    print("iPhone 5 or 5S or 5C")
                    
                    return 600.0

                case 1334:
                    print("iPhone 6/6S/7/8")
                    return 520.0

                case 2208:
                    print("iPhone 6+/6S+/7+/8+")
                    return 520.0
                case 2436:
                    print("iPhone X")
                    return 520.0
                    
                default:
                    print("unknown")
                    
                }
            }
        
        default:
            break
        }
        
        return 70.0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //let cell = tableView.dequeueReusableCell(withIdentifier: "registerUserCell", for: indexPath) as! registerUserCell
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "QuejasCellID")! as! QuejasCell
        cell.asuntoTxt.delegate = self
        
        if indexPath.row == 0 {
            cell.titleText?.text = "¿Qué hechos han dado lugar  a que presentes esta queja o reclamación?"
            cell.lblText?.text = "Mensaje"
            cell.asuntoTxt.tag = 1
            cell.asuntoTxt.accessibilityIdentifier = "hechos"

            cell.asuntoTxt.keyboardType = .default
            cell.asuntoTxt.text = "Escribe aquí tu mensaje."
            cell.asuntoTxt.textColor = UIColor.lightGray
            if dataWS["hechos"] != "" {
                cell.asuntoTxt.textColor = UIColor.black
                cell.asuntoTxt.text = dataWS["hechos"]
            }
            
            return cell
        }else if indexPath.row == 1 {
            cell.titleText?.text = "Manifiesta qué resultado pretendes obtener tras la presentación de esta queja o reclamación."
            cell.lblText?.text = "Mensaje"
            cell.asuntoTxt.tag = 2
            cell.asuntoTxt.accessibilityIdentifier = "mensaje"

            cell.asuntoTxt.keyboardType = .default
            cell.asuntoTxt.text = "Escribe aquí tu mensaje."
            cell.asuntoTxt.textColor = UIColor.lightGray
            if dataWS["manifiesta"] != "" {
                cell.asuntoTxt.textColor = UIColor.black
                cell.asuntoTxt.text = dataWS["manifiesta"]
            }
            return cell
        }else if indexPath.row == 2 {
            
            let cell3 = tableView.dequeueReusableCell(withIdentifier: "SolicitudAutorizacionesFileCellID")! as! SolicitudAutorizacionesFileCell
            cell3.viewContainer.layer.cornerRadius = 5.0
            
            cell3.btnFile.addTarget(self, action: #selector(addFile), for: .touchUpInside)
            cell3.btnFile.setBackgroundImage(imageAux, for: .normal)
            if cell3.btnFile.currentBackgroundImage == UIImage.init(named: "icon-pdf") {
                cell3.btnFile.layer.shadowColor = UIColor.black.cgColor
                cell3.btnFile.layer.shadowOpacity = 0.2
                cell3.btnFile.layer.shadowOffset = CGSize.zero
                cell3.btnFile.layer.shadowRadius = 2
            }else {
                cell3.btnFile.layer.shadowColor = UIColor.clear.cgColor
                cell3.btnFile.layer.shadowOpacity = 0.0
                cell3.btnFile.layer.shadowOffset = CGSize.zero
                cell3.btnFile.layer.shadowRadius = 0
            }
            cell3.btnFile.contentMode = .scaleAspectFit
            return cell3
        }else if indexPath.row == 3 {
            let cell5 = tableView.dequeueReusableCell(withIdentifier: "SolicitudAutorizacionesTextCellID")! as! SolicitudAutorizacionesTextCell
            cell5.lblText.text = "El reclamante manifiesta que la materia objeto de la queja o reclamación no está siendo objeto de un procedimiento administrativo, arbitral o judicial.\nEn caso de disconformidad con la resolución adoptada por este servicio, o si transcurren más de dos meses de su reclamación, puede recurrir, de acuerdo con la ECO/734/2004, de 11 de marzo y la ECC/2502/2012, de 16 de noviembre, le asiste el derecho de quejarse, reclamar, consultar o recurrir al Servicio de Reclamaciones de la DGSFP, siguiendo los procedimientos desarrollados en la normativa señalada o cualquier otra que le sea de aplicación, sin perjuicio de otras acciones incluso judiciales que pudiera utilizar.\nEl Mutualista queda informado de forma inequivoca y precisa y autoriza expresamente a la ASOCIACIÓN FERROVIARIA MÉDICO-FARMACÉUTICA, para recabar y tratar automatizadamente en un Fichero del que es Contrato Póliza-cuaya cumplimentación es necesaria para adquirir la condición de mutualista-y los que se obtengan como consecuencia de la relación establecida entre el mutualista y Asociación Ferroviaria Médico-Farmacéutica (incluidos, en su caso, los datos de salud), con la única finalidad del mantenimiento, desarrollo o control de la relación entre el mutualista y Asociación Ferroviaria Médico-Farmacéutica.\nEl Mutualista podrá denegar el consentimiento anteriormente facilitado, asi como ejercitar los derechos de acceso, oposición, rectificación y cancelación de los datos recogidos en el Fichero, de acuerdo a la ley 15/1999, de 13 de diciembre de Proteccion de Datos de Carácter Personal, dirigiéndose para ello a la C/Murcia, 10. Madrid 28045."
            return cell5
        }
        
        return cell
    }
    
    
//    @objc func selectionBtnTerminos() {
//        if aceptFiles {
//            aceptFiles = false
//            dataWS["autenticidad"] = "false"
//        }else {
//            aceptFiles = true
//            dataWS["autenticidad"] = "true"
//        }
//        DispatchQueue.main.async{
//            self.tableData.reloadData()
//        }
//    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor =  UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        let headerLabel = UILabel(frame: CGRect(x: 13, y: 5, width:
            tableView.bounds.size.width - 26, height: tableView.bounds.size.height))
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 13)
        headerLabel.textColor = UIColor.lightGray
        headerLabel.numberOfLines = 2
        headerLabel.textAlignment = .left
        if section == 0 {
            headerLabel.text = "Indícanos el motivo de tu solicitud y envíanos los archivos necesarios para su tramitación."
        }
        
        headerLabel.sizeToFit()
        let customViewLine = UIView(frame: CGRect(x: 0, y: 44 , width: self.view.frame.size.width, height: 1))
        customViewLine.backgroundColor = UIColor(red: 235/255, green: 235/255, blue: 235/255, alpha: 1)
        headerView.addSubview(customViewLine)
        headerView.addSubview(headerLabel)
        
        return headerView
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    
    @IBAction func addFile(_ sender: Any) {
        
        //Create the AlertController and add Its action like button in Actionsheet
        let actionSheetControllerIOS8: UIAlertController = UIAlertController(title: "Adjuntar:", message: "", preferredStyle: .actionSheet)
        
        
        let cancelActionButton = UIAlertAction(title: "Cancelar", style: .cancel) { _ in
            
        }
        actionSheetControllerIOS8.addAction(cancelActionButton)
        
        let saveActionButton = UIAlertAction(title: "Documento", style: .default)
        { _ in
            
            let importMenu = UIDocumentMenuViewController(documentTypes: [String(kUTTypePDF),"public.text"], in: .import)
            importMenu.delegate = self
            importMenu.modalPresentationStyle = .formSheet
            self.present(importMenu, animated: true, completion: nil)
            
            print("Documento")
        }
        actionSheetControllerIOS8.addAction(saveActionButton)
        
        let deleteActionButton = UIAlertAction(title: "Capturar foto", style: .default)
        { _ in
            if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
                self.openCamera()
            }
            
            print("Foto")
            
        }
        actionSheetControllerIOS8.addAction(deleteActionButton)
        
        let galleryActionButton = UIAlertAction(title: "Abrir galeria", style: .default)
        { _ in
            if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
                
                self.openGallary()
                //                print("Button capture")
                //
                //                self.imagePicker.delegate = self
                //                self.imagePicker.sourceType = .savedPhotosAlbum;
                //                self.imagePicker.allowsEditing = false
                //
                //                self.present(self.imagePicker, animated: true, completion: nil)
            }
            
            print("Foto")
            
        }
        actionSheetControllerIOS8.addAction(galleryActionButton)
        self.present(actionSheetControllerIOS8, animated: true, completion: nil)
    }
    
    func openGallary() {
        imagePicker.delegate = self
        imagePicker.allowsEditing = false
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        
        imagePicker.modalPresentationStyle = .popover
        let presentationController = imagePicker.popoverPresentationController
        presentationController?.sourceView = self.tableData
        if presentationController == nil {
            present(imagePicker, animated: false, completion: nil)
        } else {
            //self.dismiss(animated: false, completion: {
            self.present(self.imagePicker, animated: false, completion: nil)
            //})
        }
    }
    
    
    func openCamera() {
    if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
            imagePicker.delegate = self
            imagePicker.allowsEditing = false
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.modalPresentationStyle = .popover
            let presentationController = imagePicker.popoverPresentationController
            presentationController?.sourceView = self.tableData
            if presentationController == nil {
                present(imagePicker, animated: false, completion: nil)
            } else {
                self.present(self.imagePicker, animated: false, completion: nil)
            }

        }else{
            let alert = UIAlertController(title: "Camara no encontrada", message: "Este dispositivo no tiene camara", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style:.default, handler: nil)
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        
        if let possibleImage = info[.editedImage] as? UIImage {
            let imageData = possibleImage.jpegData(compressionQuality: 0.1)
            let fileImage = imageData?.base64EncodedString(options: .lineLength64Characters)
            self.imageAux = possibleImage
            self.dataWS["imagenAdjunto"] = fileImage
            
        } else if let possibleImage = info[.originalImage] as? UIImage {
            let imageData = possibleImage.jpegData(compressionQuality: 0.1)
            let fileImage = imageData?.base64EncodedString(options: .lineLength64Characters)
            self.imageAux = possibleImage
            self.dataWS["imagenAdjunto"] = fileImage
            
        } else {
            
//            let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
//            let imageData = image.jpegData(compressionQuality: 0.1)
//            let fileImage = imageData?.base64EncodedString(options: .lineLength64Characters)
//            self.imageAux = image
//            self.dataWS["imagenAdjunto"] = fileImage
//            return
        }
        
        self.dismiss(animated: true, completion: nil)
        self.tableData.reloadData()
        
    }
    
    public func documentPicker(_ controller: UIDocumentPickerViewController,
                               didPickDocumentAt url: URL) {
        let myURL = url as URL
        print("import result : \(myURL)")
        
        let filePath = myURL // real path of the pdf file
        
        DispatchQueue.main.async{
            self.imageAux = UIImage.init(named: "icon-pdf")
            self.tableData.reloadData()
            
        }
        
        do{
            //let strFile = try String(contentsOf: filePath)
            let fileData = NSData(contentsOf: filePath)
            let fileStream = fileData!.base64EncodedString(options: NSData.Base64EncodingOptions.lineLength64Characters)
            self.dataWS["documentoAdjunto"] = fileStream
        }catch{
            print("error transforming")
        }
        
    }
    
    public func documentMenu(_ documentMenu:UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        documentPicker.delegate = self
        
        self.present(documentPicker, animated: true, completion: nil)
        
    }
    
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("view was cancelled")
        controller.dismiss(animated: true, completion: nil)
        
    }
    
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        if textView.text == "Escribe aquí tu mensaje." {
            textView.text = ""
            textView.textColor = UIColor.black
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
       
        if textView.tag == 1 {
            if textView.text.isEmpty {
                self.dataWS["manifiesta"] = textView.text
                textView.text = "Escribe aquí tu mensaje."
                textView.textColor = UIColor.lightGray
            }else {
                self.dataWS["hechos"] = textView.text
            }
        }else {
            if textView.text.isEmpty {
                self.dataWS["manifiesta"] = textView.text
                textView.text = "Escribe aquí tu mensaje."
                textView.textColor = UIColor.lightGray
            }else {
                self.dataWS["manifiesta"] = textView.text
            }
        }
        
    }
    
    func setupKeyboardDismissRecognizer(){
        let tapRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(ViewController.dismissKeyboard))
        
        self.view.addGestureRecognizer(tapRecognizer)
    }
    
    @objc func dismissKeyboard()
    {
        view.endEditing(true)
    }
    
}

extension QuejasViewController: UIDocumentInteractionControllerDelegate {
    /// If presenting atop a navigation stack, provide the navigation controller in order to animate in a manner consistent with the rest of the platform
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        guard let navVC = self.navigationController else {
            return self
        }
        return navVC
    }
}
