//
//  UserJSON.swift

//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 21/11/2018.
//  Copyright © 2018 Delta Ceti. All rights reserved.
//

import Foundation

class UserJSON: Decodable {
    
    var employeeId: String?
    var nombre: String?
    var usuario: String?
    var email: String?
    var dni: String?
    var dirección: String?
    var cp: String?
    var localidad: String?
    var provincia: String?
    var país: [String]?
    var teléfono: String?
    var fecha_nacimiento: String?
    var newsletter: String?
}



