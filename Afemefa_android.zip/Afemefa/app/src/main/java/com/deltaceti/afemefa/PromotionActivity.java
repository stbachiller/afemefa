package com.deltaceti.afemefa;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.Answer;
import com.deltaceti.afemefa.json.Post;
import com.deltaceti.afemefa.json.Promotion;
import com.deltaceti.afemefa.json.PromotionsAnswer;
import com.deltaceti.afemefa.json.User;
import com.deltaceti.afemefa.list.PromotionAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class PromotionActivity extends AppCompatActivity {

    private LinearLayout login_form;
    private View mProgressView;

    private ListView promotion_listview;
    private static PromotionAdapter adapter;

    private ArrayList<Promotion> promotions_list;

    private Gson gson;
    private PrefManager prefManager;
    private RequestQueue requestQueue;
    private String endpointPromotions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promotion);
        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Window window = this.getWindow();

// finally change the color
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.blue));

        login_form = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);

        promotion_listview = findViewById(R.id.list);

        prefManager = new PrefManager(getApplicationContext());
        gson = new GsonBuilder().serializeNulls().create();

        Utils.showProgress(true, getApplicationContext(), login_form, mProgressView);
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        endpointPromotions = getString(R.string.base_url).concat(getString(R.string.promotions_path));

        fetchPosts();

        promotion_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Promotion promotion = promotions_list.get(position);
                try{
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(promotion.getUrl_contenido()));
                    startActivity(i);
                } catch (Exception e){
                    Log.e("AFEMAFA", "Error opening promotion url");
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(PromotionActivity.this, MenuActivity.class);
                //PrefManager prefManager = new PrefManager(MenuActivity.this);
                //prefManager.setId("defaultStringIfNothingFound");
                startActivity(intent);
                finish();
                //super.onBackPressed();
                break;
        }
        return true;
    }

    private void fetchPosts() {
        StringRequest request = new StringRequest(Request.Method.GET, endpointPromotions, onPostsLoaded, onPostsError)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }


            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), PromotionActivity.this);
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoaded = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            PromotionsAnswer answer = gson.fromJson(response, PromotionsAnswer.class);
            JsonArray promotions_array = answer.getPromociones();
            promotions_list = new ArrayList<>();
            for (int i = 0; i < promotions_array.size(); i++) {
                Promotion promotion = gson.fromJson(promotions_array.get(i), Promotion.class);
                Log.d("AFEMAFA", promotion.getTitulo());
                promotions_list.add(promotion);
                Log.d("AFEMAFA", promotion.getUrl_imagen());
            }
            fill_list(promotions_list);
            Utils.showProgress(false, getApplicationContext(), login_form, mProgressView);
            /*answer = gson.fromJson(response, Answer.class);
            try{
                startActivity(new Intent(MainActivity.this, MenuActivity.class));
            } catch (JsonParseException e) {
                Utils.alertErrorProfessional("ATENCIÓN", getString(R.string.system_fails), ProfessionalLoginActivity.this);
            }*/
        }
    };

    private final Response.ErrorListener onPostsError = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getApplicationContext(), login_form, mProgressView);
            Utils.alertError("ATENCIÓN", getString(R.string.system_fails), PromotionActivity.this);
            Log.e("PostActivity", error.toString());
        }
    };

    private void fill_list(ArrayList<Promotion> promotions_list){
        adapter = new PromotionAdapter(promotions_list, PromotionActivity.this);
        promotion_listview.setAdapter(adapter);
    }

    public class PicassoImageGetter implements Html.ImageGetter {

        private TextView textView;

        private Picasso picasso;

        public PicassoImageGetter(@NonNull Picasso picasso, @NonNull TextView textView) {
            this.picasso = picasso;
            this.textView = textView;
        }

        @Override
        public Drawable getDrawable(String source) {
            Log.d(PicassoImageGetter.class.getName(), "Start loading url " + source);

            BitmapDrawablePlaceHolder drawable = new BitmapDrawablePlaceHolder();

            picasso
                    .load(source)
                    .error(R.drawable.bg_user)
                    .into(drawable);

            return drawable;
        }

        private class BitmapDrawablePlaceHolder extends BitmapDrawable implements Target {

            protected Drawable drawable;

            @Override
            public void draw(final Canvas canvas) {
                if (drawable != null) {
                    checkBounds();
                    drawable.draw(canvas);
                }
            }

            public void setDrawable(@Nullable Drawable drawable) {
                if (drawable != null) {
                    this.drawable = drawable;
                    checkBounds();
                }
            }

            private void checkBounds() {
                float defaultProportion = (float) drawable.getIntrinsicWidth() / (float) drawable.getIntrinsicHeight();
                int width = Math.min(textView.getWidth(), drawable.getIntrinsicWidth());
                int height = (int) ((float) width / defaultProportion);

                if (getBounds().right != textView.getWidth() || getBounds().bottom != height) {

                    setBounds(0, 0, textView.getWidth(), height); //set to full width

                    int halfOfPlaceHolderWidth = (int) ((float) getBounds().right / 2f);
                    int halfOfImageWidth = (int) ((float) width / 2f);

                    drawable.setBounds(
                            halfOfPlaceHolderWidth - halfOfImageWidth, //centering an image
                            0,
                            halfOfPlaceHolderWidth + halfOfImageWidth,
                            height);

                    textView.setText(textView.getText()); //refresh text
                }
            }

            //------------------------------------------------------------------//

            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                setDrawable(new BitmapDrawable(getApplicationContext().getResources(), bitmap));
            }

            @Override
            public void onBitmapFailed(Drawable errorDrawable) {
                setDrawable(errorDrawable);
            }

            @Override
            public void onPrepareLoad(Drawable placeHolderDrawable) {
                setDrawable(placeHolderDrawable);
            }

            //------------------------------------------------------------------//

        }
    }

}
