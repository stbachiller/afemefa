package com.deltaceti.afemefa.json;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

/**
 * Created by arr375 on 13/02/2017.
 */

public class PromotionsAnswer {

    private String mensaje;
    private JsonElement pagina;
    private JsonArray promociones;

    public String getMensaje() {
        return mensaje;
    }

    public JsonElement getPagina() {
        return pagina;
    }

    public JsonArray getPromociones() {
        return promociones;
    }
}
