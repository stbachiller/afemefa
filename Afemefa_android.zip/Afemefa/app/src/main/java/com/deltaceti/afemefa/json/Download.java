package com.deltaceti.afemefa.json;

import java.io.Serializable;

/**
 * Created by arr on 01/11/2017.
 */

public class Download implements Serializable {

    private String id;
    private String titulo;
    private String contenido;
    private String name;
    private String fecha_creacion;
    private String fecha_modificacion;
    private String url_descarga;
    private String tamanio;
    private String tipo;
    private String ext;
    private String tipo_user;

    public Download(String id, String titulo, String contenido, String name, String fecha_creacion, String fecha_modificacion, String url_descarga, String tamanio, String tipo, String ext) {
        this.id = id;
        this.titulo = titulo;
        this.contenido = contenido;
        this.name = name;
        this.fecha_creacion = fecha_creacion;
        this.fecha_modificacion = fecha_modificacion;
        this.url_descarga = url_descarga;
        this.tamanio = tamanio;
        this.tipo = tipo;
        this.ext = ext;
    }

    public void setTipoUser(String tipo_user){
        this.tipo_user=tipo_user;
    }

    public String getTipoUser(){
        return this.tipo_user;
    }

    public String getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getContenido() {
        return contenido;
    }

    public String getName() {
        return name;
    }

    public String getFecha_creacion() {
        return fecha_creacion;
    }

    public String getFecha_modificacion() {
        return fecha_modificacion;
    }

    public String getUrl_descarga() {
        return url_descarga;
    }

    public String getTamanio() {
        return tamanio;
    }

    public String getTipo() {
        return tipo;
    }

    public String getExt() {
        return ext;
    }
}
