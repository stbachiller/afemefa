//
//  SolicitudAutorizacionesTextCell.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 20/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit

class SolicitudAutorizacionesTextCell: UITableViewCell {
    
    @IBOutlet weak var lblText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
