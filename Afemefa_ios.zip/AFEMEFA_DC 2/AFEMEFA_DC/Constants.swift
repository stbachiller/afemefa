//
//  Constants.swift
//  Cabin
//
//  Created by Cristina Hortelano on 21/11/2018.
//  Copyright © 2018 Delta Ceti. All rights reserved.
//

import Foundation
import UIKit

public final class Constants {
    
    static let shared = Constants()
    //static let serverIP = "https://api.afemefa.oficina.splink.es/"
    static let serverIP = "https://api.afemefa.com/"
    static let deviceID = UIDevice.current.identifierForVendor
    
    
}
