//
//  SearchCuadroMedicoDental.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 11/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit

class SearchCuadroMedicoDental: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var tableData: UITableView!
    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var viewBack: UIView!
    
    var activeTextField = UITextField()
    
    var datosProvincias : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()
    var datosLocalidades : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()
    var datosEspecialidades : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()

    var isMedical = Bool()
    var dataWSMed : [String: String] = ["especialidad":"","especialidadID":"","provincia":"","provinciaID":"","localidad":"","localidadID":"","cp":"","nombreCentro":"","profSanitario":""]
    var dataWSDen : [String: String] = ["provincia":"","provinciaID":"", "localidad":"", "localidadID":"", "cp":"","nombreCentro":"", "profSanitario":""]

    override func viewDidLayoutSubviews() {

        self.picker.frame = CGRect(x: 0, y: self.view.frame.size.height - 200, width: self.view.frame.size.width, height: 200)
        self.viewBack.isHidden = true
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height / 2
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(self.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(self.keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        
        
        
        if isMedical {
          labelTitle.text = "Cuadro médico"
        }else {
          labelTitle.text = "Cuadro dental"
        }
        
        self.setupKeyboardDismissRecognizer()
        
        self.tableData.delegate = self
        self.tableData.dataSource = self
        
        // Connect data:
        self.picker.delegate = self
        self.picker.dataSource = self
        
        self.picker.isHidden = true
        self.viewBack.isHidden = true
        
        let customView = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 100))
        customView.backgroundColor = UIColor.white//(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        let button = UIButton(frame: CGRect(x: 10, y: 5, width: UIScreen.main.bounds.size.width - 20, height: 50))
        button.center.x = self.view.center.x
        button.backgroundColor = UIColor(red: 164/255, green: 203/255, blue: 82/255, alpha: 1)
        button.setTitle("Buscar", for: .normal)
        button.titleLabel!.font = UIFont(name: "Ubuntu-Medium", size: 20)
        button.setTitleColor(UIColor.black, for: .normal)
        button.layer.cornerRadius = 5.0
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.2
        button.layer.shadowOffset = CGSize.zero
        button.layer.shadowRadius = 2
        button.addTarget(self, action: #selector(enterAction), for: .touchUpInside)
        customView.addSubview(button)
       
        tableData.tableFooterView = customView
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
        
        self.view.showHUD(inView: self.view)
        self.callWSProvincias()
    }
    
    func callWSProvincias() {
        
        let urlToRequest = "\(Constants.serverIP)centros-inicio"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "GET"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                DispatchQueue.main.async{
                                    
                                    self.datosEspecialidades = json["especialidades"] as! [Dictionary<String, AnyObject>]
                                    
                                    self.datosEspecialidades.insert(["id": 0 as AnyObject,"nombre":"" as AnyObject], at: 0)
                                    
                                    self.datosProvincias = json["provincias"] as! [Dictionary<String, AnyObject>]
                                    
                                    self.datosProvincias.insert(["id": 0 as AnyObject,"nombre":"" as AnyObject], at: 0)
                                    
                                    self.view.hideHUD()
                                    self.picker.reloadAllComponents()
                                }
                                
                                
                            } catch let error {
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 204:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se ha encontrado datos.")
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
        
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if isMedical {
            return "Encuentra tu centro médico o facultativo"
        }else {
            return "Encuentra tu centro dental"
        }
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor =  UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        let headerLabel = UILabel(frame: CGRect(x: 10, y: 10, width:
            tableView.bounds.size.width, height: tableView.bounds.size.height))
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 13)
        headerLabel.textColor = UIColor.lightGray
        if isMedical {
            headerLabel.text = "Encuentra tu centro médico o facultativo"
        }else {
            headerLabel.text = "Encuentra tu centro dental"
        }
        
        headerLabel.sizeToFit()
        let customViewLine = UIView(frame: CGRect(x: 0, y: 39 , width: self.view.frame.size.width, height: 1))
        customViewLine.backgroundColor = UIColor(red: 235/255, green: 235/255, blue: 235/255, alpha: 1)
        headerView.addSubview(customViewLine)
        headerView.addSubview(headerLabel)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isMedical {
            return 6
        }else {
             return 5
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "registerUserCell", for: indexPath) as! registerUserCell
        
        cell.detailTxt.delegate = self
        cell.detailTxt.isSecureTextEntry = false
        cell.asterizco.isHidden = true
        
        if isMedical {
            if indexPath.row == 0 {
                cell.titleLabel.text = "Especialidad"
                
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 1
                cell.detailTxt.keyboardType = .default
                cell.detailTxt.text = ""
                if dataWSMed["especialidad"] != "" {
                    cell.detailTxt.text = dataWSMed["especialidad"]
                }
            }else if indexPath.row == 1 {
                cell.titleLabel.text = "Provincia"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 2
                cell.detailTxt.keyboardType = .default
                cell.detailTxt.text = ""
                if dataWSMed["provincia"] != "" {
                    cell.detailTxt.text = dataWSMed["provincia"]
                }
            }else if indexPath.row == 2 {
                cell.titleLabel.text = "Localidad"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 3
                cell.detailTxt.keyboardType = .default
                cell.detailTxt.text = ""
                if dataWSMed["localidad"] != "" {
                    cell.detailTxt.text = dataWSMed["localidad"]
                }
            }else if indexPath.row == 3 {
                cell.titleLabel.text = "C.P"
                cell.detailTxt.placeholder = "Introduce tu código postal"
                cell.detailTxt.tag = 4
                cell.detailTxt.keyboardType = .numberPad
                cell.detailTxt.text = ""
                if dataWSMed["cp"] != "" {
                    cell.detailTxt.text = dataWSMed["cp"]
                }
            }else if indexPath.row == 4 {
                cell.titleLabel.text = "Nombre/Centro"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 5
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                if dataWSMed["nombreCentro"] != "" {
                    cell.detailTxt.text = dataWSMed["nombreCentro"]
                }
            }else if indexPath.row == 5 {
                cell.titleLabel.text = "Prof. Sanitario"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 6
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                if dataWSMed["profSanitario"] != "" {
                    cell.detailTxt.text = dataWSMed["profSanitario"]
                }
            }
        }else {
            if indexPath.row == 0 {
                cell.titleLabel.text = "Provincia"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 2
                cell.detailTxt.keyboardType = .default
                cell.detailTxt.text = ""
                if dataWSDen["provincia"] != "" {
                    cell.detailTxt.text = dataWSDen["provincia"]
                }
            }else if indexPath.row == 1 {
                cell.titleLabel.text = "Localidad"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 3
                cell.detailTxt.keyboardType = .default
                cell.detailTxt.text = ""
                if dataWSDen["localidad"] != "" {
                    cell.detailTxt.text = dataWSDen["localidad"]
                }
            }else if indexPath.row == 2 {
                cell.titleLabel.text = "C.P"
                cell.detailTxt.placeholder = "Introduce tu código postal"
                cell.detailTxt.tag = 4
                cell.detailTxt.keyboardType = .numberPad
                cell.detailTxt.text = ""
                if dataWSDen["cp"] != "" {
                    cell.detailTxt.text = dataWSDen["cp"]
                }
            }else if indexPath.row == 3 {
                cell.titleLabel.text = "Nombre/Centro"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 5
                cell.detailTxt.keyboardType = .default
                cell.detailTxt.text = ""
                if dataWSDen["nombreCentro"] != "" {
                    cell.detailTxt.text = dataWSDen["nombreCentro"]
                }
            }else if indexPath.row == 4 {
                cell.titleLabel.text = "Prof. Sanitario"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 6
                cell.detailTxt.keyboardType = .default
                cell.detailTxt.text = ""
                if dataWSDen["profSanitario"] != "" {
                    cell.detailTxt.text = dataWSDen["profSanitario"]
                }
            }
            
        }
       
        return cell
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        switch textField.tag {
            
        case 1:
                dataWSMed["especialidad"] = textField.text!
            
            break
        case 2:
            
            if isMedical {
                    dataWSMed["provincia"] = textField.text!
                
            }else {
                    dataWSDen["provincia"] = textField.text!
                
            }
            
            break
        case 3:
            if isMedical {
                    dataWSMed["localidad"] = textField.text!
                
            }else {
                    dataWSDen["localidad"] = textField.text!
                
            }
            
            break
        case 4:
            if isMedical {
                    dataWSMed["cp"] = textField.text!
                
            }else {
                    dataWSDen["cp"] = textField.text!
                
            }
            
            break
        case 5:
            if isMedical {
                    dataWSMed["nombreCentro"] = textField.text!
                
            }else {
                    dataWSDen["nombreCentro"] = textField.text!
                
            }
            
            break
        case 6:
            if isMedical {
                    dataWSMed["profSanitario"] = textField.text!
                
            }else {
                    dataWSDen["profSanitario"] = textField.text!
                
            }
            
            break
        
        default:
            break
        }
        textField.resignFirstResponder()
    }
    
    func setupKeyboardDismissRecognizer(){
        let tapRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(self.dismissKeyboard))
        
        self.view.addGestureRecognizer(tapRecognizer)
    }
    
    @objc func dismissKeyboard()
    {
        self.picker.isHidden = true
        self.viewBack.isHidden = true
        view.endEditing(true)
    }
    
    @IBAction func enterAction(_ sender: Any) {
        
        self.dismissKeyboard()
        
//        if self.validateFields() != ""{
//            DispatchQueue.main.async{
//                self.callAlert(msg: "Debe revisar los siguientes campos:\n\(self.validateFields())")
//            }
//        }else {
        
            self.view.showHUD(inView: self.view)
        
            var urlToRequest = ""
        
            urlToRequest = "\(Constants.serverIP)/centros-busqueda"
            func dataRequest() {
                let url4 = URL(string: urlToRequest)!
                let session4 = URLSession.shared
                let request = NSMutableURLRequest(url: url4)
                request.httpMethod = "POST"
                
                request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
                
                var paramString = ""
                if isMedical {
                    paramString = "listingfields[2]=\(String(describing: dataWSMed["especialidadID"]!))&listingfields[27]=\(String(describing: dataWSMed["provinciaID"]!))&listingfields[29]=\(String(describing: dataWSMed["localidadID"]!))&listingfields[14]=\(String(describing: dataWSMed["cp"]!))&listingfields[1]=\(String(describing: dataWSMed["nombreCentro"]!))&listingfields[15]=\(String(describing: dataWSMed["profSanitario"]!))"
                }else {
                    paramString = "listingfields[27]=\(String(describing: dataWSDen["provinciaID"]!))&listingfields[29]=\(String(describing: dataWSDen["localidadID"]!))&listingfields[14]=\(String(describing: dataWSDen["cp"]!))&listingfields[1]=\(String(describing: dataWSDen["nombreCentro"]!))&listingfields[15]=\(String(describing: dataWSDen["profSanitario"]!))"
                }
                
                
                //request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = paramString.data(using: String.Encoding.utf8, allowLossyConversion: false)
                
                //request.httpBody = paramString.data(using: String.Encoding.utf8)
                let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                    
                    if let response = response as? HTTPURLResponse {
                        
                        switch response.statusCode {
                        case 200:
                            if let data = data {
                                do {
                                    
                                    let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                    
                                    DispatchQueue.main.async{
                                        self.view.hideHUD()
                                        self.performSegue(withIdentifier: "SearchCentros_to_detail", sender: json["centros"])
                                    
                                    }
                                    
                                } catch let error {
                                    self.view.hideHUD()
                                    self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                    print("Error login user:", error)
                                }
                            }
                            break
                        case 204:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "No se han encontrado centros.")
                            }
                            break
        
                        case 500:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            
                        default:
                            break
                        }
                    }
                    
                    guard let _: Data = data, let _: URLResponse = response, error == nil else {
                        print("*****error")
                        return
                    }
                    
                    //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
                }
                task.resume()
            }
            dataRequest()
//        }
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "SearchCentros_to_detail" {
            if let detailSearchViewController = segue.destination as? DetailSearchCuadroMedicoDental {
                detailSearchViewController.datosCentros = sender as! [Dictionary<String, AnyObject>]
                
            }
            
        }
        
    }
    
    func validateFields() -> String {
        
        print(dataWSMed)
        
        var mensaje = ""
        
        if isMedical {
            
            if dataWSMed["especialidad"] == "" {
                mensaje = "Especialidad"
            }
            
            if dataWSMed["provincia"] == "" {
                mensaje = mensaje + "\nProvincia"
            }
            
            if dataWSMed["localidad"] == "" {
                mensaje = mensaje + "\nLocalidad"
            }
            
//            if dataWSMed["nombreCentro"] == "" {
//                mensaje = mensaje + "\nNombre centro"
//            }
//
//            if dataWSMed["profSanitario"] == "" {
//                mensaje = mensaje + "\nProfesional sanitario"
//            }
//
//            if dataWSMed["cp"] == "" {
//                mensaje = mensaje + "\nCódigo postal"
//            }
            
        }else {
            if dataWSDen["provincia"] == "" {
                mensaje = "Provincia"
            }
            
            if dataWSDen["localidad"] == "" {
                mensaje = mensaje + "\nLocalidad"
            }
            
//            if dataWSDen["nombreCentro"] == "" {
//                mensaje = mensaje + "\nNombre centro"
//            }
//
//            if dataWSDen["profSanitario"] == "" {
//                mensaje = mensaje + "\nProfesional sanitario"
//            }
//
//            if dataWSDen["cp"] == "" {
//                mensaje = mensaje + "\nCódigo postal"
//            }
        }
        
        
        
        return mensaje
        
    }
    
    func isValidEmail(email:String?) -> Bool {
        
        guard email != nil else { return false }
        
        let regEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let pred = NSPredicate(format:"SELF MATCHES %@", regEx)
        return pred.evaluate(with: email)
    }
    
    func isvalidDate(date:String?) -> Bool {
        
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "dd/MM/yyyy"
        
        
        if dateFormatterGet.date(from: date!) != nil {
            return true
            
        } else {
            // invalid format
            return false
            
        }
        
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {

        self.activeTextField = textField

        if textField.tag == 1 {
            self.picker.reloadAllComponents()
            self.viewBack.isHidden = false
            self.picker.isHidden = false
            return false
        }else if textField.tag == 2 {
            self.picker.reloadAllComponents()
            self.picker.isHidden = false
            self.viewBack.isHidden = false
            return false
        }else if textField.tag == 3 {
            if isMedical && self.dataWSMed["provinciaID"] != "" {
                self.picker.reloadAllComponents()
                self.picker.isHidden = false
                self.viewBack.isHidden = false
            }else if !isMedical && self.dataWSDen["provinciaID"] != "" {
                self.picker.reloadAllComponents()
                self.picker.isHidden = false
                self.viewBack.isHidden = false
            }
            return false
        }
        self.picker.isHidden = true
        self.viewBack.isHidden = true
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    
    
    // Number of columns of data
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        
        if self.activeTextField.tag == 1 {
            return self.datosEspecialidades.count
        }else if self.activeTextField.tag == 2 {
            return self.datosProvincias.count
        }else if self.activeTextField.tag == 3 {
            return self.datosLocalidades.count
        }
        
        return self.datosEspecialidades.count
    }
    
    // The data to return fopr the row and component (column) that's being passed in
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
            if self.activeTextField.tag == 1 {
                return self.datosEspecialidades[row]["nombre"] as? String
            }else if self.activeTextField.tag == 2 {
                return self.datosProvincias[row]["nombre"] as? String
            }else if self.activeTextField.tag == 3 {
                return self.datosLocalidades[row]["nombre"] as? String
            }
        
        
        return self.datosEspecialidades[row]["nombre"] as? String
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        // This method is triggered whenever the user makes a change to the picker selection.
        // The parameter named row and component represents what was selected.
            if self.activeTextField.tag == 1 {
                if isMedical {
                    if self.datosEspecialidades[row]["nombre"] as? String != "" {
                        self.dataWSMed["especialidadID"] = String(self.datosEspecialidades[row]["id"] as! Int)
                        self.dataWSMed["especialidad"] = self.datosEspecialidades[row]["nombre"] as? String
                    }else {
                        self.dataWSMed["especialidadID"] = ""
                        self.dataWSMed["especialidad"] = ""
                    }
                }
                //            return self.datosEspecialidades[row]["nombre"] as? String
            }else if self.activeTextField.tag == 2 {
        
                    if isMedical && self.datosProvincias[row]["nombre"] as? String != "" {
                        self.dataWSMed["provinciaID"] = String(self.datosProvincias[row]["id"] as! Int)
                        self.dataWSMed["provincia"] = self.datosProvincias[row]["nombre"] as? String
                        
                        self.view.showHUD(inView: self.view)
                        self.dataWSMed["localidadID"] = ""
                        self.dataWSMed["localidad"] = ""
                        self.dataWSDen["localidadID"] = ""
                        self.dataWSDen["localidad"] = ""
                        self.datosLocalidades.removeAll()
                        self.callWSLocalidades(idProvincia: String(self.datosProvincias[row]["id"] as! Int))
                        self.picker.isHidden = true
                    }else if !isMedical && self.datosProvincias[row]["nombre"] as? String != "" {
                        self.dataWSDen["provinciaID"] = String(self.datosProvincias[row]["id"] as! Int)
                        self.dataWSDen["provincia"] = self.datosProvincias[row]["nombre"] as? String
                        
                        self.view.showHUD(inView: self.view)
                      self.callWSLocalidades(idProvincia:String(self.datosProvincias[row]["id"] as! Int))
                        self.dataWSMed["localidadID"] = ""
                        self.dataWSMed["localidad"] = ""
                        self.dataWSDen["localidadID"] = ""
                        self.dataWSDen["localidad"] = ""
                        self.datosLocalidades.removeAll()
                        self.picker.isHidden = true
                    }else {
                        self.dataWSMed["provinciaID"] = ""
                        self.dataWSMed["provincia"] = ""
                        self.dataWSDen["provinciaID"] = ""
                        self.dataWSDen["provincia"] = ""
                        self.dataWSMed["localidadID"] = ""
                        self.dataWSMed["localidad"] = ""
                        self.dataWSDen["localidadID"] = ""
                        self.dataWSDen["localidad"] = ""
                        self.datosLocalidades.removeAll()
                       
                        self.picker.reloadAllComponents()
                    }
                DispatchQueue.main.async{
                    self.tableData.reloadData()
                }
                
            }else if self.activeTextField.tag == 3 {
                if isMedical && self.datosLocalidades[row]["nombre"] as? String != ""{
                    self.dataWSMed["localidadID"] = String(self.datosLocalidades[row]["id"] as! Int)
                    self.dataWSMed["localidad"] = self.datosLocalidades[row]["nombre"] as? String
                }else if !isMedical && self.datosLocalidades[row]["nombre"] as? String != ""{
                    self.dataWSDen["localidadID"] = String(self.datosLocalidades[row]["id"] as! Int)
                    self.dataWSDen["localidad"] = self.datosLocalidades[row]["nombre"] as? String
                }else {
                    self.dataWSMed["localidadID"] = ""
                    self.dataWSMed["localidad"] = ""
                    self.dataWSDen["localidadID"] = ""
                    self.dataWSDen["localidad"] = ""
                    
                    DispatchQueue.main.async{
                        self.tableData.reloadData()
                    }
                    self.picker.isHidden = true
                    self.picker.reloadAllComponents()
                }
                
            }
        
        
        self.tableData.reloadData()
    }
    
    func callWSLocalidades(idProvincia : String?) {
        
        let urlToRequest = "\(Constants.serverIP)/centros-localidad"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "POST"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            let paramString = "idProvincia=\(String(describing: idProvincia!))"
            request.httpBody = paramString.data(using: String.Encoding.utf8)
            
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                DispatchQueue.main.async{
                                    
                                    self.datosLocalidades = json["localidades"] as! [Dictionary<String, AnyObject>]
                                    
                                    self.datosLocalidades.insert(["id": 0 as AnyObject,"nombre":"" as AnyObject], at: 0)
                                    self.view.hideHUD()
                                    //self.picker.reloadAllComponents()
                                }
                                
                                
                            } catch let error {
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 204:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se ha encontrado datos.")
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
    }
    
    func textFieldShouldReturn(_ scoreText: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
}
