//
//  ZonaMutualista.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 15/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit


class ZonaMutualista: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var datosMutualista = [String]()
    
    @IBOutlet weak var tableData: UITableView!
    @IBOutlet weak var viewPerfil: UIView!
    @IBOutlet weak var viewSolicitudes: UIView!
    @IBOutlet weak var viewQuejas: UIView!
    @IBOutlet weak var viewPromociones: UIView!

    @IBOutlet weak var labelPerfil: UILabel!
    @IBOutlet weak var labelSolicitudes: UILabel!
    @IBOutlet weak var labelQuejas: UILabel!
    @IBOutlet weak var labelPromociones: UILabel!
    
    @IBOutlet weak var btnPerfil: UIButton!
    @IBOutlet weak var btnSolicitudes: UIButton!
    @IBOutlet weak var btnQuejas: UIButton!
    @IBOutlet weak var btnPromociones: UIButton!
    
    @IBOutlet weak var imgPerfil: UIImageView!
    @IBOutlet weak var imgSolicitudes: UIImageView!
    @IBOutlet weak var imgQuejas: UIImageView!
    @IBOutlet weak var imgPromociones: UIImageView!
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override func viewDidLayoutSubviews() {
        self.customizeUI()
    }
    
    //Customizar elementos
    func customizeUI () {
    
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 1136:
                print("iPhone 5 or 5S or 5C")
                viewQuejas.frame = CGRect(x: self.viewQuejas.frame.origin.x, y: self.viewQuejas.frame.origin.y + 15, width: self.viewQuejas.frame.size.width, height: self.viewQuejas.frame.size.height)
                viewPromociones.frame = CGRect(x: self.viewPromociones.frame.origin.x, y: self.viewPromociones.frame.origin.y + 15, width: self.viewPromociones.frame.size.width, height: self.viewPromociones.frame.size.height)
                tableData.frame = CGRect(x: self.tableData.frame.origin.x, y: self.tableData.frame.origin.y + 15, width: self.tableData.frame.size.width, height: self.tableData.frame.size.height - 15)
                
                self.labelPerfil.frame = CGRect(x: self.labelPerfil.frame.origin.x + 3, y: self.labelPerfil.frame.origin.y + 8, width: self.labelPerfil.frame.size.width, height: self.labelPerfil.frame.size.height)
                
                self.labelQuejas.frame = CGRect(x: self.labelQuejas.frame.origin.x + 3, y: self.labelQuejas.frame.origin.y + 8, width: self.labelQuejas.frame.size.width, height: self.labelQuejas.frame.size.height)
                
                self.labelPromociones.frame = CGRect(x: self.labelPromociones.frame.origin.x + 3, y: self.labelPromociones.frame.origin.y + 8, width: self.labelPromociones.frame.size.width, height: self.labelPromociones.frame.size.height)
                
                self.labelSolicitudes.frame = CGRect(x: self.labelSolicitudes.frame.origin.x + 3, y: self.labelSolicitudes.frame.origin.y + 8, width: self.labelSolicitudes.frame.size.width, height: self.labelSolicitudes.frame.size.height)
                
                
                
                
            case 1334:
                print("iPhone 6/6S/7/8")
                
            case 2208:
                print("iPhone 6+/6S+/7+/8+")
            case 2436:
                print("iPhone X")
                self.imgPerfil.frame = CGRect(x: self.imgPerfil.frame.origin.x, y: self.imgPerfil.frame.origin.y + 5, width: self.imgPerfil.frame.size.width, height: self.imgPerfil.frame.size.height)
                
                self.imgQuejas.frame = CGRect(x: self.imgQuejas.frame.origin.x, y: self.imgQuejas.frame.origin.y + 5, width: self.imgQuejas.frame.size.width, height: self.imgQuejas.frame.size.height)
                
                self.imgPromociones.frame = CGRect(x: self.imgPromociones.frame.origin.x , y: self.imgPromociones.frame.origin.y + 5, width: self.imgPromociones.frame.size.width, height: self.imgPromociones.frame.size.height)
                
                self.imgSolicitudes.frame = CGRect(x: self.imgSolicitudes.frame.origin.x, y: self.imgSolicitudes.frame.origin.y + 5, width: self.imgSolicitudes.frame.size.width, height: self.imgSolicitudes.frame.size.height)
            default:
                print("unknown")
                self.imgPerfil.frame = CGRect(x: self.imgPerfil.frame.origin.x, y: self.imgPerfil.frame.origin.y + 10, width: self.imgPerfil.frame.size.width, height: self.imgPerfil.frame.size.height)
                
                self.imgQuejas.frame = CGRect(x: self.imgQuejas.frame.origin.x, y: self.imgQuejas.frame.origin.y + 10, width: self.imgQuejas.frame.size.width, height: self.imgQuejas.frame.size.height)
                
                self.imgPromociones.frame = CGRect(x: self.imgPromociones.frame.origin.x , y: self.imgPromociones.frame.origin.y + 10, width: self.imgPromociones.frame.size.width, height: self.imgPromociones.frame.size.height)
                
                self.imgSolicitudes.frame = CGRect(x: self.imgSolicitudes.frame.origin.x, y: self.imgSolicitudes.frame.origin.y + 10, width: self.imgSolicitudes.frame.size.width, height: self.imgSolicitudes.frame.size.height)
                
                self.labelPerfil.frame = CGRect(x: self.labelPerfil.frame.origin.x, y: self.labelPerfil.frame.origin.y - 8, width: self.labelPerfil.frame.size.width, height: self.labelPerfil.frame.size.height)
                
                self.labelQuejas.frame = CGRect(x: self.labelQuejas.frame.origin.x, y: self.labelQuejas.frame.origin.y - 8, width: self.labelQuejas.frame.size.width, height: self.labelQuejas.frame.size.height)
                
                self.labelPromociones.frame = CGRect(x: self.labelPromociones.frame.origin.x, y: self.labelPromociones.frame.origin.y - 8, width: self.labelPromociones.frame.size.width, height: self.labelPromociones.frame.size.height)
                
                self.labelSolicitudes.frame = CGRect(x: self.labelSolicitudes.frame.origin.x, y: self.labelSolicitudes.frame.origin.y - 8, width: self.labelSolicitudes.frame.size.width, height: self.labelSolicitudes.frame.size.height)
                
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnPerfil.imageView?.contentMode = .scaleAspectFit
        btnQuejas.imageView?.contentMode = .scaleAspectFit
        btnPromociones.imageView?.contentMode = .scaleAspectFit
        btnSolicitudes.imageView?.contentMode = .scaleAspectFit
        
        // Do any additional setup after loading the view, typically from a nib.
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        self.tableData.dataSource = self
        self.tableData.delegate = self
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
        
        self.view.showHUD(inView: self.view)
        
        self.callSeguros()

    }
    
    func callSeguros()  {
        
        let userDefaults = UserDefaults.standard
        let user = userDefaults.dictionary(forKey: "user")
        
        let userID = user?["id"] as? String
        
        let urlToRequest = "\(Constants.serverIP)texto-lateral/\(userID!)"
        //let urlToRequest = "\(Constants.serverIP)texto-lateral/1885"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "GET"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                DispatchQueue.main.async{
                                    
                                    self.datosMutualista = json["texto"] as! [String]
                                    self.view.hideHUD()
                                    self.tableData.reloadData()
                                }
                                
                                
                            } catch let error {
                                self.view.hideHUD()
                                //self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 204:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            //self.callAlert(msg: "No se ha encontrado texto.")
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            //self.callAlert(msg: "No se ha introducido el id del usuario")
                        }
                        break
                    case 401:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            //self.callAlert(msg: "No se ha encontrado el usuario.")
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            //self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
        
        
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return "Tus seguros"
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor =  UIColor(red: 239/255, green: 239/255, blue: 244/255, alpha: 1)
        
        let headerLabel = UILabel(frame: CGRect(x: 10, y: 5, width:
            tableView.bounds.size.width, height: tableView.bounds.size.height))
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 13)
        headerLabel.textColor = UIColor.lightGray
        headerLabel.text = "Tus seguros"
        headerLabel.sizeToFit()
        headerView.addSubview(headerLabel)
        
        return headerView
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return datosMutualista.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ZonaMutualistaCell", for: indexPath) as! ZonaMutualistaCell
        
        cell.labelTxt.text = datosMutualista[indexPath.row]
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "mutualistas_editUser" {
            if let registerViewController = segue.destination as? RegisterUserViewController {
                registerViewController.iscommingUpadate = true
            }
            
        }
    }
    
    @IBAction func goToEditUser(_ sender: Any) {
        performSegue(withIdentifier: "mutualistas_editUser", sender: nil)

    }
    
    @IBAction func goToPromociones(_ sender: Any) {
        performSegue(withIdentifier: "mutualistas_to_promociones", sender: nil)
        
    }
    
    @IBAction func goToSolicitudes(_ sender: Any) {
        performSegue(withIdentifier: "mutualista_to_SolicitudAut", sender: nil)
        
    }
    
    @IBAction func goToQuejas(_ sender: Any) {
        performSegue(withIdentifier: "mutualista_to_quejas", sender: nil)
        
    }
}





