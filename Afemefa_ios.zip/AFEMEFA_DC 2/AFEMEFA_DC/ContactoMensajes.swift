//
//  ContactoMensajes.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 13/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit


class ContactoMensajes: UIViewController, UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate, UITextViewDelegate {
    
    var dataWSMens : [String: String] = ["your-name":"","your-email":"","your-subject":"","your-message":""]
    var aceptNewsLetter = false
    var aceptTerminos = false
    @IBOutlet weak var tableData: UITableView!
    var activeTag = 0

    
    @objc func keyboardWillShow(notification: NSNotification) {
        if activeTag == 4 {
            if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
                if self.view.frame.origin.y == 0 {
                    self.view.frame.origin.y -= keyboardSize.height / 2
                }
            }
        }
        //if self.activeTextField.accessibilityIdentifier != "name" && self.activeTextField.accessibilityIdentifier != "email" &&  self.activeTextField.accessibilityIdentifier != "asunto" {
        
        //}
        
        
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        //if self.activeTextField.accessibilityIdentifier != "name" && self.activeTextField.accessibilityIdentifier != "email" &&  self.activeTextField.accessibilityIdentifier != "asunto" {
        if activeTag == 4 {
            if self.view.frame.origin.y != 0 {
                self.view.frame.origin.y = 0
            }
        }
        
        //}
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(self.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(self.keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        
        // Do any additional setup after loading the view, typically from a nib.
        self.tableData.dataSource = self
        self.tableData.delegate = self
        
        self.setupKeyboardDismissRecognizer()

        let customView = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 100))
        customView.backgroundColor = UIColor.white//(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        let button = UIButton(frame: CGRect(x: 10, y: 5, width: UIScreen.main.bounds.size.width - 20, height: 50))
        button.center.x = self.view.center.x
        button.backgroundColor = UIColor(red: 164/255, green: 203/255, blue: 82/255, alpha: 1)
        button.setTitle("Enviar", for: .normal)
        button.titleLabel!.font = UIFont(name: "Ubuntu-Medium", size: 20)
        button.setTitleColor(UIColor.black, for: .normal)
        button.layer.cornerRadius = 5.0
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.2
        button.layer.shadowOffset = CGSize.zero
        button.layer.shadowRadius = 2
        button.addTarget(self, action: #selector(enterAction), for: .touchUpInside)
        customView.addSubview(button)
        tableData.tableFooterView = customView

    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return "Datos personales"
        case 1:
            return "Tu mensaje"
        case 2:
            return "Términos del servicio"
        default:
            break
        }
        return ""
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1 {
            return 100.0
        }else {
            return 70.0
        }
        
    }
        
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor =  UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        let headerLabel = UILabel(frame: CGRect(x: 10, y: 10, width:
        tableView.bounds.size.width, height: tableView.bounds.size.height))
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 13)
        headerLabel.textColor = UIColor.lightGray
        if section == 0 {
            headerLabel.text = "Datos personales"
        }else if section == 1 {
            headerLabel.text = "Tu mensaje"
        }else if section == 2 {
            headerLabel.text = "Términos del servicio"
        }
        
        headerLabel.sizeToFit()
        let customViewLine = UIView(frame: CGRect(x: 0, y: 39 , width: self.view.frame.size.width, height: 1))
        customViewLine.backgroundColor = UIColor(red: 235/255, green: 235/255, blue: 235/255, alpha: 1)
        headerView.addSubview(customViewLine)
        headerView.addSubview(headerLabel)
        
        return headerView
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//
//
//
//        return 70
//    }
    
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case 0:
            return 3
        case 1:
            return 1
        case 2:
            return 2
        default:
            break
        }
        return 0
    }
        
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "registerUserCell") as! registerUserCell
        let cell2 = tableView.dequeueReusableCell(withIdentifier: "registerUser2Cell") as! registerUser2Cell
        let cell3 = tableView.dequeueReusableCell(withIdentifier: "ContactoMensajeCell") as! ContactoMensajeCell
        
        cell.detailTxt.delegate = self
        cell.detailTxt.isSecureTextEntry = false
        
        switch indexPath.section {
        case 0:
            if indexPath.row == 0 {
                cell.titleLabel.text = "Nombre"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "name"

                cell.detailTxt.tag = 1
                cell.detailTxt.keyboardType = .default
                cell.detailTxt.text = ""
                if dataWSMens["your-name"] != "" {
                    cell.detailTxt.text = dataWSMens["your-name"]
                }
            }else if indexPath.row == 1 {
                cell.titleLabel.text = "Email"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "email"

                cell.detailTxt.tag = 2
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                if dataWSMens["your-email"] != "" {
                    cell.detailTxt.text = dataWSMens["your-email"]
                }
            }else if indexPath.row == 2 {
                cell.titleLabel.text = "Asunto"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "asunto"

                cell.detailTxt.tag = 3
                cell.detailTxt.keyboardType = .default
                cell.detailTxt.text = ""
                if dataWSMens["your-subject"] != "" {
                    cell.detailTxt.text = dataWSMens["your-subject"]
                }
            }
            return cell
        case 1:
            //cell3.detailLabelTxt.placeholder = "Escribe aquí tu mensaje."
            cell3.detailLabelTxt.delegate = self
            cell3.detailLabelTxt.text = "Escribe aquí tu mensaje."
            cell3.detailLabelTxt.textColor = UIColor.lightGray
            cell3.detailLabelTxt.tag = 4
            cell3.detailLabelTxt.keyboardType = .default
            if dataWSMens["your-message"] != "" {
                cell3.detailLabelTxt.textColor = UIColor.black
                cell3.detailLabelTxt.text = dataWSMens["your-message"]
            }
            return cell3
        case 2:
            if indexPath.row == 0 {
                cell2.detailLabel.text = "Acepto recibir la newsletter de AFEMEFA(noticias de salud, actualizaciones del cuadro médico, promociones, etc.)"
                cell2.btnSelect.addTarget(self, action: #selector(selectionBtnNews), for: .touchUpInside)
                if aceptNewsLetter {
                    let textImage = UIImage(named: "check")
                    cell2.btnSelect.setImage(textImage, for: .normal)
                }else {
                    let textImage = UIImage(named: "circle-outline")
                    cell2.btnSelect.setImage(textImage, for: .normal)
                }
                cell2.btnSelect.isEnabled = true
                cell2.asterizco.isHidden = true
                
            }else if indexPath.row == 1 {
                let attributedString = NSMutableAttributedString(string: "Acepto la política de privacidad.")
                //attributedString.addAttribute(.link, value: "https://www.hackingwithswift.com", range: NSRange(location: 11, length: 21))
                attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor(red: 164/255, green: 203/255, blue: 82/255, alpha: 1), range: NSRange(location: 10, length: 22))
                
                cell2.detailLabel.attributedText = attributedString
                cell2.btnTerminos.addTarget(self, action: #selector(self.openTerminosURL), for: .touchUpInside)
                cell2.btnSelect.isEnabled = true
                cell2.btnSelect.addTarget(self, action: #selector(selectionBtnTerminos), for: .touchUpInside)
                if aceptTerminos {
                    let textImage = UIImage(named: "check")
                    cell2.btnSelect.setImage(textImage, for: .normal)
                }else {
                    let textImage = UIImage(named: "circle-outline")
                    cell2.btnSelect.setImage(textImage, for: .normal)
                }
                
                cell2.asterizco.isHidden = false
                
            }
            return cell2
        default:
            break
        }
        
        return cell
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        activeTag = textField.tag
        if textField.text == "Escribe aquí tu mensaje." {
            textField.text = ""
        }
        activeTag = textField.tag

        return true
    }

    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            dataWSMens["your-message"] = textView.text
            textView.text = "Escribe aquí tu mensaje."
            textView.textColor = UIColor.lightGray
        }else {
            
            dataWSMens["your-message"] = textView.text
        }
    }
    
    @objc func selectionBtnNews() {
        if aceptNewsLetter {
            aceptNewsLetter = false
            //dataWS["newsLetter"] = "false"
        }else {
            aceptNewsLetter = true
            //dataWS["newsLetter"] = "true"
        }
        
        DispatchQueue.main.async{
            self.tableData.reloadData()
        }
    }
    
    @objc func selectionBtnTerminos() {
        if aceptTerminos {
            aceptTerminos = false
            //dataWS["terminos"] = "false"
        }else {
            aceptTerminos = true
            //dataWS["terminos"] = "true"
        }
        DispatchQueue.main.async{
            self.tableData.reloadData()
        }
    }
        
        
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        switch textField.tag {
        
            case 1:
                    dataWSMens["your-name"] = textField.text!
                
                break
            case 2:
                    dataWSMens["your-email"] = textField.text!
                
                break
            case 3:
                    dataWSMens["your-subject"] = textField.text!
                
                break
        default:
            break
        }
        textField.resignFirstResponder()
            
    }
        
    func setupKeyboardDismissRecognizer(){
        let tapRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(self.dismissKeyboard))
        
                self.view.addGestureRecognizer(tapRecognizer)
            }
        
    @objc func dismissKeyboard()
    {
        view.endEditing(true)
    }
    
    @IBAction func enterAction(_ sender: Any) {
        
        self.dismissKeyboard()
        
        if self.validateFields() != ""{
            DispatchQueue.main.async{
                self.callAlert(msg: "Debe revisar los siguientes campos:\n\(self.validateFields())")
            }
        }else {
            
            self.view.showHUD(inView: self.view)
            
            let userDefaults = UserDefaults.standard
            let user = userDefaults.dictionary(forKey: "user")
            
            let userID = user?["id"] as? String
            
            let urlToRequest = "\(Constants.serverIP)contacto"///\(String(describing: userID!))"
            func dataRequest() {
                let url4 = URL(string: urlToRequest)!
                let session4 = URLSession.shared
                let request = NSMutableURLRequest(url: url4)
                request.httpMethod = "POST"
                
                request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
                
                let paramString = "your-name=\(String(describing: dataWSMens["your-name"]!))&your-email=\(String(describing: dataWSMens["your-email"]!))&your-subject=\(String(describing: dataWSMens["your-subject"]!))&your-message=\(String(describing: dataWSMens["your-message"]!))"
                
                //request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = paramString.data(using: String.Encoding.utf8, allowLossyConversion: false)
                
                //request.httpBody = paramString.data(using: String.Encoding.utf8)
                let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                    
                    if let response = response as? HTTPURLResponse {
                        
                        switch response.statusCode {
                        case 200:
                            if let data = data {
                                do {
                                    
                                    let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                    
                                    DispatchQueue.main.async{
                                        self.view.hideHUD()
                                        self.callAlert(msg: json["mensaje"] as? String)
                                        
                                    }
                                    print(json)
                                    
                                } catch let error {
                                    self.view.hideHUD()
                                    self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                    print("Error login user:", error)
                                }
                            }
                            break
                        case 401:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "No se ha encontrado el formulario de contacto con ese id.")
                            }
                            break
                            
                        case 400:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "No se han pasado los parámetros correctamente.")
                            }
                            break
                        case 500:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            
                        default:
                            break
                        }
                    }
                    
                    guard let _: Data = data, let _: URLResponse = response, error == nil else {
                        print("*****error")
                        return
                    }
                    
                    //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
                }
                task.resume()
            }
            dataRequest()
        }
        
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    func validateFields() -> String {
        
        print(dataWSMens)
        
        var mensaje = ""
        
        if dataWSMens["your-name"] == "" {
            mensaje = "Nombre"
        }
        
        if dataWSMens["your-email"] == "" || !isValidEmail(email: dataWSMens["your-email"]) {
            mensaje = mensaje + "\nEmail"
        }
        
        if dataWSMens["your-subject"] == "" {
            mensaje = mensaje + "\nAsunto"
        }
        
        if dataWSMens["your-message"] == "" {
            mensaje = mensaje + "\nMensaje"
        }
        
        if !aceptTerminos  {
            mensaje = mensaje + "\nAceptar términos del servicio"
        }
        return mensaje
        
    }
    
    func isValidEmail(email:String?) -> Bool {
        
        guard email != nil else { return false }
        
        let regEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let pred = NSPredicate(format:"SELF MATCHES %@", regEx)
        return pred.evaluate(with: email)
    }
    
    func textFieldShouldReturn(_ scoreText: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    @objc func openTerminosURL() {
        
        self.view.showHUD(inView: self.view)
        
        let urlToRequest = "\(Constants.serverIP)/textos-legales"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "POST"
            
            //request.httpBody = paramString.data(using: String.Encoding.utf8)
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                
                                DispatchQueue.main.async{
                                    self.view.hideHUD()
                                    guard let url = URL(string: json["url"] as! String) else { return }
                                    UIApplication.shared.open(url)
                                }
                                print(json)
                                
                            } catch let error {
                                self.view.hideHUD()
                                
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                        }
                        break
                    case 401:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
    }
}
