//
//  GestionDescargas.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 08/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit
import MobileCoreServices

class GestionDescargas: UIViewController, UITableViewDelegate, UITableViewDataSource, UIActionSheetDelegate, UIDocumentPickerDelegate {

    var datosDescargas : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()
    var datosDescargasUsuario : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()

    @IBOutlet weak var tableDescargas: UITableView!
    @IBOutlet weak var segmentoDescargas: UISegmentedControl!
    let documentInteractionController = UIDocumentInteractionController()

    var rc = UIRefreshControl()
    
    override func viewDidLayoutSubviews() {
        
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        let segAttributes: NSDictionary = [
            NSAttributedString.Key.foregroundColor: UIColor(red: 164/255, green: 203/255, blue: 82/255, alpha: 1), NSAttributedString.Key.font: UIFont(name: "OpenSans-Bold", size: 13)!
        ]
        let segAttributesWhites: NSDictionary = [
            NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: UIFont(name: "OpenSans-Bold", size: 13)!
        ]
        segmentoDescargas.setTitleTextAttributes(segAttributes as [NSObject : AnyObject] as [NSObject : AnyObject] as? [NSAttributedString.Key : Any], for: UIControl.State.selected)
        segmentoDescargas.setTitleTextAttributes(segAttributesWhites as [NSObject : AnyObject] as [NSObject : AnyObject] as? [NSAttributedString.Key : Any], for: UIControl.State.normal)
        
        documentInteractionController.delegate = self

        let userDefaults = UserDefaults.standard
        let user = userDefaults.dictionary(forKey: "user")
        
//        self.labelName.text = user?["nombre"] as? String
//        let userID = user?["id"] as? String
//        self.labelNumeroSocio.text = "Mutualista: " + userID!
        
        self.view.showHUD(inView: self.view)
        self.callWsDescargas(userID: (user?["id"] as? String)!)

        self.rc.addTarget(self, action: #selector(doPullToRefresh), for: UIControl.Event.valueChanged)
        if #available(iOS 10.0, *) {
            self.tableDescargas.refreshControl = self.rc
        } else {
            // Fallback on earlier versions
        }
        
    
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @objc func doPullToRefresh() {
        let userDefaults = UserDefaults.standard
        let user = userDefaults.dictionary(forKey: "user")
        self.callWsDescargas(userID: (user?["id"] as? String)!)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        
    }
    
    func callWsDescargas(userID: String)  {
        
        let urlToRequest = "\(Constants.serverIP)/descargas/\(userID)"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "GET"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                DispatchQueue.main.async{
                                    
                                    self.datosDescargas = json["descargasMutualista"] as! [Dictionary<String, AnyObject>]
                                    
                                    self.datosDescargasUsuario = json["descargasUsuario"] as! [Dictionary<String, AnyObject>]
                                    
                                    self.rc.endRefreshing()
                                    self.view.hideHUD()
                                    self.tableDescargas.reloadData()
                                }
                                
                                
                            } catch let error {
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 204:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se ha encontrado ninguna descarga.")
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
        
        
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Descargas"
    }
    
    
    public func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor =  UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        let headerLabel = UILabel(frame: CGRect(x: 10, y: 10, width:
            tableView.bounds.size.width, height: tableView.bounds.size.height))
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 13)
        headerLabel.textColor = UIColor.lightGray
        headerLabel.text = "Descargas"
        headerLabel.sizeToFit()
        let customViewLine = UIView(frame: CGRect(x: 0, y: 39 , width: self.view.frame.size.width, height: 1))
        customViewLine.backgroundColor = UIColor(red: 235/255, green: 235/255, blue: 235/255, alpha: 1)
        headerView.addSubview(customViewLine)
        headerView.addSubview(headerLabel)
        
        return headerView
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        switch segmentoDescargas.selectedSegmentIndex {
        case 0:
            return self.datosDescargas.count
        case 1:
            return self.datosDescargasUsuario.count
        default:
            break
        }
        return self.datosDescargas.count
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GestionDescargasCellID", for: indexPath) as! GestionDescargasCell
        
        var post = Dictionary<String, AnyObject>()
        switch segmentoDescargas.selectedSegmentIndex {
        case 0:
            post = self.datosDescargas[indexPath.row]
            break
        case 1:
            post = self.datosDescargasUsuario[indexPath.row]
            break
        default:
            break
        }
        
        let tamanioDoc = post["tamanio"] as? String
        cell.detailLabelTxt.text = "Descargar: " + tamanioDoc!
        cell.titleLabelTxt.text = post["titulo"] as? String
        
        if post["ext"] as? String == "pdf" {
            cell.imageCell.image = UIImage.init(named: "icon-pdf")
        }else if post["ext"] as? String == "Word" {
            cell.imageCell.image = UIImage.init(named: "icon-doc")
        }else if post["ext"] as? String == "rar" {
            cell.imageCell.image = UIImage.init(named: "icon-rar-file")
        }else if post["ext"] as? String == "zip" {
            cell.imageCell.image = UIImage.init(named: "icon-zip-file")
        }else  {
            cell.imageCell.image = UIImage.init(named: "icon-noformat-file")
        }
        
        cell.imageCell.contentMode = .scaleAspectFit
        
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        //let post = self.datosPosts[indexPath.row]
        //performSegue(withIdentifier: "homePosts_to_detail", sender: post)
        
        var post = Dictionary<String, AnyObject>()
        switch segmentoDescargas.selectedSegmentIndex {
        case 0:
            post = self.datosDescargas[indexPath.row]
            break
        case 1:
            post = self.datosDescargasUsuario[indexPath.row]
            break
        default:
            break
        }
        
        self.view.showHUD(inView: self.view)

        let urlString = (post["url_descarga"] as? String)!
        
        self.storeAndShare(withURLString: urlString)
            

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
//        if segue.identifier == "homePosts_to_detail" {
//            if let detailPostViewController = segue.destination as? DetailPost {
//                detailPostViewController.datosPost = sender as! Dictionary<String, AnyObject>
//
//            }
//
//        }
        
    }
    
    @IBAction func backAction(_ sender: Any) {
        //close view
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func segmentedAction(_ sender: Any) {
        DispatchQueue.main.async{
            self.tableDescargas.reloadData()
        }
    }
    
    @IBAction func filterSheet(sender: AnyObject)
    {
        
        //Create the AlertController and add Its action like button in Actionsheet
        let actionSheetControllerIOS8: UIAlertController = UIAlertController(title: "Ordenar por:", message: "", preferredStyle: .actionSheet)
        
        
        let cancelActionButton = UIAlertAction(title: "Cancelar", style: .cancel) { _ in
            
        }
        actionSheetControllerIOS8.addAction(cancelActionButton)
        
        let saveActionButton = UIAlertAction(title: "Titulo", style: .default)
        { _ in

            self.datosDescargasUsuario = (self.datosDescargasUsuario as NSArray).sortedArray(using: [NSSortDescriptor(key: "titulo", ascending: true)]) as! [[String:AnyObject]]
            
            self.datosDescargas = (self.datosDescargas as NSArray).sortedArray(using: [NSSortDescriptor(key: "titulo", ascending: true)]) as! [[String:AnyObject]]

            self.tableDescargas.reloadData()
            print("Save")
        }
        actionSheetControllerIOS8.addAction(saveActionButton)
        
        let deleteActionButton = UIAlertAction(title: "Fecha de Publicación", style: .default)
        { _ in
            print("Delete")
            
            self.datosDescargasUsuario = self.datosDescargasUsuario.sorted{ ($0["fecha_creacion"] as? String)! > ($1["fecha_creacion"]as? String)! }
            
            self.datosDescargas = self.datosDescargas.sorted{ ($0["fecha_creacion"]as? String)! > ($1["fecha_creacion"]as? String)! }
            self.tableDescargas.reloadData()
        }
        actionSheetControllerIOS8.addAction(deleteActionButton)
        self.present(actionSheetControllerIOS8, animated: true, completion: nil)
    }
    
//    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
//        let myURL = url as URL
//        print("import result : \(myURL)")
    
    
    public func documentPicker(_ controller: UIDocumentPickerViewController,
                                 didPickDocumentAt url: URL) {
        let myURL = url as URL
        print("import result : \(myURL)")
        self.view.hideHUD()

    }
    
    public func documentMenu(_ documentMenu:UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        documentPicker.delegate = self
        self.view.hideHUD()

        self.present(documentPicker, animated: true, completion: nil)

    }
    
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("view was cancelled")
        controller.dismiss(animated: true, completion: nil)
        self.view.hideHUD()

    }
    
    
}

extension GestionDescargas {
    /// This function will set all the required properties, and then provide a preview for the document
    func share(url: URL) {
        documentInteractionController.url = url
        documentInteractionController.uti = url.typeIdentifier ?? "public.data, public.content, public.text"
        documentInteractionController.name = url.localizedName ?? url.lastPathComponent
        documentInteractionController.presentPreview(animated: true)
    }
    
    /// This function will store your document to some temporary URL and then provide sharing, copying, printing, saving options to the user
    func storeAndShare(withURLString: String) {
        guard let url = URL(string: withURLString) else { return }
        /// START YOUR ACTIVITY INDICATOR HERE
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else { return }
            let tmpURL = FileManager.default.temporaryDirectory
                .appendingPathComponent(response?.suggestedFilename ?? "fileName.png")
            do {
                try data.write(to: tmpURL)
            } catch {
                print(error)
            }
            DispatchQueue.main.async {
                /// STOP YOUR ACTIVITY INDICATOR HERE
                self.view.hideHUD()
                self.share(url: tmpURL)
            }
            }.resume()
    }
}

extension GestionDescargas: UIDocumentInteractionControllerDelegate {
    /// If presenting atop a navigation stack, provide the navigation controller in order to animate in a manner consistent with the rest of the platform
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        guard let navVC = self.navigationController else {
            return self
        }
        return navVC
    }
}

extension URL {
    var typeIdentifier: String? {
        return (try? resourceValues(forKeys: [.typeIdentifierKey]))?.typeIdentifier
    }
    var localizedName: String? {
        return (try? resourceValues(forKeys: [.localizedNameKey]))?.localizedName
    }
}
