package com.deltaceti.afemefa.json;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

/**
 * Created by arr375 on 13/02/2017.
 */

public class LateralText {

    private String mensaje;
    private JsonArray texto;


    public JsonArray getTexto() {
        return texto;
    }


}
