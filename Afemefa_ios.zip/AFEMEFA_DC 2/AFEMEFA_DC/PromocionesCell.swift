//
//  PromocionesCell.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 10/01/2019.
//  Copyright © 2019 RiverSnap. All rights reserved.
//

import Foundation
import UIKit

class PromocionesCell: UITableViewCell {
    
    @IBOutlet weak var labelTxt: UILabel!
    @IBOutlet weak var titleTxt: UILabel!
    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var viewContainer: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
