package com.deltaceti.afemefa.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.deltaceti.afemefa.json.Download;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by arr on 17/02/2018.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    private static DatabaseHelper sInstance;

    // Logcat tag
    private static final String LOG = "DatabaseHelper";

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "DataAfemefa";

    // Table Downloads
    private static final String TABLE_DOWNLAOD = "downloads";

    // Columns Provincies
    public static final String DOWNLOAD_COLUMN_ID = "id";
    public static final String DOWNLOAD_COLUMN_TIPO_USER = "tipo_usuario";
    public static final String DOWNLOAD_COLUMN_TITULO = "titulo";
    public static final String DOWNLOAD_COLUMN_CONTENIDO = "contenido";
    public static final String DOWNLOAD_COLUMN_NAME = "name";
    public static final String DOWNLOAD_COLUMN_FECHA_CREACION = "fecha_creacion";
    public static final String DOWNLOAD_COLUMN_FECHA_MODIFICACION = "fecha_modificación";
    public static final String DOWNLOAD_COLUMN_URL = "url_descarga";
    public static final String DOWNLOAD_COLUMN_TAMANIO = "tamanio";
    public static final String DOWNLOAD_COLUMN_TIPO = "tipo";
    public static final String DOWNLOAD_COLUMN_EXT = "ext";



    // Create Downloads table
    private static final String CREATE_TABLE_DOWNLOADS = "CREATE TABLE " + TABLE_DOWNLAOD +
            "(" + DOWNLOAD_COLUMN_ID + " TEXT PRIMARY KEY, " +
            DOWNLOAD_COLUMN_TIPO_USER + " TEXT, " +
            DOWNLOAD_COLUMN_TITULO + " TEXT, " +
            DOWNLOAD_COLUMN_CONTENIDO + " TEXT, " +
            DOWNLOAD_COLUMN_NAME + " TEXT, " +
            DOWNLOAD_COLUMN_FECHA_CREACION + " TEXT, " +
            DOWNLOAD_COLUMN_FECHA_MODIFICACION + " TEXT, " +
            DOWNLOAD_COLUMN_URL + " TEXT, " +
            DOWNLOAD_COLUMN_TAMANIO + " TEXT, " +
            DOWNLOAD_COLUMN_TIPO + " TEXT, " +
            DOWNLOAD_COLUMN_EXT + " TEXT)";

    public static synchronized DatabaseHelper getInstance(Context context) {

        // Use the application context, which will ensure that you
        // don't accidentally leak an Activity's context.
        // See this article for more information: http://bit.ly/6LRzfx
        if (sInstance == null) {
            sInstance = new DatabaseHelper(context.getApplicationContext());
        }
        return sInstance;
    }

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // creating required tables
        db.execSQL(CREATE_TABLE_DOWNLOADS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        // on upgrade drop older tables
        //db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DOWNLAOD);

        // create new tables
        onCreate(db);
    }

    public void addDownload(ArrayList<Download> list) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL( "delete FROM " + TABLE_DOWNLAOD);
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            for (Download download : list) {
                values.put(DOWNLOAD_COLUMN_ID, download.getId());
                Log.d("AFEMAFA", download.getId());
                values.put(DOWNLOAD_COLUMN_TIPO_USER, download.getTipoUser());
                values.put(DOWNLOAD_COLUMN_TITULO, download.getTitulo());
                Log.d("AFEMAFA", download.getTitulo());
                values.put(DOWNLOAD_COLUMN_CONTENIDO, download.getContenido());
                values.put(DOWNLOAD_COLUMN_NAME, download.getName());
                values.put(DOWNLOAD_COLUMN_FECHA_CREACION, download.getFecha_creacion());
                values.put(DOWNLOAD_COLUMN_FECHA_MODIFICACION, download.getFecha_modificacion());
                values.put(DOWNLOAD_COLUMN_URL, download.getUrl_descarga());
                values.put(DOWNLOAD_COLUMN_TAMANIO, download.getTamanio());
                values.put(DOWNLOAD_COLUMN_TIPO, download.getTipo());
                values.put(DOWNLOAD_COLUMN_EXT, download.getExt());

                db.insert(TABLE_DOWNLAOD, null, values);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }


    public List<Download> getDownloads(String user_type, String order) {
        SQLiteDatabase db = this.getReadableDatabase();
        String mysql = "SELECT * FROM downloads WHERE tipo_usuario=? ORDER BY " + order;
        if (order.startsWith("fecha"))
            mysql = mysql + " DESC";
        Cursor res =  db.rawQuery( mysql,  new String[]{user_type});
        List<Download> events = new ArrayList<Download>();
        res.moveToFirst();
        for (int i = 0; i < res.getCount(); i++) {
            events.add(new Download(res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_ID)), res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_TITULO)),
                    res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_CONTENIDO)), res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_NAME)),
                    res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_FECHA_CREACION)),res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_FECHA_MODIFICACION)),
                    res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_URL)), res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_TAMANIO)),
                    res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_TIPO)), res.getString(res.getColumnIndex(DOWNLOAD_COLUMN_EXT))));
            res.moveToNext();
        }
        db.close();
        return events;
    }



}
