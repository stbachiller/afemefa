package com.deltaceti.afemefa;

import android.content.Context;
import android.content.SharedPreferences;

import com.deltaceti.afemefa.json.Centers;

/**
 * Created by arr375 on 20/02/2017.
 */

public class PrefManager {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;

    // shared pref mode
    int PRIVATE_MODE = 0;

    // Shared preferences file name
    private static final String PREF_NAME = "info-afemafa";

    private static final String USER_INFO = "User_info";

    private static final String USER_ID = "User_id";

    private static final String TIME_STAMP_POSTS = "Time_stamp_posts";

    private static final String POSTS = "Posts";

    private static final String URL_BLOG = "Url_blog";

    private static final String CENTERS = "Centers";

    public Long getTimeStampPosts() {
        return pref.getLong(TIME_STAMP_POSTS, 0);
    }

    public String getPOSTS() {
        return pref.getString(POSTS, "defaultStringIfNothingFound");
    }

    public void setTimeStampPosts(Long time_stamps_posts) {
        editor.putLong(TIME_STAMP_POSTS, time_stamps_posts);
        editor.commit();
    }

    public void setPosts(String posts) {
        editor.putString(POSTS, posts);
        editor.commit();
    }

    public PrefManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void setUserInfo(String user_info) {
        editor.putString(USER_INFO, user_info);
        editor.commit();
    }

    public String getUserInfo() {
        return pref.getString(USER_INFO, "defaultStringIfNothingFound");
    }

    public void setUserId(String user_id) {
        editor.putString(USER_ID, user_id);
        editor.commit();
    }

    public String getUserId() {
        return pref.getString(USER_ID, "defaultStringIfNothingFound");
    }

    public void setCenters(String centers) {
        editor.putString(CENTERS, centers);
        editor.commit();
    }

    public String getCenters() {
        return pref.getString(CENTERS, "defaultStringIfNothingFound");
    }

    public void setUrlBlog(String url_blog) {
        editor.putString(URL_BLOG, url_blog);
        editor.commit();
    }

    public String getUrlBlog() {
        return pref.getString(URL_BLOG, "defaultStringIfNothingFound");
    }


}
