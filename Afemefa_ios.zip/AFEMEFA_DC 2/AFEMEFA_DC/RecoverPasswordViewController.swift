//
//  RecoverPasswordViewController.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 21/11/2018.
//  Copyright © 2018 Delta Ceti. All rights reserved.
//
import UIKit
import Foundation

class RecoverPasswordViewController: UIViewController, UITextFieldDelegate {
    
    //Declaracion de variables locales
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var titulo: UILabel!
    @IBOutlet weak var descr: UILabel!
    @IBOutlet weak var userTxt: UITextField!
    @IBOutlet weak var enterBtn: UIButton!

    override func viewDidLayoutSubviews() {
        
        titulo.frame = CGRect(x: self.titulo.frame.origin.x, y: self.titulo.frame.origin.y - 50, width: self.titulo.frame.size.width, height: self.titulo.frame.size.height)
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height / 2
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 1136:
                print("iPhone 5 or 5S or 5C")
                let notificationCenter = NotificationCenter.default
                notificationCenter.addObserver(self, selector: #selector(self.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
                notificationCenter.addObserver(self, selector: #selector(self.keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
                descr.font = UIFont(name: "Ubuntu-Medium", size: 15)
            case 1334:
                print("iPhone 6/6S/7/8")
                
            case 2208:
                print("iPhone 6+/6S+/7+/8+")
                
            case 2436:
                print("iPhone X")
                
            default:
                print("unknown")
                let notificationCenter = NotificationCenter.default
                notificationCenter.addObserver(self, selector: #selector(self.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
                notificationCenter.addObserver(self, selector: #selector(self.keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
            }
        }
        // Do any additional setup after loading the view, typically from a nib.
                
        self.setupKeyboardDismissRecognizer()

        self.customizeUI()
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    func customizeUI() {

        self.userTxt.delegate = self
        self.viewContainer.layer.cornerRadius = 10.0
        self.enterBtn.layer.cornerRadius = 10.0
    }
    
    func isValidEmail(email:String?) -> Bool {
        
        guard email != nil else { return false }
        
        let regEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let pred = NSPredicate(format:"SELF MATCHES %@", regEx)
        return pred.evaluate(with: email)
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    func textFieldShouldReturn(_ scoreText: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    @IBAction func backAction(_ sender: Any) {
        //close view
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func enterAction(_ sender: Any) {
        
        //validate fields
        //if everything is correct, call login webservice.
        //if self.isValidEmail(email: userTxt.text){
            // call webservice
            // This shows how you can specify the settings/parameters instead of using the default/shared parameters
        self.view.showHUD(inView: self.view)

            let urlToRequest = "\(Constants.serverIP)/recuperar-password"
            func dataRequest() {
                let url4 = URL(string: urlToRequest)!
                let session4 = URLSession.shared
                let request = NSMutableURLRequest(url: url4)
                request.httpMethod = "POST"
                request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
                let paramString = "username=\(String(describing: userTxt.text!))"
                request.httpBody = paramString.data(using: String.Encoding.utf8)
                let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                    
                    if let response = response as? HTTPURLResponse {
                        
                        switch response.statusCode {
                        case 200:
                            
                            DispatchQueue.main.async{
                                self.view.hideHUD()

                                self.callAlert(msg: "Se ha enviado un email a tu cuenta para recuperar la contraseña.")
                            }
//                            if let data = data {
//                                do {
//                                    let userJSON = try JSONDecoder().decode(UserJSON.self, from: data)
//                                    print(userJSON)
//                                } catch let error {
//                                    self.callAlert(msg: "El usuario se ha registrado correctamente.")
//                                    print("Error login user:", error)
//                                }
//                            }
                            break
                           
                        case 400:
                            DispatchQueue.main.async{
                                self.view.hideHUD()

                                self.callAlert(msg: "Por favor, introduce tu nombre de usuario o email para recuperar la contraseña.")
                            }
                            break
                        case 401:
                            DispatchQueue.main.async{
                                self.view.hideHUD()

                                self.callAlert(msg: "No existe el usuario.")
                            }
                            break
                        case 500:
                            DispatchQueue.main.async{
                                self.view.hideHUD()

                                self.callAlert(msg: "No se ha podido enviar el email al usuario.")
                            }
                            break
                        default:
                            break
                        }
                    }
                    
                    guard let _: Data = data, let _: URLResponse = response, error == nil else {
                        print("*****error")
                        return
                    }
                    
                    //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
                }
                task.resume()
            }
            dataRequest()
            
        //}else {
        //    self.callAlert(msg: "Debe escribir un email valido.")
        //}
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
    }
    
    func setupKeyboardDismissRecognizer(){
        let tapRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(ViewController.dismissKeyboard))
        
        self.view.addGestureRecognizer(tapRecognizer)
    }
    
    @objc func dismissKeyboard()
    {
        view.endEditing(true)
    }
    
   
}
