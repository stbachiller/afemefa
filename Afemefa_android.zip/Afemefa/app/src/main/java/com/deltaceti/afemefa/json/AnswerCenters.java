package com.deltaceti.afemefa.json;

import com.google.gson.JsonArray;

/**
 * Created by arr375 on 13/02/2017.
 */

public class AnswerCenters {

    private String mensaje;
    private JsonArray centros;

    public String getMensaje() {
        return mensaje;
    }

    public JsonArray getCentros() {
        return centros;
    }
}
