//
//  HomePrivada.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 06/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit

class HomePrivada: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var datosPosts : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()
    @IBOutlet weak var tablePosts: UITableView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelNumeroSocio: UILabel!
    @IBOutlet weak var viewMenu: UIView!
    @IBOutlet weak var viewMenuWhite: UIView!
    
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelSubtitle: UILabel!
    @IBOutlet weak var labelMSGUser: UILabel!
    
    @IBOutlet weak var btnMutualista: UIButton!
    @IBOutlet weak var btnCuadroMedico: UIButton!
    @IBOutlet weak var btnCuadroDental: UIButton!
    @IBOutlet weak var btnDescargas: UIButton!
    @IBOutlet weak var btnContacto: UIButton!
    @IBOutlet weak var btnCerrarSesion: UIButton!
    @IBOutlet weak var btnArrow: UIButton!
    @IBOutlet weak var imgBanner: UIImageView!

    
    var isOpenMenu = false
    
    var urlToOpen = ""
    var urlToBlog = ""
    var rc = UIRefreshControl()

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLayoutSubviews() {
        
        DispatchQueue.main.async{
            self.viewMenu.frame =  CGRect(x: 0 - UIScreen.main.bounds.size.width , y: 0, width: UIScreen.main.bounds.size.width - 100, height: UIScreen.main.bounds.size.height)
            self.viewMenuWhite.frame =  CGRect(x: 0 - UIScreen.main.bounds.size.width , y: 0, width:  100, height: UIScreen.main.bounds.size.height)
            
            self.btnArrow.frame =  CGRect(x: UIScreen.main.bounds.size.width - 40, y: 150, width:  self.btnArrow.frame.size.width, height: self.btnArrow.frame.size.height)
            self.viewMenu.isHidden = false

        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        self.labelTitle.text = ""
        self.labelSubtitle.text = ""
        
        let customViewLine = UIView(frame: CGRect(x: self.view.frame.size.width - 61, y: 0 , width: 2, height: self.view.frame.size.height))
        customViewLine.backgroundColor = UIColor(red: 235/255, green: 235/255, blue: 235/255, alpha: 1)
        viewMenu.addSubview(customViewLine)
        
        let userDefaults = UserDefaults.standard
        let user = userDefaults.dictionary(forKey: "user")
        
        self.labelName.text = user?["nombre"] as? String
        let userID = user?["usuario"] as? String
        self.labelNumeroSocio.text = "MUTUALISTA: " + userID!
        
        self.tablePosts.delegate = self
        self.tablePosts.dataSource = self
        
        self.view.showHUD(inView: self.view)
        self.callWsPosts(numPosts: "3", categoria: "")
        let customView = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 60))
        customView.backgroundColor = UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        let button = UIButton(frame: CGRect(x: 10, y: 5, width: UIScreen.main.bounds.size.width - 20, height: 50))
        button.center.x = self.view.center.x
        button.backgroundColor = UIColor.clear
        button.setTitle("Ver más", for: .normal)
        button.titleLabel?.font = UIFont(name: "Ubuntu-Medium", size: 16)
        button.setTitleColor(UIColor.lightGray, for: .normal)
        button.layer.cornerRadius = 5.0
        button.addTarget(self, action: #selector(self.enterAction), for: .touchUpInside)
        customView.addSubview(button)
        self.tablePosts.tableFooterView = customView
        
        
        self.rc.addTarget(self, action: #selector(doPullToRefresh), for: UIControl.Event.valueChanged)
        if #available(iOS 10.0, *) {
            self.tablePosts.refreshControl = self.rc
        } else {
            // Fallback on earlier versions
        }

        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        swipeLeft.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(swipeRight)
        self.view.addGestureRecognizer(swipeLeft)
        
        var tapGesture = UITapGestureRecognizer()
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.myviewTapped(_:)))
        tapGesture.numberOfTapsRequired = 1
        tapGesture.numberOfTouchesRequired = 1
        viewMenuWhite.addGestureRecognizer(tapGesture)
        viewMenuWhite.isUserInteractionEnabled = true
    }
    
    @objc func myviewTapped(_ sender: UITapGestureRecognizer) {
        
        DispatchQueue.main.async{
            self.isOpenMenu = false
            UIView.animate(withDuration: 0.2) {
                self.viewMenu.frame =  CGRect(x: 0 - UIScreen.main.bounds.size.width , y: 0, width: UIScreen.main.bounds.size.width - 60, height: UIScreen.main.bounds.size.height)
                
                self.viewMenuWhite.frame =  CGRect(x: 0 - 60 , y: 0, width:  60, height: UIScreen.main.bounds.size.height)
            }
        }
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.isOpenMenu = true
                DispatchQueue.main.async{
                    UIView.animate(withDuration: 0.2) {
                        self.viewMenu.frame =  CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width - 60, height: UIScreen.main.bounds.size.height)
                        self.viewMenuWhite.frame =  CGRect(x: UIScreen.main.bounds.size.width - 60, y: 0, width:  60, height: UIScreen.main.bounds.size.height)
                    }
                    
                }
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
                DispatchQueue.main.async{
                    self.isOpenMenu = false
                    UIView.animate(withDuration: 0.2) {
                        self.viewMenu.frame =  CGRect(x: 0 - UIScreen.main.bounds.size.width , y: 0, width: UIScreen.main.bounds.size.width - 60, height: UIScreen.main.bounds.size.height)

                        self.viewMenuWhite.frame =  CGRect(x: 0 - 60 , y: 0, width:  60, height: UIScreen.main.bounds.size.height)
                    }
                }
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @objc func doPullToRefresh() {
        
        self.callWsPosts(numPosts: "3", categoria: "")
    }
    
    @IBAction func enterAction(_ sender: Any) {

        //self.view.showHUD(inView: self.view)
        
        //self.callWsPosts(numPosts: "-1", categoria: "")
        
        guard let url = URL(string: self.urlToBlog) else { return }
        UIApplication.shared.open(url)
    }
    
    @IBAction func enterDescargas(_ sender: Any) {
    
        performSegue(withIdentifier: "homePosts_to_descargas", sender: nil)
    }
    
    @IBAction func enterEbookGratuito(_ sender: Any) {
        //performSegue(withIdentifier: "homePosts_to_ebook", sender: nil)
        guard let url = URL(string: self.urlToOpen) else { return }
        UIApplication.shared.open(url)
    }
    
    @IBAction func goToLogin(_ sender: Any) {
        
        let userDefaults = UserDefaults.standard
        userDefaults.set(
            nil, forKey: "user")
        userDefaults.set(nil, forKey: "pass")
        
        self.dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func enterCuadroMedico(_ sender: Any) {
        performSegue(withIdentifier: "homePosts_to_detailMed", sender: nil)
        
    }
    
    @IBAction func enterDental(_ sender: Any) {
        
        performSegue(withIdentifier: "homePosts_to_detailDent", sender: nil)
        
    }
    
    @IBAction func enterContacto(_ sender: Any) {
        performSegue(withIdentifier: "homeToContact_Segue", sender: nil)
        
    }
    
    @IBAction func enterGestionMutualista(_ sender: Any) {
        performSegue(withIdentifier: "homePosts_to_mutualista", sender: nil)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
       
        
    }
    
    func callWsPosts(numPosts: String, categoria: String)  {
        
        let urlToRequest = "\(Constants.serverIP)/posts?numPosts=\(numPosts)"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "GET"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                self.callWSBanner()

                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                DispatchQueue.main.async{

                                    self.datosPosts = json["datos"] as! [Dictionary<String, AnyObject>]
                                    
                                    self.urlToBlog = json["url_blog"] as! String
                                    
                                    self.rc.endRefreshing()
                                    //self.view.hideHUD()
                                    self.tablePosts.reloadData()
                                }
                                
                                
                            } catch let error {
                                //self.view.hideHUD()
                                self.callWSBanner()

                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 204:
                        DispatchQueue.main.async{
                           // self.view.hideHUD()
                            self.callWSBanner()

                            self.callAlert(msg: "No se han encontrado entradas del blog.")
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            //self.view.hideHUD()
                            self.callWSBanner()

                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            //self.view.hideHUD()
                            self.callWSBanner()

                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
    
    
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return "Consejos de salud"
        
    }
    
    
    public func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor =  UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        let headerLabel = UILabel(frame: CGRect(x: 10, y: 10, width:
            tableView.bounds.size.width, height: tableView.bounds.size.height))
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 13)
        headerLabel.textColor = UIColor.lightGray
        headerLabel.text = "Consejos de salud"
        headerLabel.sizeToFit()
        headerView.addSubview(headerLabel)
        
        return headerView
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return self.datosPosts.count
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomePrivadaCellID", for: indexPath) as! HomePrivadaCell
        
        let post = self.datosPosts[indexPath.row]
        cell.detailLabelTxt.text = post["contenidoPlano"] as? String
        cell.titleLabelTxt.text = post["titulo"] as? String
        
//        let dateFormatterGet = DateFormatter()
//        dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
//
//        let dateFormatterPrint = DateFormatter()
//        dateFormatterPrint.dateFormat = "dd MMM yyyy"
//
//        if let date = dateFormatterGet.date(from: (post["fecha_creacion"] as? String)!) {
        cell.dateLabelTxt.text = (post["fecha_creacion"] as! String)//dateFormatterPrint.string(from: date)
//            print(dateFormatterPrint.string(from: date))
//        } else {
//            print("There was an error decoding the string")
//        }
//        cell.dateLabelTxt.text = post["fecha_creacion"] as? String
        cell.imageCell.downloaded(from: (post["url_imagen_destacada"] as? String)!)
        cell.imageCell.clipsToBounds = true
        cell.containerView.layer.cornerRadius = 5.0
        cell.containerView.layer.shadowColor = UIColor.black.cgColor
        cell.containerView.layer.shadowOpacity = 0.5
        cell.containerView.layer.shadowOffset = CGSize.zero
        cell.containerView.layer.shadowRadius = 2
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let post = self.datosPosts[indexPath.row]
        performSegue(withIdentifier: "homePosts_to_detail", sender: post)

    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    
        if segue.identifier == "homePosts_to_detail" {
            if let detailPostViewController = segue.destination as? DetailPost {
                detailPostViewController.datosPost = sender as! Dictionary<String, AnyObject>
                
            }
            
        }else if segue.identifier == "homePosts_to_detailDent" {
            if let detailPostViewController = segue.destination as? SearchCuadroMedicoDental {
                detailPostViewController.isMedical = false
                
            }
            
        }else if segue.identifier == "homePosts_to_detailMed" {
            if let detailPostViewController = segue.destination as? SearchCuadroMedicoDental {
                detailPostViewController.isMedical = true

            }
            
        }
        
    }
    
    @IBAction func enterMenuBtn(_ sender: Any) {
        
        if !isOpenMenu {
            DispatchQueue.main.async{
                UIView.animate(withDuration: 0.2) {
                    self.viewMenu.frame =  CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width - 60, height: UIScreen.main.bounds.size.height)
                    self.viewMenuWhite.frame =  CGRect(x: UIScreen.main.bounds.size.width - 60, y: 0, width:  60, height: UIScreen.main.bounds.size.height)
                }
            }
        }else {
            DispatchQueue.main.async{
                self.isOpenMenu = false
                UIView.animate(withDuration: 0.2) {
                    self.viewMenu.frame =  CGRect(x: 0 - UIScreen.main.bounds.size.width , y: 0, width: UIScreen.main.bounds.size.width - 60, height: UIScreen.main.bounds.size.height)
                    self.viewMenuWhite.frame =  CGRect(x: 0 - 60 , y: 0, width:  60, height: UIScreen.main.bounds.size.height)

                }
            }
        }
    }
    
    func callWSBanner() {
        //self.view.showHUD(inView: self.view)

        let urlToRequest = "\(Constants.serverIP)/slider"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "GET"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                DispatchQueue.main.async{
                                    
                                    print(json["ios"]!["1"] as! Dictionary<String, AnyObject>)
                                    let datos = json["ios"]!["1"] as! Dictionary<String, AnyObject>
                                    self.urlToOpen = (datos["enlace"] as? String)!
                                    self.imgBanner.downloaded(from: datos["imagenes"]!["ST"] as! String)
                                    self.imgBanner.clipsToBounds = true
                                    self.labelTitle.text = datos["titulo"] as? String
                                    self.labelSubtitle.text = datos["texto"] as? String
                                    self.view.hideHUD()
                                }
                                
                                
                            } catch let error {
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 204:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se ha encontrado la página indicada.")
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
    }
    
}

extension UIImageView {
    func downloaded(from url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFill) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleAspectFill) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
    
    
    
    
}
