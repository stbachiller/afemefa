//
//  DetailPost.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 07/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit

class DetailPost: UIViewController {
    

    var datosPost : Dictionary<String, AnyObject> = Dictionary<String, AnyObject>()
    @IBOutlet weak var imagePost: UIImageView!
    @IBOutlet weak var labelTitulo: UILabel!
    @IBOutlet weak var fechaTitulo: UILabel!
    @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var customView : UIView!

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLayoutSubviews() {

        self.customView.layer.shadowColor = UIColor.black.cgColor
        self.customView.layer.shadowOpacity = 0.2
        self.customView.layer.shadowOffset = CGSize.zero
        self.customView.layer.shadowRadius = 2
        self.customView.clipsToBounds = false
        
//        let dateFormatterGet = DateFormatter()
//        dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
//        
//        let dateFormatterPrint = DateFormatter()
//        dateFormatterPrint.dateFormat = "dd MMM yyyy"
//        
//        if let date = dateFormatterGet.date(from: (datosPost["fecha_creacion"] as? String)!) {
        
//            print(dateFormatterPrint.string(from: date))
//        } else {
//            print("There was an error decoding the string")
//        }
        let headerLabel = UILabel(frame: CGRect(x: 5, y: -15, width:
            txtDescription.bounds.size.width, height: 15))

        headerLabel.text = (datosPost["fecha_creacion"] as? String)!
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 13)
        headerLabel.textColor = UIColor(red: 145.0/255, green: 204.0/255, blue: 68.0/255, alpha: 1.0)
        txtDescription.addSubview(headerLabel)
        
        txtDescription.clipsToBounds = false
        txtDescription.scrollRangeToVisible(NSMakeRange(0, 0))
        txtDescription.contentInset = UIEdgeInsets(top: 20.0, left: 0.0, bottom: 0.0, right: 0.0)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        labelTitulo.text = datosPost["titulo"] as? String
        
//        let dateFormatterGet = DateFormatter()
//        dateFormatterGet.dateFormat = "yyyy-MM-dd HH:mm:ss"
//
//        let dateFormatterPrint = DateFormatter()
//        dateFormatterPrint.dateFormat = "dd MMM yyyy"
        
//        if let date = dateFormatterGet.date(from: (datosPost["fecha_creacion"] as? String)!) {
        fechaTitulo.text = (datosPost["fecha_creacion"] as! String)//dateFormatterPrint.string(from: date)
//            print(dateFormatterPrint.string(from: date))
//        } else {
//            print("There was an error decoding the string")
//        }
        
//        fechaTitulo.text = datosPost["fecha_creacion"] as? String
        
        fechaTitulo.isHidden = true
        let str = (datosPost["contenidoHtml"] as! String)
        
        txtDescription.attributedText = str.htmlAttributed(family: "Ubuntu-Light", size: 12.0, color: UIColor.lightGray)
        
        
        //txtDescription.attributedText = str

        imagePost.downloaded(from: (datosPost["url_imagen_destacada"] as? String)!)

        imagePost.clipsToBounds = true
        imagePost.layer.cornerRadius = 3.0
        
        
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
    }
    
   
}

//extension String{
//    func convertHtml() -> NSAttributedString{
//        guard let data = data(using: .utf8) else { return NSAttributedString() }
//        do{
//            return try NSAttributedString(data: data, options: [NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType, NSCharacterEncodingDocumentAttribute: String.Encoding.utf8.rawValue], documentAttributes: nil)
//        }catch{
//            return NSAttributedString()
//        }
//    }
//}

extension String {
    func htmlAttributed(family: String?, size: CGFloat, color: UIColor) -> NSAttributedString? {
        do {
            let htmlCSSString = "<style>" +
                "html *" +
                "{" +
                "font-size: \(size)pt !important;" +
                "color: #\(color.cgColor) !important;" +
                "font-family: \(family ?? "Helvetica"), Helvetica !important;" +
            "}</style> \(self)"
            
            guard let data = htmlCSSString.data(using: String.Encoding.utf8) else {
                return nil
            }
            
            return try NSAttributedString(data: data,
                                          options: [.documentType: NSAttributedString.DocumentType.html,
                                                    .characterEncoding: String.Encoding.utf8.rawValue],
                                          documentAttributes: nil)
        } catch {
            print("error: ", error)
            return nil
        }
    }
}
