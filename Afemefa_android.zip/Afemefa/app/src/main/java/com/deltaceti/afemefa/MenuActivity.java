package com.deltaceti.afemefa;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class MenuActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navView;
    private ImageView more_image;
    private TextView menu_name_tv, lateral_text_tv;
    private LinearLayout close_session_ll;

    android.support.v4.app.FragmentTransaction transaction = null;
    Fragment fragment = null;
    private Gson gson;
    private PrefManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        final Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        prefManager = new PrefManager(getApplicationContext());

        drawerLayout = findViewById(R.id.drawer_layout);
        navView = findViewById(R.id.navview);
        close_session_ll = findViewById(R.id.logout);
        //more_image = findViewById(R.id.more_image);

        close_session_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(
                        MenuActivity.this, R.style.AppThemeDialog);
                builder.setTitle("ATENCIÓN");
                builder.setMessage(getString(R.string.close_session));
                builder.setPositiveButton(getString(R.string.yes),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                prefManager.setUserId("defaultStringIfNothingFound");
                                //prefManager.setMenuLateralText("defaultStringIfNothingFound");
                                Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                                //PrefManager prefManager = new PrefManager(MenuActivity.this);
                                //prefManager.setId("defaultStringIfNothingFound");
                                startActivity(intent);
                                finish();
                            }
                        });

                builder.setNegativeButton(getString(R.string.no),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                dialog.dismiss();
                            }
                        });

                AlertDialog alert = builder.create();
                alert.show();
            }
        });


        navView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {

                        boolean fragmentTransaction = false;
                        Bundle bundle;
                        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) myToolbar.getLayoutParams();

                        if (menuItem.getItemId()==R.id.menu_zone){
                            /*layoutParams.height = RelativeLayout.LayoutParams.WRAP_CONTENT;
                            myToolbar.setLayoutParams(layoutParams);*/

                            //myToolbar.setLayoutParams(new Toolbar.LayoutParams(Toolbar.LayoutParams.MATCH_PARENT, Toolbar.LayoutParams.WRAP_CONTENT));
                            myToolbar.setBackgroundColor(getColor(R.color.transparent));
                        } else {
                            /*final TypedArray styledAttributes = getApplicationContext().getTheme().obtainStyledAttributes(
                                    new int[] { android.R.attr.actionBarSize });
                            int mActionBarSize = (int) styledAttributes.getDimension(0, 0);
                            layoutParams.height = mActionBarSize;
                            myToolbar.setLayoutParams(layoutParams);*/
                            myToolbar.setBackgroundColor(getColor(R.color.blue));
                        }

                        switch (menuItem.getItemId()) {
                            case R.id.menu_zone:
                                myToolbar.getMenu().clear();
                                //more_image.setVisibility(View.GONE);

                                if (Utils.checkConnectivity(MenuActivity.this)) {
                                    fragment = new ZoneFragment();
                                    //bundle = new Bundle();
                                    //bundle.putString("id", id);
                                    //fragment.setArguments(bundle);
                                    fragmentTransaction = true;

                                } else {
                                    Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), MenuActivity.this);
                                }
                                break;

                            case R.id.menu_doctor:
                                myToolbar.getMenu().clear();
                                //more_image.setVisibility(View.GONE);

                                if (Utils.checkConnectivity(MenuActivity.this)) {
                                    fragment = new DoctorFragment();
                                    /*if (events_notifications!=null){
                                        bundle = new Bundle();
                                        bundle.putSerializable("events_notifications", events_notifications);
                                        fragment.setArguments(bundle);
                                    }*/
                                    fragmentTransaction = true;
                                } else {
                                    Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), MenuActivity.this);
                                }
                                break;
                            case R.id.menu_dental:
                                myToolbar.getMenu().clear();
                               // more_image.setVisibility(View.GONE);
                                if (Utils.checkConnectivity(MenuActivity.this)) {
                                    fragment = new ToothFragment();
                                    fragmentTransaction = true;
                                } else {
                                    Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), MenuActivity.this);
                                }
                                break;
                            case R.id.menu_download:
                                //more_image.setVisibility(View.VISIBLE);
                                if (Utils.checkConnectivity(MenuActivity.this)) {
                                    fragment = new DownloadFragment();
                                    fragmentTransaction = true;
                                } else {
                                    Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), MenuActivity.this);
                                }
                                break;
                            case R.id.menu_contact:
                                myToolbar.getMenu().clear();
                                //more_image.setVisibility(View.GONE);
                                fragment = new ContactFragment();
                                fragmentTransaction = true;
                                break;

                            /*case R.id.menu_close_session:
                                AlertDialog.Builder builder = new AlertDialog.Builder(
                                        MenuActivity.this, R.style.AppThemeDialog);
                                builder.setTitle("ATENCIÓN");
                                builder.setMessage(getString(R.string.close_session));
                                builder.setPositiveButton(getString(R.string.yes),
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog,
                                                                int which) {
                                                prefManager.setUserId("defaultStringIfNothingFound");
                                                //prefManager.setMenuLateralText("defaultStringIfNothingFound");
                                                Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                                                //PrefManager prefManager = new PrefManager(MenuActivity.this);
                                                //prefManager.setId("defaultStringIfNothingFound");
                                                startActivity(intent);
                                                finish();
                                            }
                                        });

                                builder.setNegativeButton(getString(R.string.no),
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog,
                                                                int which) {
                                                dialog.dismiss();
                                            }
                                        });

                                AlertDialog alert = builder.create();
                                alert.show();
                                break;*/

                        }

                        if(fragmentTransaction) {

                            changeFragment(menuItem);
                            /*android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
                            FragmentTransaction ft = fragmentManager.beginTransaction();
                            ft.replace(R.id.content_frame, fragment);
                            ft.commit();

                            menuItem.setChecked(true);
                            getSupportActionBar().setTitle(menuItem.getTitle());*/
                        }

                        drawerLayout.closeDrawers();

                        return true;
                    }
                });

        //select the option the first time menu is load

        //navView.getMenu().performIdentifierAction(R.id.menu_zone, 0);


        View headerView = navView.getHeaderView(0);
        menu_name_tv = (TextView) headerView.findViewById(R.id.menu_name);
        lateral_text_tv = (TextView)headerView.findViewById(R.id.lateral_text_tv);

        if (prefManager.getUserInfo().compareTo("defaultStringIfNothingFound")!=0){
            gson = new GsonBuilder().serializeNulls().create();
            User user = gson.fromJson(prefManager.getUserInfo(), User.class);
            Log.d("Afemafa", user.getNombre());
            menu_name_tv.setText(user.getNombre());
            lateral_text_tv.setText("MUTUALISTA: ".concat(user.getUsuario()));
        }

        myToolbar.setBackgroundColor(getColor(R.color.transparent));
        if (Utils.checkConnectivity(MenuActivity.this)) {
            fragment = new EntriesBlogFragment();
            changeFragment(null);
        } else {
            Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), MenuActivity.this);
        }


    }


    private void changeFragment(MenuItem menuItem){
        android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.replace(R.id.content_frame, fragment);
        ft.commit();

        if (menuItem!=null) {
            menuItem.setChecked(true);
            getSupportActionBar().setTitle(menuItem.getTitle());
        } else {
            getSupportActionBar().setTitle("");
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
            default:
                return false;
        }
    }

}
