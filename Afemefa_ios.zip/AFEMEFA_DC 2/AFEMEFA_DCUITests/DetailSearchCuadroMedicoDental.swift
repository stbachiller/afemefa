//
//  DetailSearchCuadroMedicoDental.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 13/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import Contacts


class DetailSearchCuadroMedicoDental: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var datosCentros : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()
    var artworks: [Artwork] = []
    var valoresTabla = ["","","","","","","","",""]
    @IBOutlet weak var tableData: UITableView!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var viewContainerMap: UIView!
    @IBOutlet weak var viewContainerTable: UIView!
    
    let initialLocation = CLLocation(latitude: 40.429974, longitude: -3.704962)
 
    let regionRadius: CLLocationDistance = 10000
    
    func zoomToFitMapAnnotations(mapView: MKMapView) {
        
        var topLeftCoord = CLLocationCoordinate2D()
        topLeftCoord.latitude = -90
        topLeftCoord.longitude = 180
        
        var bottomRightCoord = CLLocationCoordinate2D()
        bottomRightCoord.latitude = 90
        bottomRightCoord.longitude = -180
        
        for annotation in mapView.annotations {
            
            topLeftCoord.longitude = fmin(topLeftCoord.longitude, annotation.coordinate.longitude)
            topLeftCoord.latitude = fmax(topLeftCoord.latitude, annotation.coordinate.latitude)
            
            bottomRightCoord.longitude = fmax(bottomRightCoord.longitude, annotation.coordinate.longitude)
            bottomRightCoord.latitude = fmin(bottomRightCoord.latitude, annotation.coordinate.latitude)
        }
        
        var coordinateRegion = MKCoordinateRegion()
        coordinateRegion.center.latitude = topLeftCoord.latitude - (topLeftCoord.latitude - bottomRightCoord.latitude) * 0.5
        coordinateRegion.center.longitude = topLeftCoord.longitude + (bottomRightCoord.longitude - topLeftCoord.longitude) * 0.5
        coordinateRegion.span.latitudeDelta = fabs(topLeftCoord.latitude - bottomRightCoord.latitude) * 1.1 // Add a little extra space on the sides
        coordinateRegion.span.longitudeDelta = fabs(bottomRightCoord.longitude - topLeftCoord.longitude) * 1.1 // Add a little extra space on the sides
        
        mapView.setRegion(coordinateRegion, animated: true)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)

    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLayoutSubviews() {
       
        self.viewContainerMap.frame = self.mapView.frame
        self.viewContainerTable.frame = self.tableData.frame

        self.mapView.layer.cornerRadius = 5.0

        self.viewContainerMap.layer.cornerRadius = 5.0
        self.viewContainerMap.layer.borderWidth = 0.1
        self.viewContainerMap.layer.shadowColor = UIColor.black.cgColor
        self.viewContainerMap.layer.shadowOpacity = 0.5
        self.viewContainerMap.layer.shadowOffset = CGSize.zero
        self.viewContainerMap.layer.shadowRadius = 5
        
        self.tableData.layer.cornerRadius = 5.0

        self.viewContainerTable.layer.shadowColor = UIColor.black.cgColor
        self.viewContainerTable.layer.shadowOpacity = 0.5
        self.viewContainerTable.layer.shadowOffset = CGSize.zero
        self.viewContainerTable.layer.shadowRadius = 5
        self.viewContainerTable.layer.cornerRadius = 5.0

    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        
        self.tableData.delegate = self
        self.tableData.dataSource = self
        
        addAnnotatiosToArray()
        
        mapView.delegate = self

        //centerMapOnLocation(location: initialLocation)

        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
        
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func addAnnotatiosToArray () {
        
        for index in datosCentros {
            
            let coordenadas = (index["coordenadas"] as! String).components(separatedBy: ",")
            var latitud = Float()
            var longitud = Float()
            
            for i in 0 ... coordenadas.count{

                if i == 0 {
                    latitud = Float(coordenadas[i].replacingOccurrences(of: "(", with: ""))!
                }else if i == 1{
                    longitud = Float(coordenadas[i].replacingOccurrences(of: ")", with: ""))!
                }
            }
            
            let artwork = Artwork(title: index["nombre_centro"] as! String,
                                  direccion: index["direccion"] as! String,
                                  especialidad: index["especialidad"] as! String,
                                  provincia: index["provincia"] as! String,
                                  profSanitario: index["profesional_sanitario"] as! String,
                                  poblacion: index["localidad"] as! String,
                                  telefono: index["telefono"] as! String,
                                  web: index["url"] as! String,
                                  observaciones: index["observaciones"] as! String,
                                  coordinate: CLLocationCoordinate2D(latitude: CLLocationDegrees(latitud), longitude: CLLocationDegrees(longitud)))
            artworks.append(artwork)
        }
        
        
        mapView.addAnnotations(artworks)
        
        self.zoomToFitMapAnnotations(mapView: mapView)
    }
    
    
    func centerMapOnLocation(location: CLLocation) {
        
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate,
                                                  latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return ""
    }
    
    
//    public func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        let headerView = UIView()
//        headerView.backgroundColor =  UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
//
//        let headerLabel = UILabel(frame: CGRect(x: 10, y: 10, width:
//            tableView.bounds.size.width, height: tableView.bounds.size.height))
//        headerLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 13)
//        headerLabel.textColor = UIColor.lightGray
//        headerLabel.text = "Tus seguros"
//        headerLabel.sizeToFit()
//        headerView.addSubview(headerLabel)
//
//        return headerView
//    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return 5
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailSearchCuadroCellID", for: indexPath) as! DetailSearchCuadroCell
        
        switch indexPath.row {
        case 0:
            cell.labelTxt1.text = "Especialidad:"
            cell.labelTxt2.text = "Provincia:"
            cell.detaiLabelTxt1.text = valoresTabla[0]
            cell.detaiLabelTxt2.text = valoresTabla[1]
            break
        case 1:
            cell.labelTxt1.text = "Nombre/Centro:"
            cell.labelTxt2.text = "Profesional sanitario:"
            cell.detaiLabelTxt1.text = valoresTabla[2]
            cell.detaiLabelTxt2.text = valoresTabla[3]
            break
        case 2:
            cell.labelTxt1.text = "Dirección:"
            cell.labelTxt2.text = "Población:"
            cell.detaiLabelTxt1.text = valoresTabla[4]
            cell.detaiLabelTxt2.text = valoresTabla[5]
            break
        case 3:
            cell.labelTxt1.text = "Teléfono:"
            cell.labelTxt2.text = "Web:"
            cell.detaiLabelTxt1.text = valoresTabla[6]
            cell.detaiLabelTxt2.text = valoresTabla[7]
            break
        case 4:
            cell.labelTxt1.text = "Observaciones:"
            cell.labelTxt2.isHidden = true
            cell.detaiLabelTxt1.text = valoresTabla[8]
            cell.detaiLabelTxt2.isHidden = true
            break
        default:
            break
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

    }
}

extension DetailSearchCuadroMedicoDental: MKMapViewDelegate {
    // 1
    
    
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // 2
        guard let annotation = annotation as? Artwork else { return nil }
        // 3
        let identifier = "marker"
        var view: MKMarkerAnnotationView
        // 4
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            as? MKMarkerAnnotationView {
            dequeuedView.annotation = annotation
            view = dequeuedView
        } else {
            // 5
            view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)
            view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            

        }
        
        return view
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView)
    {
        let annotation = view.annotation as! Artwork
        self.valoresTabla[0] = annotation.especialidad
        self.valoresTabla[1] = annotation.provincia
        self.valoresTabla[2] = annotation.title!
        self.valoresTabla[3] = annotation.profSanitario
        self.valoresTabla[4] = annotation.direccion
        self.valoresTabla[5] = annotation.poblacion
        self.valoresTabla[6] = annotation.telefono
        self.valoresTabla[7] = annotation.web
        self.valoresTabla[8] = annotation.observaciones
        
        DispatchQueue.main.async{
            self.tableData.reloadData()
        }
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 calloutAccessoryControlTapped control: UIControl) {
        let location = view.annotation as! Artwork
        
        
        let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
        location.mapItem().openInMaps(launchOptions: launchOptions)
    }
    
    
}


class Artwork: NSObject, MKAnnotation {
    let title: String?
    let direccion: String
    let especialidad: String
    let provincia: String
    let profSanitario: String
    let poblacion: String
    let telefono: String
    let web: String
    let observaciones: String
    let coordinate: CLLocationCoordinate2D
    
    init(title: String, direccion: String, especialidad: String, provincia: String, profSanitario: String, poblacion: String, telefono: String, web: String, observaciones: String, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.direccion = direccion
        self.especialidad = especialidad
        self.provincia = provincia
        self.profSanitario = profSanitario
        self.poblacion = poblacion
        self.telefono = telefono
        self.web = web
        self.observaciones = observaciones
        self.coordinate = coordinate
        
        super.init()
    }
    
    var subtitle: String? {
        return direccion
    }
    
    func mapItem() -> MKMapItem {
        let addressDict = [CNPostalAddressStreetKey: subtitle!]
        let placemark = MKPlacemark(coordinate: coordinate, addressDictionary: addressDict)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = title
        return mapItem
    }
    
}
