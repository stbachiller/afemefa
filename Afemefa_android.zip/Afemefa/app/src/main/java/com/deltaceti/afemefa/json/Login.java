package com.deltaceti.afemefa.json;

/**
 * Created by arr375 on 13/02/2017.
 */

public class Login {

    private String username;
    private String password;
    public Login(String username, String password){
        this.password = password;
        this.username = username;
    }
}
