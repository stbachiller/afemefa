//
//  RegisterUserViewController.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 21/11/2018.
//  Copyright © 2018 Delta Ceti. All rights reserved.
//
import UIKit
import Foundation

class RegisterUserViewController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableData: UITableView!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var viewContainer2: UIView!
    @IBOutlet weak var datePicker: UIDatePicker!
    var activeTextField : UITextField!
    
    var iscommingUpadate = false
    
    var aceptNewsLetter = false
    var aceptTerminos = false
    var dataWS : [String: String] = ["nombre":"","usuario":"","contraseña":"","contraseña2":"","email":"","dni":"","direccion":"","cp":"","localidad":"","provincia":"","pais":"","telefono":"","fechaNac":"","newsLetter":"false","terminos":"false"]
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        
        if self.activeTextField.accessibilityIdentifier != "name" && self.activeTextField.accessibilityIdentifier != "user" &&  self.activeTextField.accessibilityIdentifier != "pass" {
            if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
                if self.view.frame.origin.y == 0 {
                    self.view.frame.origin.y -= keyboardSize.height / 2
                }
            }
        }
        
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.activeTextField.accessibilityIdentifier != "name" && self.activeTextField.accessibilityIdentifier != "user" && self.activeTextField.accessibilityIdentifier != "pass"{
            if self.view.frame.origin.y != 0 {
                self.view.frame.origin.y = 0
            }
        }
        
    }
    
    @objc func dateChanged(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        dataWS["fechaNac"] = dateFormatter.string(from: sender.date)
        self.tableData.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.datePicker.isHidden = true
        self.viewContainer.isHidden = true
        self.viewContainer2.isHidden = true
        self.datePicker.addTarget(self, action: #selector(self.dateChanged), for: .valueChanged)

        (UIApplication.shared.delegate as! AppDelegate).restrictRotation = .portrait
        
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(self.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(self.keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        // Do any additional setup after loading the view, typically from a nib.
        
        self.setupKeyboardDismissRecognizer()

        self.tableData.delegate = self
        self.tableData.dataSource = self
        
        let customView = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 100))
        customView.backgroundColor = UIColor.white//(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        let button = UIButton(frame: CGRect(x: 10, y: 5, width: UIScreen.main.bounds.size.width - 20, height: 50))
        button.center.x = self.view.center.x
        button.backgroundColor = UIColor(red: 164/255, green: 203/255, blue: 82/255, alpha: 1)
        if iscommingUpadate {
            button.setTitle("Enviar", for: .normal)
            button.addTarget(self, action: #selector(self.updateAction), for: .touchUpInside)
        }else  {
            button.setTitle("Registrarse", for: .normal)
            button.addTarget(self, action: #selector(self.enterAction), for: .touchUpInside)
        }
        button.titleLabel!.font = UIFont(name: "Ubuntu-Medium", size: 20)

        button.setTitleColor(UIColor.black, for: .normal)
        button.layer.cornerRadius = 5.0
        //button.addTarget(self, action: #selector(enterAction), for: .touchUpInside)
        
        customView.addSubview(button)
        tableData.tableFooterView = customView

        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
        
        if iscommingUpadate {
            self.view.showHUD(inView: self.view)
            self.labelTitle.text = "Editar perfil"
            self.callWSDAtosUser()
        }
    }
    
    func callWSDAtosUser() {
        
        let userDefaults = UserDefaults.standard
        let user = userDefaults.dictionary(forKey: "user")
        let userID = user?["id"] as? String
        let urlToRequest = "\(Constants.serverIP)/perfil-get/\(userID!)"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "GET"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                DispatchQueue.main.async{
                                  
                                    print(json["usuario"] as! Dictionary<String, AnyObject>)
                                    
                                    self.dataWS["nombre"] = json["usuario"]!["nombre"] as? String
                                    self.dataWS["usuario"] = json["usuario"]!["usuario"] as? String
                                    self.dataWS["email"] = json["usuario"]!["email"] as? String
                                    self.dataWS["dni"] = json["usuario"]!["dni"] as? String
                                    self.dataWS["direccion"] = json["usuario"]!["direccion"] as? String
                                    self.dataWS["cp"] = json["usuario"]!["cp"] as? String
                                    self.dataWS["localidad"] = json["usuario"]!["localidad"] as? String
                                    self.dataWS["provincia"] = json["usuario"]!["provincia"] as? String
                                    self.dataWS["pais"] = json["usuario"]!["pais"] as? String
                                    self.dataWS["telefono"] = json["usuario"]!["telefono"] as? String
                                    self.dataWS["fechaNac"] = json["usuario"]!["fecha_nacimiento"] as? String
                                    self.view.hideHUD()
                                    self.tableData.reloadData()
                                }
                                
                                
                            } catch let error {
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 204:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se han encontrado entradas del blog.")
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "No se han pasado los parámetros correctamente.")
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                            self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
                self.dismiss(animated: true, completion: nil)
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
    
   @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//
//        switch indexPath.section {
//        case 0:
//            return 65.0
//        case 1:
//            return 60.0
//        case 2:
//            return 60.0
//        case 3:
//            return 80.0
//        default:
//            return 60.0
//        }
//        return 65.0
//    }
//    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        switch section {
        case 0:
            return "Crea tu usuario"
        case 1:
            return "Crea tu contraseña"
        case 2:
            return "Otros datos"
        case 3:
            return "Términos del servicio"
        default:
            return ""
        }
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor =  UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        let headerLabel = UILabel(frame: CGRect(x: 15, y: 20, width:
            tableView.bounds.size.width, height: tableView.bounds.size.height))
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 13)
        headerLabel.textColor = UIColor.lightGray
        switch section {
        case 0:
            if iscommingUpadate {
                headerLabel.text = "Edita tu nombre"
            }else {
                headerLabel.text = "Crea tu usuario"
            }
        case 1:
            if iscommingUpadate {
                headerLabel.text = "Edita tu contraseña"
            }else {
                headerLabel.text = "Crea tu contraseña"
            }
        case 2:
            headerLabel.text = "Otros datos"
        case 3:
            headerLabel.text = "Términos del servicio"
        default:
            headerLabel.text = ""
        }
        
        headerLabel.sizeToFit()
        
        let customViewLine = UIView(frame: CGRect(x: 0, y: 39 , width: self.view.frame.size.width, height: 1))
        customViewLine.backgroundColor = UIColor(red: 235/255, green: 235/255, blue: 235/255, alpha: 1)
        headerView.addSubview(customViewLine)
        headerView.addSubview(headerLabel)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0 {
            return 2
        }else if section == 1 {
            return 2
        }else if section == 2 {
            return 9
        }else if section == 3 {
           return 2
        }
        return 0
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "registerUserCell", for: indexPath) as! registerUserCell
        let cell2 = tableView.dequeueReusableCell(withIdentifier: "registerUser2Cell", for: indexPath) as! registerUser2Cell
        
        cell.detailTxt.delegate = self
        cell.detailTxt.isSecureTextEntry = false

        switch indexPath.section {
        case 0:
            if indexPath.row == 0 {
                cell.titleLabel.text = "Nombre"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "name"
                cell.detailTxt.tag = 1
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                if dataWS["nombre"] != "" {
                    cell.detailTxt.text = dataWS["nombre"]
                }
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
            }else {
                if iscommingUpadate {
                    cell.detailTxt.isEnabled = false
                    cell.asterizco.isHidden = true
                }
                cell.titleLabel.text = "Usuario"
                cell.detailTxt.placeholder = "9 dígitos de la tarjeta, sin espacios"
                cell.detailTxt.accessibilityIdentifier = "user"
                cell.detailTxt.tag = 2
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                if dataWS["usuario"] != "" {
                    cell.detailTxt.text = dataWS["usuario"]
                }
            }
            return cell
        case 1:
            if indexPath.row == 0 {
                cell.titleLabel.text = "Contraseña"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "pass"
                cell.detailTxt.tag = 3
                cell.detailTxt.isSecureTextEntry = true
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["contraseña"] != "" {
                    cell.detailTxt.text = dataWS["contraseña"]
                }
            }else  {
                cell.titleLabel.text = "Confirmar contraseña"
                cell.detailTxt.placeholder = "Repite la contraseña"
                cell.detailTxt.accessibilityIdentifier = "pass2"
                cell.detailTxt.tag = 4
                cell.detailTxt.isSecureTextEntry = true
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["contraseña2"] != "" {
                    cell.detailTxt.text = dataWS["contraseña2"]
                }
            }
            return cell
        case 2:
            if indexPath.row == 0 {
                cell.titleLabel.text = "Email"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "email"
                cell.detailTxt.tag = 5
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["email"] != "" {
                    cell.detailTxt.text = dataWS["email"]
                }
            }else if indexPath.row == 1 {
                cell.titleLabel.text = "DNI"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "dni"
                cell.detailTxt.tag = 6
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["dni"] != "" {
                    cell.detailTxt.text = dataWS["dni"]
                }
            }else if indexPath.row == 2 {
                cell.titleLabel.text = "Dirección"
                cell.detailTxt.tag = 7
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "address"
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["direccion"] != "" {
                    cell.detailTxt.text = dataWS["direccion"]
                }
            }else if indexPath.row == 3 {
                cell.titleLabel.text = "C.P."
                cell.detailTxt.tag = 8
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "cp"
                cell.detailTxt.keyboardType = .numberPad
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["cp"] != "" {
                    cell.detailTxt.text = dataWS["cp"]
                }
            }else if indexPath.row == 4 {
                cell.titleLabel.text = "Localidad"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.tag = 9
                cell.detailTxt.accessibilityIdentifier = "localidad"
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["localidad"] != "" {
                    cell.detailTxt.text = dataWS["localidad"]
                }
            }else if indexPath.row == 5 {
                cell.titleLabel.text = "Provincia"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "provincia"
                cell.detailTxt.tag = 10
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["provincia"] != "" {
                    cell.detailTxt.text = dataWS["provincia"]
                }
                
            }else if indexPath.row == 6 {
                cell.titleLabel.text = "País"
                cell.detailTxt.tag = 11
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "pais"
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["pais"] != "" {
                    cell.detailTxt.text = dataWS["pais"]
                }
            }else if indexPath.row == 7 {
                cell.titleLabel.text = "Teléfono"
                cell.detailTxt.placeholder = ""
                cell.detailTxt.accessibilityIdentifier = "telefono"
                cell.detailTxt.tag = 12
                cell.detailTxt.keyboardType = .numberPad
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["telefono"] != "" {
                    cell.detailTxt.text = dataWS["telefono"]
                }
            }else if indexPath.row == 8 {
                cell.titleLabel.text = "Fecha de nac."
                cell.detailTxt.accessibilityIdentifier = "fechaNac"
                cell.detailTxt.placeholder = "dd/mm/aaaa"
                //cell.detailTxt.addTarget(self, action: #selector(dp(_:)), for: .touchUpInside)

                cell.detailTxt.tag = 13
                cell.detailTxt.keyboardType = .emailAddress
                cell.detailTxt.text = ""
                cell.detailTxt.isEnabled = true
                cell.asterizco.isHidden = false
                if dataWS["fechaNac"] != "" {
                    let str = dataWS["fechaNac"]?.replacingOccurrences(of: "/", with: "-")
                    cell.detailTxt.text = str
                }
            }
            return cell
        case 3:
            if indexPath.row == 0 {
                cell2.detailLabel.text = "Acepto recibir la newsletter de AFEMEFA (noticias de salud, actualizaciones del cuadro médico, promociones, etc.)"
                cell2.btnSelect.addTarget(self, action: #selector(selectionBtnNews), for: .touchUpInside)
                if aceptNewsLetter {
                    let textImage = UIImage(named: "check")
                     cell2.btnSelect.setImage(textImage, for: .normal)
                }else {
                    let textImage = UIImage(named: "circle-outline")
                    cell2.btnSelect.setImage(textImage, for: .normal)
                }
                
            cell2.asterizco.isHidden = true
                
            }else if indexPath.row == 1 {
                
                let attributedString = NSMutableAttributedString(string: "Acepto los términos del servicio.")
                //attributedString.addAttribute(.link, value: "https://www.hackingwithswift.com", range: NSRange(location: 11, length: 21))
                attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor(red: 164/255, green: 203/255, blue: 82/255, alpha: 1), range: NSRange(location: 11, length: 21))
                cell2.btnTerminos.addTarget(self, action: #selector(self.openTerminosURL), for: .touchUpInside)
                cell2.detailLabel.attributedText = attributedString
                    
                cell2.btnSelect.addTarget(self, action: #selector(selectionBtnTerminos), for: .touchUpInside)
                if aceptTerminos {
                    let textImage = UIImage(named: "check")
                    cell2.btnSelect.setImage(textImage, for: .normal)
                }else {
                    let textImage = UIImage(named: "circle-outline")
                    cell2.btnSelect.setImage(textImage, for: .normal)
                }
                
                cell2.asterizco.isHidden = false

            }
            return cell2
        default:
            break
        }
        
        return cell
    }
    
    @objc func selectionBtnNews() {
        if aceptNewsLetter {
            aceptNewsLetter = false
            dataWS["newsLetter"] = "false"
        }else {
            aceptNewsLetter = true
            dataWS["newsLetter"] = "true"
        }
        
        DispatchQueue.main.async{
            self.tableData.reloadData()
        }
    }
    
    @objc func selectionBtnTerminos() {
        if aceptTerminos {
            aceptTerminos = false
            dataWS["terminos"] = "false"
        }else {
            aceptTerminos = true
            dataWS["terminos"] = "true"
        }
        DispatchQueue.main.async{
            self.tableData.reloadData()
        }
    }
    
    @objc func openTerminosURL() {
        
        self.view.showHUD(inView: self.view)
        
        let urlToRequest = "\(Constants.serverIP)/textos-legales"
        func dataRequest() {
            let url4 = URL(string: urlToRequest)!
            let session4 = URLSession.shared
            let request = NSMutableURLRequest(url: url4)
            request.httpMethod = "POST"
            
            //request.httpBody = paramString.data(using: String.Encoding.utf8)
            let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                
                if let response = response as? HTTPURLResponse {
                    
                    switch response.statusCode {
                    case 200:
                        if let data = data {
                            do {
                                
                                let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                
                                DispatchQueue.main.async{
                                    self.view.hideHUD()
                                    guard let url = URL(string: json["url"] as! String) else { return }
                                    UIApplication.shared.open(url)
                                }
                                print(json)
                                
                            } catch let error {
                                self.view.hideHUD()
                                
                                print("Error login user:", error)
                            }
                        }
                        break
                    case 400:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                        }
                        break
                    case 401:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                        }
                        break
                    case 500:
                        DispatchQueue.main.async{
                            self.view.hideHUD()
                        }
                        
                    default:
                        break
                    }
                }
                
                guard let _: Data = data, let _: URLResponse = response, error == nil else {
                    print("*****error")
                    return
                }
                
                //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
            }
            task.resume()
        }
        dataRequest()
    
        
        /*guard let url = URL(string: "https://api.afemefa.oficina.splink.es/textos-legales") else { return }
        UIApplication.shared.open(url)*/
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        switch textField.tag {
            
        case 1:
            dataWS["nombre"] = textField.text!
        
            break
        case 2:
            dataWS["usuario"] = textField.text!
            
            break
        case 3:
            dataWS["contraseña"] = textField.text!
            
            break
        case 4:
            dataWS["contraseña2"] = textField.text!
            
            break
        case 5:
            dataWS["email"] = textField.text!
            
            break
        case 6:
            dataWS["dni"] = textField.text!
            
            break
        case 7:
            dataWS["direccion"] = textField.text!
            
            break
        case 8:
            dataWS["cp"] = textField.text!
            
            break
        case 9:
            dataWS["localidad"] = textField.text!
            
            break
        case 10:
            dataWS["provincia"] = textField.text!
            
            break
        case 11:
            dataWS["pais"] = textField.text!
            
            break
        case 12:
            dataWS["telefono"] = textField.text!
            
            break
        case 13:
            dataWS["fechaNac"] = textField.text!
            
            break
        default:
            break
        }
        textField.resignFirstResponder()
    }
    
    func setupKeyboardDismissRecognizer(){
        let tapRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(ViewController.dismissKeyboard))
        
        self.view.addGestureRecognizer(tapRecognizer)
    }
    
    @objc func dismissKeyboard()
    {
        self.datePicker.isHidden = true
        self.viewContainer.isHidden = true
        self.viewContainer2.isHidden = true
        view.endEditing(true)
    }
    
    @IBAction func enterAction(_ sender: Any) {
        
        if self.validateFields() != ""{
            DispatchQueue.main.async{
                self.callAlert(msg: "Debe revisar los siguientes campos:\n\(self.validateFields())")
            }
        }else {
            
            self.view.showHUD(inView: self.view)
            
            let urlToRequest = "\(Constants.serverIP)/registro"
            func dataRequest() {
                let url4 = URL(string: urlToRequest)!
                let session4 = URLSession.shared
                let request = NSMutableURLRequest(url: url4)
                request.httpMethod = "POST"
                
                //var dateScape = String(describing: dataWS["fechaNac"]!)
                let str = dataWS["fechaNac"]!.replacingOccurrences(of: "/", with: "-")
               //let replaced = dateScape.replacingOccurrences(of: "/", with: "\/")//.stringByReplacingOccurrencesOfString("\"", withString: " ")
                
                request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
                let paramString = "first_name=\(String(describing: dataWS["nombre"]!))&user_login=\(String(describing: dataWS["usuario"]!))&pass1=\(String(describing: dataWS["contraseña"]!))&pass2=\(String(describing: dataWS["contraseña2"]!))&user_email=\(String(describing: dataWS["email"]!))&dni=\(String(describing: dataWS["dni"]!))&direccion=\(String(describing: dataWS["direccion"]!))&codigo_postal=\(String(describing: dataWS["cp"]!))&localidad=\(String(describing: dataWS["localidad"]!))&provincia=\(String(describing: dataWS["provincia"]!))&pais=\(String(describing: dataWS["pais"]!))&telefono=\(String(describing: dataWS["telefono"]!))&fecha_nacimiento=\(String(describing: str))&newsletter=\(String(describing: dataWS["newsLetter"]!))"
                
                //request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = paramString.data(using: String.Encoding.utf8, allowLossyConversion: false)
                
                //request.httpBody = paramString.data(using: String.Encoding.utf8)
                let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                    
                    if let response = response as? HTTPURLResponse {
                        
                        switch response.statusCode {
                        case 200:
                            if let data = data {
                                do {
                                    
                                    let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                    
                                    DispatchQueue.main.async{
                                        self.view.hideHUD()
                                        self.callAlert(msg: "\(String(describing: json["mensaje"] as! String))")
                                    }
                                    print(json)
                                    
                                } catch let error {
                                    self.view.hideHUD()
                                    self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                    print("Error login user:", error)
                                }
                            }
                            break
                        case 400:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            break
                        case 401:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Usuario ya registrado (ya existe un usuario con el username de entrada o ya existe un usuario con el email de entrada")
                            }
                            break
                        case 500:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            
                        default:
                            break
                        }
                    }
                    
                    guard let _: Data = data, let _: URLResponse = response, error == nil else {
                        print("*****error")
                        return
                    }
                    
                    //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
                }
                task.resume()
            }
            dataRequest()
        }
        
    }
    
    func validateFields() -> String {
     
        print(dataWS)
        
        var mensaje = ""
        
        if dataWS["nombre"] == "" {
            mensaje = "Nombre"
        }
        
        if dataWS["usuario"] == "" {
            mensaje = mensaje + "\nUsuario"
        }
        
        if dataWS["contraseña"] == "" {
            mensaje = mensaje + "\nContraseña"
        }else if  dataWS["contraseña2"] != dataWS["contraseña"]{
            if !iscommingUpadate {
                mensaje = "La contraseña y su confirmacion deben coincidir"
            }
            return mensaje
        }
        
        
        
        if dataWS["email"] == "" || !isValidEmail(email: dataWS["email"]) {
            mensaje = mensaje + "\nEmail"
        }
        
        if dataWS["dni"] == "" {
            mensaje = mensaje + "\nDNI"
        }
        
        if dataWS["direccion"] == "" {
            mensaje = mensaje + "\nDirección"
        }
        
        if dataWS["cp"] == "" {
            mensaje = mensaje + "\nCP"
        }
        
        if dataWS["localidad"] == "" {
            mensaje = mensaje + "\nLocalidad"
        }
        
        if dataWS["provincia"] == "" {
            mensaje = mensaje + "\nProvincia"
        }
        
        if dataWS["pais"] == "" {
            mensaje = mensaje + "\nPaís"
        }
        
        if dataWS["telefono"] == "" || dataWS["telefono"]!.count != 9 {
            mensaje = mensaje + "\nTeléfono"
        }
        
        if dataWS["fechaNac"] == "" || !self.isvalidDate(date: dataWS["fechaNac"]){
            mensaje = mensaje + "\nFecha de nacimiento"
        }
        
        if !aceptTerminos  {
            mensaje = mensaje + "\nAceptar términos del servicio"
        }
        return mensaje
        
    }
    
    func isValidEmail(email:String?) -> Bool {
        
        guard email != nil else { return false }
        
        let regEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let pred = NSPredicate(format:"SELF MATCHES %@", regEx)
        return pred.evaluate(with: email)
    }
    
    func isvalidDate(date:String?) -> Bool {
        
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "dd-MM-yyyy"
        
        
        if dateFormatterGet.date(from: date!) != nil {
            return true

        } else {
            // invalid format
            return false

        }
        
    }
    
    func callAlert(msg:String?) {
        let alert = UIAlertController(title: "Aviso", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    @IBAction func updateAction(_ sender: Any) {
        
        if self.validateFieldsUpdate() != ""{
            DispatchQueue.main.async{
                self.callAlert(msg: "Debe revisar los siguientes campos:\n\(self.validateFields())")
            }
        }else {
            
            self.view.showHUD(inView: self.view)
            
            let userDefaults = UserDefaults.standard
            let user = userDefaults.dictionary(forKey: "user")
            
            let urlToRequest = "\(Constants.serverIP)/perfil-update"
            func dataRequest() {
                let url4 = URL(string: urlToRequest)!
                let session4 = URLSession.shared
                let request = NSMutableURLRequest(url: url4)
                request.httpMethod = "POST"
                
                let str = dataWS["fechaNac"]!.replacingOccurrences(of: "/", with: "-")

                //let replaced = dateScape.replacingOccurrences(of: "/", with: "\/")//.stringByReplacingOccurrencesOfString("\"", withString: " ")
                
                request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
                
                let paramString = "first_name=\(String(describing: dataWS["nombre"]!))&user_id=\(String(describing: user!["id"] as! String))&user_login=\(String(describing: dataWS["usuario"]!))&pass1=\(String(describing: dataWS["contraseña"]!))&pass2=\(String(describing: dataWS["contraseña2"]!))&user_email=\(String(describing: dataWS["email"]!))&dni=\(String(describing: dataWS["dni"]!))&direccion=\(String(describing: dataWS["direccion"]!))&codigo_postal=\(String(describing: dataWS["cp"]!))&localidad=\(String(describing: dataWS["localidad"]!))&provincia=\(String(describing: dataWS["provincia"]!))&pais=\(String(describing: dataWS["pais"]!))&telefono=\(String(describing: dataWS["telefono"]!))&fecha_nacimiento=\(String(describing: str))&newsletter=\(String(describing: dataWS["newsLetter"]!))"
                
                //request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = paramString.data(using: String.Encoding.utf8, allowLossyConversion: false)
                
                //request.httpBody = paramString.data(using: String.Encoding.utf8)
                let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
                    
                    if let response = response as? HTTPURLResponse {
                        
                        switch response.statusCode {
                        case 200:
                            if let data = data {
                                do {
                                    
                                    let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! Dictionary<String, AnyObject>
                                    
                                    DispatchQueue.main.async{
                                        self.view.hideHUD()
                                        self.callAlert(msg: "Registro acutalizado correctamente.")
                                    }
                                    print(json)
                                    
                                } catch let error {
                                    self.view.hideHUD()
                                    self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                                    print("Error login user:", error)
                                }
                            }
                            break
                        case 400:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            break
                        case 401:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Usuario ya registrado (ya existe un usuario con el username de entrada o ya existe un usuario con el email de entrada")
                            }
                            break
                        case 500:
                            DispatchQueue.main.async{
                                self.view.hideHUD()
                                self.callAlert(msg: "Error al procesar los datos, intentelo de nuevo.")
                            }
                            
                        default:
                            break
                        }
                    }
                    
                    guard let _: Data = data, let _: URLResponse = response, error == nil else {
                        print("*****error")
                        return
                    }
                    
                    //                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    //                    print("*****This is the data 4: \(dataString)") //JSONSerialization
                }
                task.resume()
            }
            dataRequest()
        }
    }
    
    func validateFieldsUpdate() -> String {
        
        print(dataWS)
        
        var mensaje = ""
        
        if dataWS["nombre"] == "" {
            mensaje = "Nombre"
        }
        
        if dataWS["usuario"] == "" {
            mensaje = mensaje + "\nUsuario"
        }
        
//        if dataWS["contraseña"] == "" {
//            mensaje = mensaje + "\nContraseña"
//        }
        
        if dataWS["contraseña2"] != dataWS["contraseña"]{
            mensaje = "La contraseña y su confirmacion deben coincidir"
            return mensaje
        }
        
        if dataWS["email"] == "" || !isValidEmail(email: dataWS["email"]) {
            mensaje = mensaje + "\nEmail"
        }
        
        if dataWS["dni"] == "" {
            mensaje = mensaje + "\nDNI"
        }
        
        if dataWS["direccion"] == "" {
            mensaje = mensaje + "\nDireccion"
        }
        
        if dataWS["cp"] == "" {
            mensaje = mensaje + "\nCP"
        }
        
        if dataWS["localidad"] == "" {
            mensaje = mensaje + "\nLocalidad"
        }
        
        if dataWS["provincia"] == "" {
            mensaje = mensaje + "\nProvincia"
        }
        
        if dataWS["pais"] == "" {
            mensaje = mensaje + "\nPais"
        }
        
        if dataWS["telefono"] == "" || dataWS["telefono"]!.count != 9 {
            mensaje = mensaje + "\nTelefono"
        }
        
        if dataWS["fechaNac"] == "" || !self.isvalidDate(date: dataWS["fechaNac"]){
            mensaje = mensaje + "\nFecha de nacimiento"
        }
        
        if !aceptTerminos  {
            mensaje = mensaje + "\nAceptar términos del servicio"
        }
        return mensaje
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.activeTextField = textField

        if textField.tag == 13 {
            self.datePicker.isHidden = false
            self.viewContainer.isHidden = false
            self.viewContainer2.isHidden = false
            return false
        }
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    
    func textFieldShouldReturn(_ scoreText: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    
}
