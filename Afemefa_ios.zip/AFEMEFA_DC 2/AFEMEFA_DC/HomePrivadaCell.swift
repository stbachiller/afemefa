//
//  HomePrivadaCell.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 06/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit

class HomePrivadaCell: UITableViewCell {
    
    @IBOutlet weak var titleLabelTxt: UILabel!
    @IBOutlet weak var detailLabelTxt: UILabel!
    @IBOutlet weak var dateLabelTxt: UILabel!
    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var containerView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
