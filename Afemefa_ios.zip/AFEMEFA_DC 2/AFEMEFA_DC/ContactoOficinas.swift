//
//  ContactoOficinas.swift
//  AFEMEFA_DC
//
//  Created by Cristina Hortelano on 13/12/2018.
//  Copyright © 2018 RiverSnap. All rights reserved.
//

import Foundation
import UIKit
import MessageUI

class ContactoOficinas: UIViewController, UITableViewDataSource, UITableViewDelegate, MFMailComposeViewControllerDelegate {
    
//    var datosOficinas : [Dictionary<String, AnyObject>] = [Dictionary<String, AnyObject>]()

    @IBOutlet weak var tableData: UITableView!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.tableData.dataSource = self
        self.tableData.delegate = self
        self.tableData.layer.cornerRadius = 5.0
        self.tableData.clipsToBounds = true
    }
    
    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        switch section {
        case 0:
            return "AFEMEFA Madrid"
            
        case 1:
            return "AFEMEFA Valladolid"
            
        default:
            break
        }
        return "AFEMEFA Madrid"
    }
    
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor =  UIColor.clear
        
        let headerLabel = UILabel(frame: CGRect(x: 10, y: 20, width:
            tableView.bounds.size.width, height: tableView.bounds.size.height))
        if UIDevice().userInterfaceIdiom == .phone {
            switch UIScreen.main.nativeBounds.height {
            case 1136:
                print("iPhone 5 or 5S or 5C")
                headerLabel.frame = CGRect(x: 10, y: 5, width:
                    tableView.bounds.size.width, height: tableView.bounds.size.height)

            case 1334:
                print("iPhone 6/6S/7/8")
                headerLabel.frame = CGRect(x: 10, y: 5, width:
                    tableView.bounds.size.width, height: tableView.bounds.size.height)

            case 2208:
                print("iPhone 6+/6S+/7+/8+")
            case 2436:
                print("iPhone X")
                headerLabel.frame = CGRect(x: 10, y: 10, width:
                    tableView.bounds.size.width, height: tableView.bounds.size.height)
            default:
                print("unknown")
            }
        }
        headerLabel.font = UIFont(name: "OpenSans-Bold", size: 15)
        headerLabel.textColor = UIColor(red: 105.0/255.0, green: 155.0/255.0, blue: 199.0/255.0, alpha: 1.0)
        switch section {
        case 0:
            headerLabel.text = "AFEMEFA Madrid"
            
        case 1:
            headerLabel.text = "AFEMEFA Valladolid"
            
        default:
            break
        }
        headerLabel.sizeToFit()
        headerView.addSubview(headerLabel)
        
        return headerView
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 3
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactoOficinasCell", for: indexPath) as! ContactoOficinasCell
        
        let customViewLine = UIView(frame: CGRect(x: 10, y: 59 , width: self.view.frame.size.width, height: 1))
        customViewLine.backgroundColor = UIColor(red: 235/255, green: 235/255, blue: 235/255, alpha: 1)
        cell.addSubview(customViewLine)
        
        switch indexPath.section {
        case 0:
            if indexPath.row == 0 {
                cell.imageCell.image = UIImage(named: "icon-house")
                cell.labelTxt?.text = "C/Murcia, 10 Bajo B.28045-Madrid"
                cell.layer.cornerRadius = 5.0
                cell.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
//                cell.layer.shadowColor = UIColor.black.cgColor
//                cell.layer.shadowOpacity = 0.8
//                cell.layer.shadowOffset = CGSize.zero
//                cell.layer.shadowRadius = 5
            }else if indexPath.row == 1 {
                cell.imageCell.image = UIImage(named: "icon-email")
                cell.labelTxt?.text = "afemefa@afemefa.com"
                cell.layer.cornerRadius = 0.0

            }else if indexPath.row == 2 {
                cell.imageCell.image = UIImage(named: "icon-phonepng")
                cell.labelTxt?.text = "915 280 582 - 915 208 203"
                cell.layer.cornerRadius = 5.0
                cell.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
//                cell.layer.shadowColor = UIColor.black.cgColor
//                cell.layer.shadowOpacity = 0.8
//                cell.layer.shadowOffset = CGSize.zero
//                cell.layer.shadowRadius = 5
            }
            break
        case 1:
            if indexPath.row == 0 {
                cell.layer.cornerRadius = 5.0
                cell.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
//                cell.layer.shadowColor = UIColor.black.cgColor
//                cell.layer.shadowOpacity = 0.8
//                cell.layer.shadowOffset = CGSize.zero
//                cell.layer.shadowRadius = 5
                cell.imageCell.image = UIImage(named: "icon-house")
                cell.labelTxt?.text = "C/Regalado, 8. 47002 - Valladolid"
            }else if indexPath.row == 1 {
                cell.imageCell.image = UIImage(named: "icon-email")
                cell.labelTxt?.text = "valladolid@afemefa.com"
                cell.layer.cornerRadius = 0.0
//                cell.layer.shadowColor = UIColor.black.cgColor
//                cell.layer.shadowOpacity = 0.8
//                cell.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
//                cell.layer.shadowRadius = 5
//                let shadowRect: CGRect = cell.bounds.insetBy(dx: 0, dy: 0)
//                cell.layer.shadowPath = UIBezierPath(rect: shadowRect).cgPath
                
//                let shadowSize : CGFloat = 5.0
//                let shadowPath = UIBezierPath(rect: CGRect(x: -shadowSize / 2,
//                                                           y: -shadowSize / 2,
//                                                           width: cell.frame.size.width + shadowSize,
//                                                           height: cell.frame.size.height + shadowSize))
//                cell.layer.masksToBounds = false
//                cell.layer.shadowColor = UIColor.black.cgColor
//                let contactRect = CGRect(x: -shadowSize, y: height - (shadowSize * 0.4), width: width + shadowSize * 2, height: shadowSize)
//
//                cell.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
//                cell.layer.shadowOpacity = 0.5
//                cell.layer.shadowPath = shadowPath.cgPath
                
            }else if indexPath.row == 2 {
                cell.imageCell.image = UIImage(named: "icon-phonepng")
                cell.labelTxt?.text = "983 30 64 16"
                cell.layer.cornerRadius = 5.0
                cell.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
//                cell.layer.shadowColor = UIColor.black.cgColor
//                cell.layer.shadowOpacity = 0.8
//                cell.layer.shadowOffset = CGSize.zero
//                cell.layer.shadowRadius = 5
            }
            
            break
        default:
            break
        }
        cell.clipsToBounds = false

        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        switch indexPath.section {
        case 0:
            if indexPath.row == 0 {
            }else if indexPath.row == 1 {
                //cell.imageCell.image = UIImage(named: "icon-email")
                //cell.labelTxt?.text = "afemefa@afemefa.com"
                if MFMailComposeViewController.canSendMail() {
                    let mail = MFMailComposeViewController()
                    mail.mailComposeDelegate = self
                    mail.setToRecipients(["afemefa@afemefa.com"])
                    mail.setMessageBody("<p></p>", isHTML: true)
                    
                    present(mail, animated: true)
                }
            }else if indexPath.row == 2 {
                UIApplication.shared.openURL(NSURL(string: "tel://915280582")! as URL)
            }
            break
        case 1:
            if indexPath.row == 0 {
            }else if indexPath.row == 1 {
                //cell.labelTxt?.text = "valladolid@afemefa.com"
                if MFMailComposeViewController.canSendMail() {
                    let mail = MFMailComposeViewController()
                    mail.mailComposeDelegate = self
                    mail.setToRecipients(["valladolid@afemefa.com"])
                    mail.setMessageBody("<p></p>", isHTML: true)
                    
                    present(mail, animated: true)
                }
            }else if indexPath.row == 2 {
                UIApplication.shared.openURL(NSURL(string: "tel://983306416")! as URL)
            }
            break
        default:
            break
        }
        
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }

    
}
