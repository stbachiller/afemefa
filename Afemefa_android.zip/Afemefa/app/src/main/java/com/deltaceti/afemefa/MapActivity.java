package com.deltaceti.afemefa;

import android.Manifest;
import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.CenterDoctor;
import com.deltaceti.afemefa.json.User;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileNotFoundException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MapActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, OnMapReadyCallback, LocationListener {

    private GoogleMap mMap;
    MapView mMapView;

    private Marker currLocationMarker;
    private MarkerOptions markerOptions;

    private GoogleApiClient apiClient;
    private Geocoder geocoder;
    private Gson gson;

    private List<CenterDoctor> centers;
    private HashMap<Marker, CenterDoctor> markerHashMap;

    private TextView speciality_tv, province_tv, professional_tv, center_tv, address_tv, city_tv,
                     phone_tv, web_tv, observations_tv;
    private LinearLayout details_ll, web_ll, phone_ll;

    private static final int PETICION_PERMISO_LOCALIZACION = 101;

    private PrefManager pref_manager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Log.d("AFEMAFA", "1");

        /*Intent intent = this.getIntent();
        Bundle bundle = intent.getExtras();
        centers = (ArrayList<CenterDoctor>) bundle.getSerializable("centers");
        Log.d("AFEMAFA", "2");*/

        pref_manager = new PrefManager(MapActivity.this);
        if (pref_manager.getCenters().compareTo("defaultStringIfNothingFound")!=0) {
            gson = new GsonBuilder().serializeNulls().create();
            Type type = new TypeToken<List<CenterDoctor>>(){}.getType();
            centers = gson.fromJson(pref_manager.getCenters(), type);
        }


        details_ll = findViewById(R.id.details_ll);
        speciality_tv = findViewById(R.id.speciality_tv);
        province_tv = findViewById(R.id.province_tv);
        center_tv = findViewById(R.id.center_tv);
        professional_tv = findViewById(R.id.professional_tv);
        city_tv = findViewById(R.id.city_tv);
        address_tv = findViewById(R.id.address_tv);
        phone_tv = findViewById(R.id.phone_tv);
        web_tv = findViewById(R.id.web_tv);
        observations_tv = findViewById(R.id.observations_tv);

        phone_ll = findViewById(R.id.phone_ll);
        web_ll = findViewById(R.id.web_ll);

        MapFragment mapFragment = (MapFragment) getFragmentManager()
                .findFragmentById(R.id.map);

        phone_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uri = "tel:" + phone_tv.getText().toString().trim() ;
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse(uri));
                startActivity(intent);
            }
        });

        web_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = web_tv.getText().toString().trim();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });


        Log.d("AFEMAFA", "asasdasd");

        MapsInitializer.initialize(getApplicationContext());
        //locationText = rootView.findViewById(R.id.textLocation);
       // mMapView = (MapView) findViewById(R.id.map);
        //mMapView.onCreate(savedInstanceState);

        mapFragment.getMapAsync(this);



        markerOptions = new MarkerOptions();
        geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
        Log.d("AFEMAFA", "Start");

    }

    protected synchronized void buildGoogleApiClient() {
        apiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
    }


    public void requestLocationUpdates() {

        if (ContextCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {

            Location lastLocation =
                    LocationServices.FusedLocationApi.getLastLocation(apiClient);

            if (lastLocation != null) {
                //place marker at current position
                //mGoogleMap.clear();
                markerHashMap = new HashMap<Marker, CenterDoctor>();
                LatLng latLng = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                //markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.title("Tu posición");
                //markerOptions.snippet(getAddress(latLng));
                markerOptions.icon(BitmapDescriptorFactory.defaultMarker(209.0f));
                //markerOptions.icon(BitmapDescriptorFactory.defaultMarker(R.color.colorPrimaryUser));
                currLocationMarker = mMap.addMarker(markerOptions);
                currLocationMarker.showInfoWindow();


                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(latLng).zoom(14).build();

                for (CenterDoctor center : centers) {
                    String coordenadas = center.getCoordenadas();
                    Log.d("AFEMAFA", center.toString());
                    coordenadas = coordenadas.substring(1, coordenadas.length()-2);
                    coordenadas.split(",");
                    String coordinadas_array[] = coordenadas.split(",");
                    LatLng position = new LatLng(Double.parseDouble(coordinadas_array[0]), Double.parseDouble(coordinadas_array[1]));
                    if (coordinadas_array.length==2) {
                        Marker marker = mMap.addMarker(new MarkerOptions()
                                .position(position)
                                .snippet(center.getDireccion())
                                .title(center.getNombre_centro())
                                .icon(BitmapDescriptorFactory.defaultMarker(79.0f)));
                        markerHashMap.put(marker, center);
                    }
                }

                mMap.animateCamera(CameraUpdateFactory
                        .newCameraPosition(cameraPosition));

                mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {

                    @Override
                    public boolean onMarkerClick(Marker marker) {
                        //locationText.setText(marker.getTitle());
                        int zoom = (int)mMap.getCameraPosition().zoom;
                        CameraUpdate cu = CameraUpdateFactory.newLatLngZoom(new
                                LatLng(marker.getPosition().latitude + (double)90/Math.pow(4, zoom),
                                marker.getPosition().longitude), zoom);
                        mMap.animateCamera(cu,500,null);

                        if (markerHashMap.get(marker) != null) {
                            CenterDoctor center_selected = markerHashMap.get(marker);
                            //Toast.makeText(getApplicationContext(), center_selected.getProfesional_sanitario(), Toast.LENGTH_LONG).show();
                            marker.showInfoWindow();
                            speciality_tv.setText(center_selected.getEspecialidad());
                            province_tv.setText(center_selected.getProvincia());
                            center_tv.setText(center_selected.getNombre_centro());
                            professional_tv.setText(center_selected.getProfesional_sanitario());
                            address_tv.setText(center_selected.getDireccion());
                            city_tv.setText(center_selected.getLocalidad());
                            phone_tv.setText(center_selected.getTelefono());
                            web_tv.setText(center_selected.getWeb());
                            observations_tv.setText(center_selected.getObservaciones());
                            details_ll.setVisibility(View.VISIBLE);
                        } else {
                            details_ll.setVisibility(View.GONE);
                        }
                        return Boolean.TRUE;
                    }

                });
            }

        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PETICION_PERMISO_LOCALIZACION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PETICION_PERMISO_LOCALIZACION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    this.requestLocationUpdates();

                    return;
                }

                // other 'case' lines to check for other
                // permissions this app might request
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                super.onBackPressed();
                break;
        }
        return true;
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        Log.d("AFEMAFA", "Connected");
        requestLocationUpdates();
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.d("AFEMAFA", "Suspended");
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.d("AFEMAFA", "Failed");
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        buildGoogleApiClient();
        apiClient.connect();
        Log.d("AFEMAFA", "Ready");
        mMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

            @Override
            public View getInfoWindow(Marker arg0) {
                return null;
            }

            @Override
            public View getInfoContents(Marker marker) {

                LinearLayout info = new LinearLayout(getApplicationContext());
                info.setOrientation(LinearLayout.VERTICAL);

                TextView title = new TextView(getApplicationContext());
                title.setTextColor(Color.BLACK);
                title.setGravity(Gravity.CENTER);
                title.setTypeface(null, Typeface.BOLD);
                title.setMaxLines(5);
                title.setText(marker.getTitle());

                TextView snippet = new TextView(getApplicationContext());
                snippet.setTextColor(Color.GRAY);
                snippet.setText(marker.getSnippet());
                snippet.setGravity(Gravity.CENTER);

                info.addView(title);
                info.addView(snippet);

                return info;
            }
        });
    }

    @Override
    public void onLocationChanged(Location location) {
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        markerOptions.position(latLng);
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(169.0f));
        currLocationMarker = mMap.addMarker(markerOptions);

        //zoom to current position:
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(latLng).zoom(14).build();

        mMap.animateCamera(CameraUpdateFactory
                .newCameraPosition(cameraPosition));
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
}
