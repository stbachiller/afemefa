package com.deltaceti.afemefa.json;

import com.google.gson.JsonElement;

/**
 * Created by arr375 on 13/02/2017.
 */

public class Answer {

    private String mensaje;
    private JsonElement usuario;


    public JsonElement getData() {
        return usuario;
    }


}
