package com.deltaceti.afemefa.json;

/**
 * Created by arr375 on 13/02/2017.
 */

public class User {

    private String id;
    private String usuario;
    private String nombre;
    private String email;
    private String dni;
    private String direccion;
    private String cp;
    private String localidad;
    private String provincia;
    private String pais;
    private String telefono;
    private String fecha_nacimiento;

    public String getId() {
        return id;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getDni() {
        return dni;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getCp() {
        return cp;
    }

    public String getLocalidad() {
        return localidad;
    }

    public String getProvincia() {
        return provincia;
    }

    public String getPais() {
        return pais;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public String getNewsletter() {
        return newsletter;
    }

    public String getActive() {
        return active;
    }

    private String newsletter;
    private String active;

    public User(String id, String usuario, String nombre, String email, String dni, String direccion, String cp, String localidad, String provincia, String pais, String fecha_nacimiento, String newsletter, String active) {
        this.id = id;
        this.usuario = usuario;
        this.nombre = nombre;
        this.email = email;
        this.dni = dni;
        this.direccion = direccion;
        this.cp = cp;
        this.localidad = localidad;
        this.provincia = provincia;
        this.pais = pais;
        this.fecha_nacimiento = fecha_nacimiento;
        this.newsletter = newsletter;
        this.active = active;
    }
}
