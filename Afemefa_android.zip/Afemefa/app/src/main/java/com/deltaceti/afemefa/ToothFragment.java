package com.deltaceti.afemefa;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.AnswerCenters;
import com.deltaceti.afemefa.json.CenterDoctor;
import com.deltaceti.afemefa.json.Centers;
import com.deltaceti.afemefa.json.Cities;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ToothFragment extends Fragment {

    private TextInputLayout cp_layout, professional_layout, center_layout;

    private TextInputEditText cp_et, professional_et, center_et;

    private String cp_str, professional_str, center_str;

    private Button find_btn;

    private View mProgressView;
    private View mLoginFormView;

    private RequestQueue requestQueue;
    private Gson gson;
    private PrefManager pref_manager;
    private String endpointLogin, endpointCities, endpointCenters;

    private HashMap<String, Integer> hashMap_provincias = null;
    private HashMap<String, Integer> hashMap_cities = null;
    private Spinner province_sp, city_sp;
    private List<String> cities=null;

    private Integer city_id=null, province_id=null;

    public ToothFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_tooth, container, false);

        find_btn = v.findViewById(R.id.btn_find);

        cp_layout = v.findViewById(R.id.cp_layout);
        professional_layout = v.findViewById(R.id.professional_layout);
        center_layout = v.findViewById(R.id.center_layout);

        cp_et = v.findViewById(R.id.cp_et);
        professional_et = v.findViewById(R.id.professional_et);
        center_et = v.findViewById(R.id.center_et);

        mLoginFormView = v.findViewById(R.id.scrollView1);
        mProgressView = v.findViewById(R.id.login_progress);

        province_sp = (Spinner) v.findViewById(R.id.province_sp);
        city_sp = (Spinner) v.findViewById(R.id.city_sp);

        pref_manager = new PrefManager(getContext());

        Utils.showProgress(true, getContext(), mLoginFormView, mProgressView);
        requestQueue = Volley.newRequestQueue(getContext());
        gson = new GsonBuilder().serializeNulls().create();
        endpointLogin = getString(R.string.base_url).concat(getString(R.string.centers_path));
        fetchPosts();

        find_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptFind();
            }
        });

        return v;
    }

    @Override
    public void onViewCreated(View rootView, Bundle savedInstanceState){
        super.onViewCreated(rootView, savedInstanceState);
        final View v = rootView;
// Spinner element

        // Spinner click listener
        province_sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {

                // On selecting a spinner item
                String item = parent.getItemAtPosition(position).toString();
                endpointCities = getString(R.string.base_url).concat(getString(R.string.cities_path));
                province_id = hashMap_provincias.get(item);

                if (province_id != null) {
                    fetchPostsCities();
                } else {
                    Log.d("AFEMAFA", "Todas provincias");
                    city_sp.setAdapter(null);
                }
                city_sp.setEnabled(false);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // Spinner click listener
        city_sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {

                // On selecting a spinner item
                String item = parent.getItemAtPosition(position).toString();
                city_id = hashMap_cities.get(item);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void attemptFind(){
        cp_layout.setError(null);
        professional_layout.setError(null);
        center_layout.setError(null);

        cp_str = cp_et.getText().toString();
        professional_str = professional_et.getText().toString();
        center_str = center_et.getText().toString();

        boolean cancel = false;
        View focusView = null;


        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            if (Utils.checkConnectivity(getActivity())) {
                Utils.showProgress(true, getContext(), mLoginFormView, mProgressView);
                endpointCenters = getString(R.string.base_url).concat(getString(R.string.doctor_centers_path));
                fetchCenters();
            } else {
                Utils.alertError("ATENCIÓN", getString(R.string.connectivity_problem), getActivity());
            }
        }
    }

    private void fillCities(){
        ArrayAdapter<String> dataAdapter_1 = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, cities);
// Drop down layout style - list view with radio button
        dataAdapter_1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// attaching data adapter to spinner
        city_sp.setAdapter(dataAdapter_1);
        city_sp.setEnabled(true);
    }

    //////// POST
    private void fetchPosts() {
        StringRequest request = new StringRequest(Request.Method.GET, endpointLogin, onPostsLoaded, onPostsError)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoaded = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            Centers answer = gson.fromJson(response, Centers.class);
            JsonArray list_especialidades = gson.fromJson(answer.getEspecialidades(), JsonArray.class);

            JsonArray list_provincias = gson.fromJson(answer.getProvincias(), JsonArray.class);
            hashMap_provincias = new HashMap<String, Integer>();
            List<String> provinces = new ArrayList<String>();
            provinces.add("Todas las provincias");
            for (int i = 0; i < list_provincias.size(); i++) {
                Integer id = list_provincias.get(i).getAsJsonObject().get("id").getAsInt();
                String name = list_provincias.get(i).getAsJsonObject().get("nombre").getAsString();
                hashMap_provincias.put(name, id);
                Log.d("Afemafa", name);
                provinces.add(name);
            }
            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter_2 = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, provinces);
// Drop down layout style - list view with radio button
            dataAdapter_2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// attaching data adapter to spinner
            province_sp.setAdapter(dataAdapter_2);
            //User user = gson.fromJson(answer.getData(), User.class);
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);

        }
    };

    private final Response.ErrorListener onPostsError = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
            Log.e("PostActivity", error.toString());
        }
    };

    //////// POST
    private void fetchPostsCities() {
        StringRequest request = new StringRequest(Request.Method.POST, endpointCities, onPostsLoadedCities, onPostsErrorCities)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("idProvincia", String.valueOf(province_id));
                return params;
            }


            /*@Override
            public byte[] getBody() throws AuthFailureError {

                Log.i("PostActivity", requestBody);
                return requestBody == null ? null : requestBody.getBytes();

            }*/

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoadedCities = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            Cities answer = gson.fromJson(response, Cities.class);
            JsonArray list_cities = gson.fromJson(answer.getLocalidades(), JsonArray.class);
            hashMap_cities = new HashMap<String, Integer>();
            cities = new ArrayList<String>();
            cities.add("Todas las localidades");
            for (int i = 0; i < list_cities.size(); i++) {
                Integer id = list_cities.get(i).getAsJsonObject().get("id").getAsInt();
                String name = list_cities.get(i).getAsJsonObject().get("nombre").getAsString();
                hashMap_cities.put(name, id);
                cities.add(name);
            }
            fillCities();
            // Creating adapter for spinner


        }
    };

    private final Response.ErrorListener onPostsErrorCities = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            NetworkResponse networkResponse = error.networkResponse;
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
            Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
            Log.e("PostActivity", error.toString());
        }
    };



    ////////////CENTERS////////////////////
    //////// POST
    private void fetchCenters() {
        StringRequest request = new StringRequest(Request.Method.POST, endpointCenters, onPostsLoadedCenters, onPostsErrorCenters)

        {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded";
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("listingfields[2]", "579");
                if (province_id!=null)
                    params.put("listingfields[27]", String.valueOf(province_id));
                if (city_id!=null)
                    params.put("listingfields[29]", String.valueOf(city_id));
                params.put("listingfields[14]", cp_str);
                params.put("listingfields[1]", center_str);
                params.put("listingfields[15]", professional_str);
                Log.d("AFEMAFA", params.toString());
                return params;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {

                Log.d("PostActivity", response.toString());
                Log.d("PostActivity", "aaaa");
                String json = null;
                if (response.statusCode==200) {
                    try {
                        json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    return Response.success(json, HttpHeaderParser.parseCacheHeaders(response));
                } else if(response.statusCode==204){
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
                            Utils.alertError("ATENCIÓN", getString(R.string.no_centers), getActivity());
                        }
                    });

                    return null;
                } else{
                    return null;
                }
            }


        };
        Log.d("PostActivity", request.toString());
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);

    }

    private final Response.Listener<String> onPostsLoadedCenters = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Log.i("PostActivity", response);
            AnswerCenters answer = gson.fromJson(response, AnswerCenters.class);
            JsonArray list_centers = gson.fromJson(answer.getCentros(), JsonArray.class);
            ArrayList<CenterDoctor> centers_list = new ArrayList<>();
            for (int i = 0; i < list_centers.size(); i++) {
                CenterDoctor center = gson.fromJson(list_centers.get(i), CenterDoctor.class);
                Log.d("AFEMAFA", center.getDireccion());
                centers_list.add(center);
            }


            Log.d("AFEMAFA", list_centers.toString());
            Intent intent = new Intent(getActivity(), MapActivity.class);
            /*Bundle b = new Bundle();
            b.putSerializable("centers", centers_list);
            intent.putExtras(b); //Put your id to your next Intent*/

            String json_centers = gson.toJson(centers_list);
            pref_manager.setCenters(json_centers);
            startActivity(intent);
            Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);

        }
    };

    private final Response.ErrorListener onPostsErrorCenters = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Log.e("PostActivity", error.toString());
            NetworkResponse networkResponse = error.networkResponse;
            if (networkResponse != null && networkResponse.statusCode != 204) {
                Utils.showProgress(false, getContext(), mLoginFormView, mProgressView);
                Utils.alertError("ATENCIÓN", getString(R.string.system_fails), getActivity());
            }
        }
    };
}
