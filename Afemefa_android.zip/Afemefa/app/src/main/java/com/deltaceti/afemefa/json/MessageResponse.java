package com.deltaceti.afemefa.json;

/**
 * Created by arr375 on 13/02/2017.
 */

public class MessageResponse {

    private String mensaje;

    public MessageResponse(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getMensaje() {
        return mensaje;
    }
}
