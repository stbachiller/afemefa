package com.deltaceti.afemefa;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deltaceti.afemefa.Utils.InputStreamVolleyRequest;
import com.deltaceti.afemefa.Utils.Utils;
import com.deltaceti.afemefa.json.Download;
import com.deltaceti.afemefa.json.LateralText;
import com.deltaceti.afemefa.list.DownloadAdapter;
import com.deltaceti.afemefa.sql.DatabaseHelper;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class PublicDownloadFragment extends Fragment implements Response.Listener<byte[]>, Response.ErrorListener {


    private ListView listView;

    private List<Download> download_list;

    private static DownloadAdapter adapter;
    private ImageView more_image;

    private DatabaseHelper db;
    private static final int PETICION_PERMISO_ALMACENAMIENTO=100;

    private Download download;

    private InputStreamVolleyRequest request;
    private int count;

    public PublicDownloadFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_download_public, container, false);
        setHasOptionsMenu(true);

        db = DatabaseHelper.getInstance(getContext());

        download_list = db.getDownloads("mutualista", "contenido");

        listView = v.findViewById(R.id.list);
        adapter = new DownloadAdapter((ArrayList<Download>) download_list, getContext());
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                download= download_list.get(position);

                if (ContextCompat.checkSelfPermission(getContext(),
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PETICION_PERMISO_ALMACENAMIENTO);
                } else {
                    String mUrl=download.getUrl_descarga();
                    request = new InputStreamVolleyRequest(Request.Method.GET, mUrl, PublicDownloadFragment.this, PublicDownloadFragment.this, null);
                    RequestQueue mRequestQueue = Volley.newRequestQueue(getContext(),
                            new HurlStack());
                    mRequestQueue.add(request);
                    Log.d("AFEMAFA", "click");
                }

            }
        });

        return v;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        getActivity().getMenuInflater().inflate(R.menu.menu_order, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_title) {

            Context context = getContext();
            download_list = db.getDownloads("mutualista", "titulo");
            adapter = new DownloadAdapter((ArrayList<Download>) download_list, getContext());
            listView.setAdapter(adapter);

            return true;
        }
        else if(id == R.id.menu_publication_date){
            Context context = getContext();
            download_list = db.getDownloads("mutualista", "fecha_modificación");
            adapter = new DownloadAdapter((ArrayList<Download>) download_list, getContext());
            listView.setAdapter(adapter);

            return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PETICION_PERMISO_ALMACENAMIENTO: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    String mUrl=download.getUrl_descarga();
                    request = new InputStreamVolleyRequest(Request.Method.GET, mUrl, PublicDownloadFragment.this, PublicDownloadFragment.this, null);
                    RequestQueue mRequestQueue = Volley.newRequestQueue(getContext(),
                            new HurlStack());
                    mRequestQueue.add(request);

                    return;
                }

                // other 'case' lines to check for other
                // permissions this app might request
            }
        }
    }

    @Override
    public void onResponse(byte[] response) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            if (response!=null) {

                //Read file name from headers
                /*String content =request.responseHeaders.get("Content-Disposition")
                        .toString();
                StringTokenizer st = new StringTokenizer(content, "=");
                //String[] arrTag = st.toArray();

                String cName="", cMascot, cAlias;
                while (st.hasMoreElements()) {
                    cName = st.nextToken();
                    cMascot = st.nextToken();
                    //cAlias = st.nextToken();
                    System.out.println("cName :" + cName);
                    System.out.println("cMascot :" + cMascot);
                    //System.out.println("cAlias :" + cAlias);
                }

                String filename = cName;
                filename = filename.replace(":", ".");
                Log.d("DEBUG::RESUME FILE NAME", filename);*/

                try{
                    long lenghtOfFile = response.length;

                    //covert reponse to input stream
                    InputStream input = new ByteArrayInputStream(response);
                    File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    File file = new File(path, download.getTitulo() + "." + download.getExt());
                    map.put("resume_path", file.toString());
                    Log.d("AFEMAFA",file.toString());
                    BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(file));
                    byte data[] = new byte[1024];

                    long total = 0;

                    while ((count = input.read(data)) != -1) {
                        total += count;
                        output.write(data, 0, count);
                    }

                    output.flush();

                    output.close();
                    input.close();
                    Toast.makeText(getContext(), "Archivo descargado", Toast.LENGTH_LONG).show();
                }catch(IOException e){
                    e.printStackTrace();

                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Log.d("KEY_ERROR", "UNABLE TO DOWNLOAD FILE");
            e.printStackTrace();
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Log.d("KEY_ERROR", "UNABLE TO DOWNLOAD FILE. ERROR:: "+error.getMessage());
    }

}
