package com.deltaceti.afemefa.json;

import com.google.gson.JsonArray;

/**
 * Created by arr375 on 13/02/2017.
 */

public class AnswerDownloads {

    private JsonArray descargasUsuario;
    private JsonArray descargasMutualista;

    public JsonArray getDescargasUsuario() {
        return descargasUsuario;
    }

    public JsonArray getDescargasMutualista() {
        return descargasMutualista;
    }
}
